import xbmc
import xbmcgui
import xbmcaddon

ADDON_ID = 'service.luc_kodi.tmdbextendedinfo'
ADDON = xbmcaddon.Addon(ADDON_ID)

PROP_NAME = 'LucKodi.TMDbExtendedContext'

class Monitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.update_prop()

    def onSettingsChanged(self):
        self.update_prop()

    def update_prop(self):
        win = xbmcgui.Window(10000)
        if xbmc.getCondVisibility('System.HasAddon(%s)' % 'plugin.video.luc_kodi') and ADDON.getSettingBool('enable_extended_context'):
            win.setProperty(PROP_NAME, 'true')
        else:
            win.clearProperty(PROP_NAME)

def run():
    mon = Monitor()
    # keep service alive
    while not mon.abortRequested():
        if mon.waitForAbort(5):
            break

if __name__ == '__main__':
    run()
