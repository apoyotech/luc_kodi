# -*- coding: utf-8 -*-
import re
import time
import xbmc
import xbmcaddon
import xbmcgui
import requests
from urllib.parse import urlencode

ADDON_ID = 'service.luc_kodi.tmdbextendedinfo'
LUC_ADDON_ID = 'plugin.video.luc_kodi'
TRAKT_AUTH_URL = 'https://trakt.tv/oauth/authorize'
TRAKT_TOKEN_URL = 'https://trakt.tv/oauth/token'
TRAKT_REDIRECT_URI = 'urn:ietf:wg:oauth:2.0:oob'

def _service_addon():
    return xbmcaddon.Addon(ADDON_ID)

def _luc_addon():
    try:
        return xbmcaddon.Addon(LUC_ADDON_ID)
    except Exception:
        return None

def _read_luc_trakt_constants(luc_path):
    try:
        import xbmcvfs
        from pathlib import Path
        trakt_file = xbmcvfs.translatePath(luc_path + '/resources/lib/modules/trakt.py')
        data = Path(trakt_file).read_text(encoding='utf-8', errors='ignore')
        cid = re.search(r"V2_API_KEY\s*=\s*'([^']+)'", data)
        sec = re.search(r"CLIENT_SECRET\s*=\s*'([^']+)'", data)
        return (cid.group(1) if cid else ''), (sec.group(1) if sec else '')
    except Exception:
        return '', ''

def get_keys_source():
    try:
        return int(_service_addon().getSetting('keys.source') or '0')
    except Exception:
        return 0

def get_tmdb_api_key():
    svc = _service_addon()
    src = get_keys_source()
    if src == 1:
        own = (svc.getSetting('own.tmdb.api_key') or '').strip()
        if own:
            return own

    luc = _luc_addon()
    if luc:
        k = (luc.getSetting('tmdb.api.key') or '').strip()
        if k:
            return k

    legacy = (svc.getSetting('tmdb_api_key') or '').strip()
    return legacy

def get_trakt_credentials():
    svc = _service_addon()
    src = get_keys_source()
    if src == 1:
        return {
            'client_id': (svc.getSetting('own.trakt.client_id') or '').strip(),
            'client_secret': (svc.getSetting('own.trakt.client_secret') or '').strip(),
            'token': (svc.getSetting('own.trakt.token') or '').strip(),
            'refresh': (svc.getSetting('own.trakt.refresh') or '').strip(),
            'expires': (svc.getSetting('own.trakt.expires') or '').strip(),
            'username': (svc.getSetting('own.trakt.username') or '').strip(),
        }

    luc = _luc_addon()
    if not luc:
        return {'client_id':'','client_secret':'','token':'','refresh':'','expires':'','username':''}

    client_id = (luc.getSetting('trakt.client_id') or '').strip()
    client_secret = (luc.getSetting('trakt.client_secret') or '').strip()
    if (not client_id) or (not client_secret):
        cid2, sec2 = _read_luc_trakt_constants(luc.getAddonInfo('path'))
        client_id = client_id or cid2
        client_secret = client_secret or sec2

    return {
        'client_id': client_id,
        'client_secret': client_secret,
        'token': (luc.getSetting('trakt.token') or '').strip(),
        'refresh': (luc.getSetting('trakt.refresh') or '').strip(),
        'expires': (luc.getSetting('trakt.expires') or '').strip(),
        'username': (luc.getSetting('trakt.username') or '').strip(),
    }

def copy_from_luc_kodi_into_service():
    luc = _luc_addon()
    if not luc:
        return False, 'plugin.video.luc_kodi is not installed.'

    svc = _service_addon()
    svc.setSetting('own.tmdb.api_key', (luc.getSetting('tmdb.api.key') or '').strip())

    client_id = (luc.getSetting('trakt.client_id') or '').strip()
    client_secret = (luc.getSetting('trakt.client_secret') or '').strip()
    if (not client_id) or (not client_secret):
        cid2, sec2 = _read_luc_trakt_constants(luc.getAddonInfo('path'))
        client_id = client_id or cid2
        client_secret = client_secret or sec2

    svc.setSetting('own.trakt.client_id', client_id)
    svc.setSetting('own.trakt.client_secret', client_secret)
    svc.setSetting('own.trakt.token', (luc.getSetting('trakt.token') or '').strip())
    svc.setSetting('own.trakt.refresh', (luc.getSetting('trakt.refresh') or '').strip())
    svc.setSetting('own.trakt.expires', (luc.getSetting('trakt.expires') or '').strip())
    svc.setSetting('own.trakt.username', (luc.getSetting('trakt.username') or '').strip())

    return True, 'Copied TMDb/Trakt values from luc_kodi into this service settings.'

def trakt_authorize_pin_flow():
    svc = _service_addon()
    client_id = (svc.getSetting('own.trakt.client_id') or '').strip()
    client_secret = (svc.getSetting('own.trakt.client_secret') or '').strip()
    if not client_id or not client_secret:
        return False, 'Set own Trakt client_id and client_secret first.'

    params = {'response_type':'code', 'client_id':client_id, 'redirect_uri':TRAKT_REDIRECT_URI}
    url = TRAKT_AUTH_URL + '?' + urlencode(params)
    xbmcgui.Dialog().ok('Trakt Authorization', 'Open this URL in a browser, authorize, then paste the PIN/code:\n\n' + url)

    pin = xbmcgui.Dialog().input('Paste Trakt PIN/code', type=xbmcgui.INPUT_ALPHANUM)
    if not pin:
        return False, 'Cancelled.'

    payload = {
        'code': pin.strip(),
        'client_id': client_id,
        'client_secret': client_secret,
        'redirect_uri': TRAKT_REDIRECT_URI,
        'grant_type': 'authorization_code',
    }
    try:
        r = requests.post(TRAKT_TOKEN_URL, json=payload, timeout=20)
        if r.status_code not in (200, 201):
            return False, 'Trakt token request failed: %s\n%s' % (r.status_code, r.text[:200])
        data = r.json()
        svc.setSetting('own.trakt.token', data.get('access_token',''))
        svc.setSetting('own.trakt.refresh', data.get('refresh_token',''))
        expires = int(time.time()) + int(data.get('expires_in', 0))
        svc.setSetting('own.trakt.expires', str(expires))
        return True, 'Trakt authorized. Tokens saved.'
    except Exception as e:
        return False, 'Error: %s' % e
