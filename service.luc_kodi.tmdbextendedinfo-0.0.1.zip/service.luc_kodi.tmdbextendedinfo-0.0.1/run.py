# -*- coding: utf-8 -*-
from __future__ import annotations
import sys, json
from urllib.parse import parse_qsl, quote_plus
import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')

def _get_params():
    try:
        return dict(parse_qsl(sys.argv[1].replace('?', '')))
    except Exception:
        # Kodi sometimes passes params via argv[2] depending on callsite
        try:
            return dict(parse_qsl(sys.argv[2].replace('?', '')))
        except Exception:
            return {}

def _close_dialogs():
    try:
        xbmc.executebuiltin('Dialog.Close(all,true)')
    except Exception:
        pass

def _notify(msg, heading=None, time_ms=3000):
    try:
        xbmcgui.Dialog().notification(heading or ADDON_ID, msg, time_ms=time_ms)
    except Exception:
        pass

def _play_media(url):
    xbmc.executebuiltin('RunPlugin(%s)' % url)

def _runscript(params: dict):
    qs = '&'.join(['%s=%s' % (k, quote_plus(str(v))) for k, v in params.items() if v is not None])
    xbmc.executebuiltin('RunScript(%s,?%s)' % (ADDON_ID, qs))


def action_play():
    # Pull from Window props set by extended_info_mod
    win = xbmcgui.Window(10000)
    # Prefer properties set by ExtendedInfo dialog (luc_ext.*)
    _p = lambda k: win.getProperty(k) or ''
    title = _p('luc_ext.title') or _p('title') or _p('movie.title') or _p('movie.Title')
    year = _p('luc_ext.year') or _p('year') or _p('movie.year') or _p('movie.Year')
    premiered = _p('luc_ext.premiered') or _p('Premiered') or _p('movie.Premiered') or ''
    tmdb_id = win.getProperty('id') or ''
    media_type = (win.getProperty('media_type') or 'movie').lower()

    if not tmdb_id:
        return _notify('No se encontró TMDb ID.')

    if media_type == 'tv':
        # For TV shows we open seasons in luc_kodi
        url = 'plugin://plugin.video.luc_kodi/?action=seasons&tmdb=%s&tvshowtitle=%s&year=%s' % (
            quote_plus(tmdb_id), quote_plus(title), quote_plus(year)
        )
    else:
        imdb = _p('luc_ext.imdb') or _p('imdb_id') or _p('IMDb') or ''
        poster = _p('luc_ext.poster') or _p('poster') or _p('movie.poster') or _p('movie.Poster') or _p('tvshow.poster') or _p('tvshow.Poster') or ''
        fanart = _p('luc_ext.fanart') or _p('fanart') or _p('movie.fanart') or _p('movie.Fanart') or _p('tvshow.fanart') or _p('tvshow.Fanart') or _p('Backdrop') or _p('ImageFilter') or ''
        meta = {
            'title': title, 'originaltitle': title, 'year': year, 'premiered': premiered,
            'imdb': imdb, 'imdbnumber': imdb, 'tmdb': tmdb_id, 'mediatype': 'movie',
            'poster': poster, 'thumb': poster, 'fanart': fanart
        }
        meta_q = quote_plus(json.dumps(meta, ensure_ascii=False))
        url = 'plugin://plugin.video.luc_kodi/?action=play&tmdb=%s&title=%s&year=%s&premiered=%s&imdb=%s&select=0&meta=%s' % (
            quote_plus(tmdb_id), quote_plus(title), quote_plus(year), quote_plus(premiered), quote_plus(imdb), meta_q
        )

    _close_dialogs()
    _open_plugin_dir(url)

def action_videos():
    """Show trailers list and play using plugin.video.luc_kodi (action=play_Trailer).

    This keeps all trailer handling inside luc_kodi (keys, windowed trailer, etc.).
    """
    from resources.lib.tmdb_api import tmdb_get_videos
    win = xbmcgui.Window(10000)
    tmdb_id = win.getProperty('id') or ''
    media_type = (win.getProperty('media_type') or 'movie').lower()
    imdb = win.getProperty('imdb_id') or win.getProperty('IMDb') or ''

    vids = tmdb_get_videos(media_type, tmdb_id)
    # Prefer trailers/teasers
    preferred = [v for v in vids if (v.get('type') or '').lower() in ('trailer', 'teaser')]
    pick_list = preferred or vids
    if not pick_list:
        return _notify('No se encontraron trailers.')

    labels = []
    items = []
    for v in pick_list:
        if (v.get('site') or '').lower() != 'youtube' or not v.get('key'):
            continue
        vtype = v.get('type') or 'Video'
        vname = v.get('name') or ''
        labels.append('%s - %s' % (vtype, vname))
        items.append(v)

    if not items:
        return _notify('No hay trailers reproducibles.')

    idx = xbmcgui.Dialog().select('Trailers', labels)
    if idx < 0:
        return

    yt_key = items[idx].get('key')
    yt_watch = 'https://www.youtube.com/watch?v=%s' % yt_key

    # Call luc_kodi trailer player
    _close_dialogs()
    url = 'plugin://plugin.video.luc_kodi/?action=play_Trailer&type=%s&name=%s&year=%s&imdb=%s&url=%s&windowedtrailer=1' % (
        quote_plus('movie' if media_type != 'tv' else 'tv'),
        quote_plus(title),
        quote_plus(year),
        quote_plus(imdb),
        quote_plus(yt_watch),
    )
    _play_media(url)

def main():

    p = _get_params()
    mode = (p.get('mode') or '').lower()
    if mode == 'play':
        return action_play()
    if mode == 'videos':
        return action_videos()
    # default: open extended info via context_extended
    _runscript({'mode': 'info'})

if __name__ == '__main__':
    main()
