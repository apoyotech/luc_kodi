import sys
import os
import json
import urllib.request
import urllib.parse
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import re

addon = xbmcaddon.Addon()
addon_id = addon.getAddonInfo('id')
addon_path = addon.getAddonInfo('path')

def log(msg):
    xbmc.log(f"[Stremio Subs] {msg}", xbmc.LOGINFO)

def get_flag_path(lang_code):
    """Obter caminho da imagem da bandeira para um idioma"""
    # Mapeamento APENAS para os 4 idiomas solicitados
    flag_mapping = {
        # Português (Portugal)
        'pt': 'pt.png',
        'por': 'pt.png',
        'portuguese': 'pt.png',
        'português': 'pt.png',
        'portugues': 'pt.png',
        
        # Português Brasil
        'pt-br': 'br.png',
        'pt-BR': 'br.png',
        'pob': 'br.png',
        'brazilian': 'br.png',
        'português brasil': 'br.png',
        'portugues brasil': 'br.png',
        'portuguese (brazil)': 'br.png',
        'portuguese brazil': 'br.png',
        
        # Espanhol
        'es': 'es.png',
        'spa': 'es.png',
        'spanish': 'es.png',
        'espanol': 'es.png',
        'español': 'es.png',
        'castilian': 'es.png',
        
        # Romeno
        'ro': 'ro.png',
        'rum': 'ro.png',
        'romanian': 'ro.png',
        'romeno': 'ro.png',
        'română': 'ro.png',
        'romana': 'ro.png'
    }
    
    lang_lower = lang_code.lower().strip()
    flag_file = flag_mapping.get(lang_lower)
    
    if flag_file:
        flag_path = os.path.join(addon_path, 'flags', flag_file)
        if xbmcvfs.exists(flag_path):
            log(f"Flag found for '{lang_code}' -> {flag_path}")
            return flag_path
    
    return None

def get_stored_preference():
    """Obter idioma preferido armazenado"""
    try:
        profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        pref_file = os.path.join(profile, 'language_preference.txt')
        
        if xbmcvfs.exists(pref_file):
            with open(pref_file, 'r') as f:
                preference = f.read().strip()
                log(f"Stored language preference: {preference}")
                return preference
        else:
            log("No stored language preference found")
            return 'auto'
    except Exception as e:
        log(f"Error reading language preference: {e}")
        return 'auto'

def store_preference(preference):
    """Armazenar idioma preferido"""
    try:
        profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        if not xbmcvfs.exists(profile):
            xbmcvfs.mkdirs(profile)
        
        pref_file = os.path.join(profile, 'language_preference.txt')
        with open(pref_file, 'w') as f:
            f.write(preference)
        
        log(f"Stored language preference: {preference}")
        return True
    except Exception as e:
        log(f"Error storing language preference: {e}")
        return False

def show_language_selection():
    """Mostrar menu de seleção de idioma"""
    try:
        languages = [
            ('auto', 'Todos os Idiomas'),
            ('pt', 'Apenas Português (Portugal)'),
            ('pt-BR', 'Apenas Português Brasil'),
            ('es', 'Apenas Español'),
            ('ro', 'Apenas Română')
        ]
        
        current_pref = get_stored_preference()
        
        # Criar lista de opções
        options = []
        preselect = 0
        
        for i, (code, name) in enumerate(languages):
            if code == current_pref:
                options.append(f"✓ {name}")
                preselect = i
            else:
                options.append(f"   {name}")
        
        dialog = xbmcgui.Dialog()
        selected = dialog.select(
            "Escolha o Filtro de Idioma",
            options,
            preselect=preselect
        )
        
        if selected >= 0:
            new_pref = languages[selected][0]
            store_preference(new_pref)
            
            # Mostrar confirmação
            dialog.notification(
                "Stremio Subs",
                f"Filtro: {languages[selected][1]}",
                xbmcgui.NOTIFICATION_INFO,
                3000
            )
            
            log(f"User selected language filter: {new_pref}")
            return True
        
        return False
        
    except Exception as e:
        log(f"Error in language selection: {e}")
        return False

def filter_subtitles_by_preference(subtitles):
    """Filtrar legendas para mostrar APENAS o idioma escolhido"""
    try:
        preferred = get_stored_preference()
        
        if preferred == 'auto' or not preferred:
            log("No language filter set, returning all subtitles")
            return subtitles
        
        # Mapeamento de códigos de idioma
        language_codes = {
            'pt': ['pt', 'por', 'portuguese'],
            'pt-BR': ['pt-BR', 'pt-br', 'pob', 'brazilian'],
            'es': ['es', 'spa', 'spanish', 'espanol'],
            'ro': ['ro', 'rum', 'romanian', 'romeno']
        }
        
        preferred_codes = language_codes.get(preferred, [])
        if not preferred_codes:
            log(f"No codes found for preferred language: {preferred}")
            return subtitles
        
        log(f"Filtering subtitles for ONLY: {preferred} (codes: {preferred_codes})")
        
        # Filtrar APENAS as legendas do idioma escolhido
        filtered_subs = []
        
        for subtitle in subtitles:
            lang = subtitle.get('lang', '').lower()
            
            # Verificar se o idioma corresponde à preferência
            is_preferred = any(code.lower() in lang or lang in code.lower() 
                             for code in preferred_codes)
            
            if is_preferred:
                filtered_subs.append(subtitle)
                log(f"Filtered subtitle included: {lang}")
        
        log(f"Returning {len(filtered_subs)} subtitles (filtered from {len(subtitles)} total)")
        return filtered_subs
        
    except Exception as e:
        log(f"Error filtering subtitles: {e}")
        return subtitles

def get_language_display_name(lang_code):
    """Obter nome de exibição melhorado do idioma"""
    display_names = {
        'pt': 'PORTUGUÊS',
        'pt-br': 'PORTUGUÊS BRASIL', 
        'pob': 'PORTUGUÊS BRASIL',
        'por': 'PORTUGUÊS',
        'es': 'ESPAÑOL',
        'spa': 'ESPAÑOL', 
        'ro': 'ROMÂNĂ',
        'rum': 'ROMÂNĂ',
        'en': 'ENGLISH',
        'eng': 'ENGLISH'
    }
    
    lang_lower = lang_code.lower()
    return display_names.get(lang_lower, lang_code.upper())

def clean_title_from_filename(filename):
    """Extrair título limpo do nome do arquivo"""
    try:
        # Remover caminho e extensão
        basename = os.path.basename(filename)
        name_without_ext = os.path.splitext(basename)[0]
        
        log(f"Cleaning filename: {name_without_ext}")
        
        # Padrões para remover (resolução, codec, etc.)
        patterns_to_remove = [
            r'\b\d{4}p\b',  # 1080p, 720p, etc.
            r'\bWEB-DL\b',
            r'\bBluRay\b',
            r'\bBDRip\b',
            r'\bDVDRip\b',
            r'\bHDRip\b',
            r'\bCAMRip\b',
            r'\bDUAL\b',
            r'\b5\.1\b',
            r'\b7\.1\b',
            r'\bDTS\b',
            r'\bAC3\b',
            r'\bx264\b',
            r'\bx265\b',
            r'\bHEVC\b',
            r'\bH\.264\b',
            r'\bH\.265\b',
            r'\bAAC\b',
            r'\bMP3\b',
            r'\bFLAC\b',
            r'\bATMOS\b',
            r'\bHDR\b',
            r'\bDOLBY\b',
            r'\bREMUX\b',
            r'\bEXTENDED\b',
            r'\bDIRECTORS\b',
            r'\bCUT\b',
            r'\bUNCUT\b',
            r'\bRERIP\b',
            r'\bPROPER\b',
            r'\bREPACK\b',
            r'\b\[.*?\]\b',  # [tags]
            r'\b\(.*?codec.*?\)\b',  # (codec info)
        ]
        
        # Remover padrões técnicos
        clean_name = name_without_ext
        for pattern in patterns_to_remove:
            clean_name = re.sub(pattern, '', clean_name, flags=re.IGNORECASE)
        
        # Extrair ano se presente
        year_match = re.search(r'\b(19|20)\d{2}\b', clean_name)
        year = year_match.group() if year_match else None
        
        # Remover ano do título
        if year:
            clean_name = re.sub(rf'\b{year}\b', '', clean_name)
        
        # Limpar pontuação e espaços extras
        clean_name = re.sub(r'[._\-]+', ' ', clean_name)
        clean_name = re.sub(r'\s+', ' ', clean_name).strip()
        
        # Remover parênteses vazios
        clean_name = re.sub(r'\(\s*\)', '', clean_name).strip()
        
        log(f"Cleaned title: '{clean_name}', Year: {year}")
        return clean_name, year
        
    except Exception as e:
        log(f"Error cleaning filename: {e}")
        return None, None

def search_tmdb_for_imdb(title, year=None):
    """Buscar IMDB ID usando a API do TMDB"""
    try:
        if not title or len(title.strip()) < 2:
            return None
            
        # API Key do TMDB (pública para demonstração)
        api_key = "8d6d91941230817f7807d643736e8a49"
        
        # Preparar query
        query = urllib.parse.quote_plus(title)
        url = f"https://api.themoviedb.org/3/search/movie?api_key={api_key}&query={query}"
        
        if year:
            url += f"&year={year}"
        
        log(f"Searching TMDB: {url}")
        
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
        
        with urllib.request.urlopen(req, timeout=10) as response:
            content = response.read().decode('utf-8')
            data = json.loads(content)
            
            results = data.get('results', [])
            if not results:
                log(f"No TMDB results for: {title}")
                return None
            
            # Pegar o primeiro resultado (mais relevante)
            movie = results[0]
            tmdb_id = movie.get('id')
            
            if not tmdb_id:
                log("No TMDB ID found in result")
                return None
            
            # Buscar detalhes do filme para obter IMDB ID
            details_url = f"https://api.themoviedb.org/3/movie/{tmdb_id}?api_key={api_key}&append_to_response=external_ids"
            
            req = urllib.request.Request(details_url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
            
            with urllib.request.urlopen(req, timeout=10) as response:
                content = response.read().decode('utf-8')
                details = json.loads(content)
                
                external_ids = details.get('external_ids', {})
                imdb_id = external_ids.get('imdb_id')
                
                if imdb_id:
                    log(f"Found IMDB ID via TMDB: {imdb_id} for '{title}' ({year})")
                    return imdb_id
                else:
                    log("No IMDB ID found in TMDB details")
                    return None
        
    except Exception as e:
        log(f"Error searching TMDB: {e}")
        return None

def search_tv_tmdb_for_imdb(title, year=None):
    """Buscar IMDB ID para séries usando a API do TMDB"""
    try:
        if not title or len(title.strip()) < 2:
            return None
            
        # API Key do TMDB (pública para demonstração)
        api_key = "8d6d91941230817f7807d643736e8a49"
        
        # Preparar query
        query = urllib.parse.quote_plus(title)
        url = f"https://api.themoviedb.org/3/search/tv?api_key={api_key}&query={query}"
        
        if year:
            url += f"&first_air_date_year={year}"
        
        log(f"Searching TMDB TV: {url}")
        
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
        
        with urllib.request.urlopen(req, timeout=10) as response:
            content = response.read().decode('utf-8')
            data = json.loads(content)
            
            results = data.get('results', [])
            if not results:
                log(f"No TMDB TV results for: {title}")
                return None
            
            # Pegar o primeiro resultado (mais relevante)
            show = results[0]
            tmdb_id = show.get('id')
            
            if not tmdb_id:
                log("No TMDB TV ID found in result")
                return None
            
            # Buscar detalhes da série para obter IMDB ID
            details_url = f"https://api.themoviedb.org/3/tv/{tmdb_id}?api_key={api_key}&append_to_response=external_ids"
            
            req = urllib.request.Request(details_url)
            req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
            
            with urllib.request.urlopen(req, timeout=10) as response:
                content = response.read().decode('utf-8')
                details = json.loads(content)
                
                external_ids = details.get('external_ids', {})
                imdb_id = external_ids.get('imdb_id')
                
                if imdb_id:
                    log(f"Found IMDB ID via TMDB TV: {imdb_id} for '{title}' ({year})")
                    return imdb_id
                else:
                    log("No IMDB ID found in TMDB TV details")
                    return None
        
    except Exception as e:
        log(f"Error searching TMDB TV: {e}")
        return None

def clean_temp_directory():
    """Limpar arquivos antigos do diretório temporário"""
    try:
        profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        temp_dir = os.path.join(profile, 'temp')
        
        if xbmcvfs.exists(temp_dir):
            dirs, files = xbmcvfs.listdir(temp_dir)
            
            import time
            current_time = time.time()
            
            for filename in files:
                filepath = os.path.join(temp_dir, filename)
                try:
                    stat = xbmcvfs.Stat(filepath)
                    if current_time - stat.st_mtime() > 3600:  # 1 hora
                        xbmcvfs.delete(filepath)
                        log(f"Removed old temp file: {filename}")
                except:
                    pass
                    
    except Exception as e:
        log(f"Error cleaning temp directory: {e}")

def get_video_info():
    """Obter informações do vídeo em reprodução - VERSÃO BASEADA NO JACKTOOK"""
    try:
        if not xbmc.Player().isPlaying():
            log("No video playing")
            return None, None, None, None, None
            
        # Tentar obter IMDB ID dos metadados
        imdb = None
        title = None
        year = None
        
        # Método 1: VideoPlayer.IMDBNumber
        imdb = xbmc.getInfoLabel("VideoPlayer.IMDBNumber")
        log(f"Method 1 - VideoPlayer.IMDBNumber: {imdb}")
        
        # Método 2: VideoInfoTag
        if not imdb or not imdb.startswith('tt'):
            try:
                info = xbmc.Player().getVideoInfoTag()
                imdb = info.getIMDBNumber()
                log(f"Method 2 - VideoInfoTag.getIMDBNumber: {imdb}")
            except Exception as e:
                log(f"Error getting VideoInfoTag: {e}")
        
        # Método 3: Buscar no nome do arquivo
        if not imdb or not imdb.startswith('tt'):
            try:
                filename = xbmc.Player().getPlayingFile()
                log(f"Playing file: {filename}")
                
                # Procurar por padrão tt seguido de números
                match = re.search(r'tt\d{7,8}', filename)
                if match:
                    imdb = match.group()
                    log(f"Method 3 - Found IMDB in filename: {imdb}")
            except Exception as e:
                log(f"Error parsing filename: {e}")
        
        # Método 4: Extrair título do nome do arquivo
        try:
            filename = xbmc.Player().getPlayingFile()
            title, year = clean_title_from_filename(filename)
            log(f"Method 4 - Extracted from filename: title='{title}', year={year}")
        except Exception as e:
            log(f"Error extracting from filename: {e}")
        
        # Método 5: Tentar obter título dos metadados
        if not title:
            try:
                info = xbmc.Player().getVideoInfoTag()
                title = info.getTitle()
                if not title:
                    title = xbmc.getInfoLabel("VideoPlayer.Title")
                log(f"Method 5 - Title from metadata: {title}")
            except Exception as e:
                log(f"Error getting title from metadata: {e}")
        
        # Método 6: Tentar obter ano dos metadados
        if not year:
            try:
                info = xbmc.Player().getVideoInfoTag()
                year = info.getYear()
                if not year or year == 0:
                    year_str = xbmc.getInfoLabel("VideoPlayer.Year")
                    if year_str:
                        year = int(year_str)
                log(f"Method 6 - Year from metadata: {year}")
            except Exception as e:
                log(f"Error getting year from metadata: {e}")
        
        # NOVO: Se não temos IMDB ID, buscar via TMDB
        if not imdb or not imdb.startswith('tt'):
            if title:
                log(f"No IMDB ID found, searching TMDB for: '{title}' ({year})")
                
                # Detectar se é série ou filme
                season = xbmc.getInfoLabel("VideoPlayer.Season")
                episode = xbmc.getInfoLabel("VideoPlayer.Episode")
                
                is_tv = season and episode and season != "" and episode != ""
                
                if is_tv:
                    imdb = search_tv_tmdb_for_imdb(title, year)
                else:
                    imdb = search_tmdb_for_imdb(title, year)
                
                if imdb:
                    log(f"Found IMDB ID via TMDB: {imdb}")
                else:
                    log("Could not find IMDB ID via TMDB")
        
        # Obter informações de temporada/episódio
        season = xbmc.getInfoLabel("VideoPlayer.Season")
        episode = xbmc.getInfoLabel("VideoPlayer.Episode")
        
        try:
            season = int(season) if season and season != "" else None
            episode = int(episode) if episode and episode != "" else None
        except:
            season = None
            episode = None
        
        log(f"Final video info - IMDB: {imdb}, Title: '{title}', Year: {year}, Season: {season}, Episode: {episode}")
        return imdb, season, episode, title, year
        
    except Exception as e:
        log(f"Error in get_video_info: {e}")
        return None, None, None, None, None

def search_stremio_subtitles(imdb, season=None, episode=None):
    """Buscar legendas na API do Stremio - COM FILTRO POR IDIOMA"""
    try:
        if season and episode:
            url = f"https://opensubtitles-v3.strem.io/subtitles/series/{imdb}:{season}:{episode}.json"
        else:
            url = f"https://opensubtitles-v3.strem.io/subtitles/movie/{imdb}.json"
        
        log(f"Searching subtitles at: {url}")
        
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
        
        with urllib.request.urlopen(req, timeout=10) as response:
            content = response.read().decode('utf-8')
            log(f"API Response: {content[:200]}...")
            
            data = json.loads(content)
            
            if not isinstance(data, dict):
                log("Invalid API response: not a dictionary")
                return []
                
            subtitles = data.get('subtitles', [])
            
            if not isinstance(subtitles, list):
                log("Invalid API response: subtitles is not a list")
                return []
            
            log(f"Found {len(subtitles)} subtitles in API response")
            
            # FILTRAR por idioma preferido (em vez de ordenar)
            filtered_subtitles = filter_subtitles_by_preference(subtitles)
            
            for i, sub in enumerate(filtered_subtitles[:3]):
                if isinstance(sub, dict):
                    log(f"Filtered subtitle {i}: lang={sub.get('lang')}, id={sub.get('id')}")
            
            return filtered_subtitles
        
    except Exception as e:
        log(f"Error searching subtitles: {e}")
        return []

def search_with_multiple_attempts(title, year, season=None, episode=None):
    """Buscar com múltiplas tentativas de título"""
    try:
        log(f"=== Starting multi-attempt search for: '{title}' ({year}) ===")
        
        # Primeira tentativa: busca normal via TMDB
        if season and episode:
            imdb_id = search_tv_tmdb_for_imdb(title, year)
        else:
            imdb_id = search_tmdb_for_imdb(title, year)
            
        if imdb_id:
            log(f"First attempt successful: {imdb_id}")
            subtitles = search_stremio_subtitles(imdb_id, season, episode)
            if subtitles:
                log(f"Found {len(subtitles)} subtitles on first attempt")
                return subtitles, imdb_id
        
        # Se não encontrou, tentar variações do título
        log("First attempt failed, trying title variations...")
        
        # Gerar variações do título
        title_variations = []
        
        # Variação 1: Remover tags técnicas (NF, DDP5, TURC, etc.)
        clean_title = re.sub(r'\b(NF|DDP5|TURC|DDP|WEB|FW|MULTI)\b', '', title, flags=re.IGNORECASE)
        clean_title = re.sub(r'\s+', ' ', clean_title).strip()
        if clean_title and clean_title != title:
            title_variations.append(clean_title)
        
        # Variação 2: Remover artigos e preposições
        clean_title = re.sub(r'\b(the|a|an|of|in|on|at|to|for|with|by)\b', '', title, flags=re.IGNORECASE)
        clean_title = re.sub(r'\s+', ' ', clean_title).strip()
        if clean_title and clean_title != title:
            title_variations.append(clean_title)
        
        # Variação 3: Substituir caracteres especiais
        ascii_title = title.replace('ç', 'c').replace('ã', 'a').replace('õ', 'o').replace('á', 'a').replace('é', 'e').replace('í', 'i').replace('ó', 'o').replace('ú', 'u')
        if ascii_title != title:
            title_variations.append(ascii_title)
        
        # Variação 4: Primeira palavra apenas (para títulos muito longos)
        first_word = title.split()[0] if title.split() else ""
        if len(first_word) > 3 and len(title.split()) > 2:
            title_variations.append(first_word)
        
        # Tentar cada variação
        for i, variation in enumerate(title_variations):
            if not variation or len(variation.strip()) < 2:
                continue
                
            log(f"Attempt {i+2}: Trying variation '{variation}'")
            
            # Tentar com ano
            if season and episode:
                imdb_id = search_tv_tmdb_for_imdb(variation, year)
            else:
                imdb_id = search_tmdb_for_imdb(variation, year)
                
            if imdb_id:
                subtitles = search_stremio_subtitles(imdb_id, season, episode)
                if subtitles:
                    log(f"Success with variation '{variation}': {len(subtitles)} subtitles found")
                    return subtitles, imdb_id
            
            # Tentar sem ano se ainda não funcionou
            if year:
                log(f"Trying variation '{variation}' without year")
                if season and episode:
                    imdb_id = search_tv_tmdb_for_imdb(variation, None)
                else:
                    imdb_id = search_tmdb_for_imdb(variation, None)
                    
                if imdb_id:
                    subtitles = search_stremio_subtitles(imdb_id, season, episode)
                    if subtitles:
                        log(f"Success with variation '{variation}' (no year): {len(subtitles)} subtitles found")
                        return subtitles, imdb_id
        
        log("All attempts failed - no subtitles found")
        return [], None
        
    except Exception as e:
        log(f"Error in multi-attempt search: {e}")
        return [], None

def download_subtitle(url, filename):
    """Baixar legenda"""
    try:
        log(f"Downloading subtitle from: {url}")
        
        if not url or not url.startswith('http'):
            log(f"Invalid URL: {url}")
            return None
        
        profile = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
        temp_dir = os.path.join(profile, 'temp')
        
        if not xbmcvfs.exists(temp_dir):
            xbmcvfs.mkdirs(temp_dir)
        
        clean_temp_directory()
        
        progress = xbmcgui.DialogProgress()
        progress.create("Stremio Subs", "Baixando legenda...")
        progress.update(10, "Conectando...")
        
        req = urllib.request.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36')
        
        progress.update(30, "Baixando...")
        
        with urllib.request.urlopen(req, timeout=15) as response:
            content = response.read()
        
        progress.update(60, "Processando...")
        
        text_content = None
        encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
        
        for encoding in encodings:
            try:
                text_content = content.decode(encoding)
                log(f"Successfully decoded with {encoding}")
                break
            except UnicodeDecodeError:
                continue
        
        if text_content is None:
            text_content = content.decode('utf-8', errors='ignore')
            log("Used fallback decoding with errors ignored")
        
        if not text_content.strip():
            log("Downloaded content is empty")
            progress.close()
            return None
            
        subtitle_markers = ['-->', 'WEBVTT', '[Script Info]', '{\\']
        has_subtitle_content = any(marker in text_content for marker in subtitle_markers)
        
        if not has_subtitle_content and len(text_content) < 100:
            log("Downloaded content doesn't appear to be a valid subtitle")
            progress.close()
            return None
        
        progress.update(80, "Salvando...")
        
        filepath = os.path.join(temp_dir, filename)
        
        try:
            file_handle = xbmcvfs.File(filepath, 'w')
            file_handle.write(text_content.encode('utf-8'))
            file_handle.close()
            log(f"Subtitle saved using xbmcvfs: {filepath}")
        except Exception as e:
            log(f"Error with xbmcvfs, trying standard file operations: {e}")
            try:
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(text_content)
                log(f"Subtitle saved using standard file operations: {filepath}")
            except Exception as e2:
                log(f"Error with standard file operations: {e2}")
                progress.close()
                return None
        
        progress.update(100, "Concluído!")
        progress.close()
        
        # Verificar se o arquivo foi criado
        if xbmcvfs.exists(filepath):
            log(f"File exists and download successful: {filepath}")
            return filepath
        else:
            log("File was not created successfully")
            return None
        
    except Exception as e:
        log(f"Error downloading subtitle: {e}")
        try:
            progress.close()
        except:
            pass
        return None

def search_subtitles():
    """Função principal de busca - COM FILTRO POR IDIOMA"""
    try:
        log("=== Starting subtitle search with language filter ===")
        
        # Verificar se é uma ação de configuração de idioma
        try:
            params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
            action = params.get('action', '')
            
            if action == 'select_language':
                log("Language selection requested")
                show_language_selection()
                return
        except:
            pass
        
        # ADICIONAR OPÇÃO DE CONFIGURAÇÃO DE IDIOMA NO TOPO
        current_pref = get_stored_preference()
        pref_names = {
            'auto': 'Todos os Idiomas',
            'pt': 'Apenas Português (Portugal)',
            'pt-BR': 'Apenas Português Brasil',
            'es': 'Apenas Español',
            'ro': 'Apenas Română'
        }
        current_name = pref_names.get(current_pref, 'Todos os Idiomas')
        
        # Item de configuração de idioma
        config_item = xbmcgui.ListItem(
            label=f"⚙️ FILTRO DE IDIOMA",
            label2=f"Atual: {current_name} - Clique para alterar"
        )
        config_item.setProperty("sync", "false")
        config_item.setProperty("hearing_imp", "false")
        
        config_url = f"plugin://{addon_id}/?action=select_language"
        
        xbmcplugin.addDirectoryItem(
            handle=int(sys.argv[1]), 
            url=config_url, 
            listitem=config_item, 
            isFolder=False
        )
        
        # Separador visual
        separator_item = xbmcgui.ListItem(
            label="─────────────────────────",
            label2="Legendas Disponíveis"
        )
        separator_item.setProperty("sync", "false")
        separator_item.setProperty("hearing_imp", "false")
        
        xbmcplugin.addDirectoryItem(
            handle=int(sys.argv[1]), 
            url="", 
            listitem=separator_item, 
            isFolder=False
        )
        
        # Buscar legendas normalmente
        imdb, season, episode, title, year = get_video_info()
        
        # Se não há IMDB ID, usar busca multi-idioma diretamente
        if not imdb or not imdb.startswith('tt'):
            if title:
                log(f"No IMDB ID found, starting multi-attempt search for: '{title}' ({year})")
                subtitles, imdb = search_with_multiple_attempts(title, year, season, episode)
                
                if not subtitles:
                    log("Multi-attempt search failed - no subtitles found")
                    # Adicionar item informativo
                    listitem = xbmcgui.ListItem(
                        label="❌ Nenhuma legenda encontrada",
                        label2=f"Para o idioma selecionado: {current_name}"
                    )
                    listitem.setProperty("sync", "false")
                    listitem.setProperty("hearing_imp", "false")
                    
                    xbmcplugin.addDirectoryItem(
                        handle=int(sys.argv[1]), 
                        url="", 
                        listitem=listitem, 
                        isFolder=False
                    )
                    return
                else:
                    log(f"Multi-attempt search successful: found {len(subtitles)} subtitles with IMDB {imdb}")
            else:
                log("No title found - cannot search for subtitles")
                # Adicionar item informativo
                listitem = xbmcgui.ListItem(
                    label="❌ ERRO: Título não encontrado",
                    label2="Não foi possível extrair título do arquivo"
                )
                listitem.setProperty("sync", "false")
                listitem.setProperty("hearing_imp", "false")
                
                xbmcplugin.addDirectoryItem(
                    handle=int(sys.argv[1]), 
                    url="", 
                    listitem=listitem, 
                    isFolder=False
                )
                return
        else:
            # Temos IMDB ID, buscar normalmente
            log(f"Searching for IMDB: {imdb}, Season: {season}, Episode: {episode}")
            
            # Buscar legendas (já filtradas por idioma)
            subtitles = search_stremio_subtitles(imdb, season, episode)
            
            # Se não encontrou legendas, tentar busca multi-idioma
            if not subtitles and title:
                log("No subtitles found with IMDB ID, trying multi-attempt search...")
                subtitles, new_imdb = search_with_multiple_attempts(title, year, season, episode)
                if new_imdb and new_imdb != imdb:
                    log(f"Multi-attempt search found different IMDB: {new_imdb} (was {imdb})")
                    imdb = new_imdb  # Atualizar IMDB para exibição
        
        if not subtitles:
            log("No subtitles found in API response")
            # Adicionar item informativo
            listitem = xbmcgui.ListItem(
                label="❌ Nenhuma legenda encontrada",
                label2=f"Para o idioma: {current_name}"
            )
            listitem.setProperty("sync", "false")
            listitem.setProperty("hearing_imp", "false")
            
            xbmcplugin.addDirectoryItem(
                handle=int(sys.argv[1]), 
                url="", 
                listitem=listitem, 
                isFolder=False
            )
            return
        
        log(f"Processing {len(subtitles)} filtered subtitles for display")
        
        # Processar legendas filtradas para exibição
        for i, subtitle in enumerate(subtitles):
            lang = subtitle.get('lang', 'unknown')
            sub_id = subtitle.get('id', str(i))
            sub_url = subtitle.get('url', '')
            
            # Nome de exibição melhorado
            display_name = get_language_display_name(lang)
            
            log(f"Adding filtered subtitle {i}: {display_name} ({lang}) - {sub_id}")
            
            # Criar item da lista
            listitem = xbmcgui.ListItem(
                label=display_name,
                label2=f"Stremio - {sub_id} ({title})"
            )
            
            # Adicionar bandeira como ícone
            flag_path = get_flag_path(lang)
            if flag_path:
                listitem.setArt({'icon': flag_path, 'thumb': flag_path})
                log(f"Flag set for {lang}: {flag_path}")
            
            listitem.setProperty("sync", "false")
            listitem.setProperty("hearing_imp", "false")
            
            # URL para download
            filename = f"sub_{i}_{lang}.srt"
            
            url = f"plugin://{addon_id}/?action=download&url={urllib.parse.quote_plus(sub_url)}&filename={filename}"
            
            xbmcplugin.addDirectoryItem(
                handle=int(sys.argv[1]), 
                url=url, 
                listitem=listitem, 
                isFolder=False
            )
        
        log("=== Filtered subtitle search completed ===")
    
    except Exception as e:
        log(f"ERROR in search_subtitles: {e}")
        import traceback
        log(f"Traceback: {traceback.format_exc()}")

def download_subtitle_action():
    """Ação de download"""
    try:
        log("=== Starting subtitle download ===")
        
        # Obter parâmetros
        params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
        url = urllib.parse.unquote_plus(params.get('url', ''))
        filename = params.get('filename', 'subtitle.srt')
        
        log(f"Download params - URL: {url}, Filename: {filename}")
        
        # Baixar legenda
        filepath = download_subtitle(url, filename)
        
        if filepath:
            log(f"Download successful: {filepath}")
            
            # Criar ListItem com o caminho da legenda
            listitem = xbmcgui.ListItem(label=filename)
            listitem.setPath(filepath)
            
            # Adicionar ao diretório do plugin
            xbmcplugin.addDirectoryItem(
                handle=int(sys.argv[1]), 
                url=filepath, 
                listitem=listitem, 
                isFolder=False
            )
            
            log(f"ListItem created and added for: {filepath}")
            return True
        else:
            log("Download failed")
            return False
            
    except Exception as e:
        log(f"ERROR in download_subtitle_action: {e}")
        import traceback
        log(f"Traceback: {traceback.format_exc()}")
        return False

if __name__ == '__main__':
    try:
        log("=== Stremio Subs FILTERED Addon Started ===")
        log(f"Arguments: {sys.argv}")
        
        # Verificar ação
        try:
            params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
            action = params.get('action', '')
            log(f"Action: {action}")
        except:
            action = ''
            log("No action specified, defaulting to search")
        
        if action == 'download':
            download_subtitle_action()
        elif action == 'select_language':
            show_language_selection()
        else:
            search_subtitles()
            
        xbmcplugin.endOfDirectory(int(sys.argv[1]))
        log("=== FILTERED Addon execution completed ===")
        
    except Exception as e:
        log(f"CRITICAL ERROR in main: {e}")
        import traceback
        log(f"Traceback: {traceback.format_exc()}")
        try:
            xbmcplugin.endOfDirectory(int(sys.argv[1]))
        except:
            pass

