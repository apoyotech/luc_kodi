# -*- coding: utf-8 -*-
import xbmc, xbmcaddon
import sqlite3
from acctmgr.modules import log_utils

char_remov = ["'", ",", ")", "("]

###################### Create Connection ######################
def create_conn(db_file):
    """Create sqlite connection (returns None on failure)."""
    try:
        if not db_file:
            return None
        return sqlite3.connect(db_file, timeout=3)
    except Exception as e:
        log_utils.error(f"Easydebrid_db Connect Failed: {e}")
        return None

#################### Fetch Token ####################
def chk_auth(settings_db, token):
    """Return the stored setting_value for a token from a settings DB.
    Always returns a string (empty if missing/unavailable) and never throws."""
    conn = create_conn(settings_db)
    if not conn:
        return ""
    try:
        with conn:
            cursor = conn.cursor()
            cursor.execute("SELECT setting_value FROM settings WHERE setting_id = ?", (token,))
            row = cursor.fetchone()
            cursor.close()
        chk_val = "" if not row else str(row[0])
    except Exception as e:
        log_utils.error(f"Easydebrid_db Read Failed: {e}")
        chk_val = ""
    finally:
        try:
            conn.close()
        except Exception:
            pass
    for char in char_remov:
        chk_val = chk_val.replace(char, "")
    return chk_val

