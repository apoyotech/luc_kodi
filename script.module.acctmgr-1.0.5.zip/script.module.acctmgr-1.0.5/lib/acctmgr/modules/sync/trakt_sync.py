# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcaddon, xbmcvfs
import os
import time
import json

from acctmgr.modules import var
from acctmgr.modules import control
from acctmgr.modules import log_utils
from acctmgr.modules.db import chk_auth_db
from acctmgr.modules.db import trakt_db

# Variables
joinPath = os.path.join
exists = xbmcvfs.exists
translatePath = xbmcvfs.translatePath
addon_id = xbmcaddon.Addon().getAddonInfo('id')
addon = xbmcaddon.Addon(addon_id)
addoninfo = addon.getAddonInfo

# Sync Helpers
def refresh_sync(mode, chk_auth, token):
    if mode == "auth":
        return True
    return chk_auth != str(token)

def authorize(mode):
    return mode == "auth"

class Auth:
    def am_trakt(self):
        acctmgr = xbmcaddon.Addon("script.module.acctmgr")
        your_token = acctmgr.getSetting("trakt.token")
        your_username = acctmgr.getSetting("trakt.username")
        your_refresh = acctmgr.getSetting("trakt.refresh")
        your_expires = acctmgr.getSetting("trakt.expires")
        try:
            your_expires_int = int(float(your_expires or 0))
        except Exception as e:
            log_utils.error(f"Error converting trakt.expires: {e}")
            your_expires_int = 0
        return your_token, your_username, your_refresh, str(your_expires_int)

    def trakt_auth(self, mode="refresh"):
        your_token, your_username, your_refresh, your_expires = self.am_trakt()
        master_token = your_token

        if not exists(var.tk_sync_list):
            return

        try:
            with open(var.tk_sync_list, "r") as synclist:
                current = json.load(synclist)["addon_list"]
        except Exception as e:
            log_utils.error(f"Error reading sync list: {e}")
            return

        # ===================== Copy Addon Data (settings.xml) =====================
        addons = (
            ("Shadow",      var.chk_shadow, var.shadow_ud,  var.chkset_shadow,  var.shadow),
            ("Ghost",       var.chk_ghost,  var.ghost_ud,   var.chkset_ghost,   var.ghost),
            ("Homelander",  var.chk_home,   var.home_ud,    var.chkset_home,    var.home),
            ("Nightwing",   var.chk_night,  var.night_ud,   var.chkset_night,   var.night),
            ("Absolution",  var.chk_absol,  var.absol_ud,   var.chkset_absol,   var.absol),
            ("The Crew",    var.chk_crew,   var.crew_ud,    var.chkset_crew,    var.crew),
            ("Scrubs V2",   var.chk_scrubs, var.scrubs_ud,  var.chkset_scrubs,  var.scrubs),
            ("TMDb Helper", var.chk_tmdbh,  var.tmdbh_ud,   var.chkset_tmdbh,   var.tmdbh),
            ("Trakt",       var.chk_trakt,  var.trakt_ud,   var.chkset_trakt,   var.trakt),
        )

        for name, chk_addon, ud_path, chk_setting, base_path in addons:
            try:
                control.copy_addon_settings(name, chk_addon, ud_path, chk_setting, base_path)
            except Exception as e:
                log_utils.error(f"Error copying settings for {name}: {e}")
                
        # ========================= Fen Light =========================
        try:
            if "Fen Light" in current and exists(var.chk_fenlt):
                if not exists(var.chkset_fenlt):
                    control.remake_settings(var.fenlt_id, var.fenlt_name)
                    xbmc.sleep(500)
                    
                if exists(var.chkset_fenlt):
                    settings_db = var.fenlt_settings_db
                    chk_auth = chk_auth_db.chk_auth(settings_db, "trakt.token")
                    
                    if refresh_sync(mode, chk_auth, master_token):
                        trakt_db.auth(settings_db)
                        control.remake_settings(var.fenlt_id, var.fenlt_name)
                        
                        if authorize(mode):
                            xbmc.sleep(300)
                            control.remake_trakt_cache(var.fenlt_id, var.fenlt_name)
        except Exception as e:
            log_utils.error(f"Fen Light Trakt Failed: {e}")
    
        # ========================= Gears =========================
        try:
            if "Gears" in current and exists(var.chk_gears):
                if not exists(var.chkset_gears):
                    control.remake_settings(var.gears_id, var.gears_name)
                    xbmc.sleep(500)
                    
                if exists(var.chkset_gears):
                    settings_db = var.gears_settings_db
                    chk_auth = chk_auth_db.chk_auth(settings_db, "trakt.token")
                    
                    if refresh_sync(mode, chk_auth, master_token):
                        trakt_db.auth(settings_db)
                        control.remake_settings(var.gears_id, var.gears_name)
                        
                        if authorize(mode):
                            xbmc.sleep(300)
                            control.remake_trakt_cache(var.gears_id, var.gears_name)
        except Exception as e:
            log_utils.error(f"Gears Trakt Failed: {e}")

        # ========================= Umbrella =========================
        try:
            if "Umbrella" in current and exists(var.chk_umb) and exists(var.chkset_umb):
                addon = xbmcaddon.Addon("plugin.video.umbrella")
                chk_auth = addon.getSetting("trakt.user.token")
                if refresh_sync(mode, chk_auth, master_token):
                    with open(var.path_umb, "r") as f:
                        data = f.read()
                    if var.umb_client in data:
                        data = data.replace(var.umb_client, var.client_am).replace(var.umb_secret, var.secret_am)
                        with open(var.path_umb, "w") as f:
                            f.write(data)
                    for k, v in {
                        "trakt.user.name": your_username,
                        "trakt.user.token": your_token,
                        "trakt.refreshtoken": your_refresh,
                        "trakt.token.expires": your_expires,
                        "trakt.isauthed": "true",
                        "indicators": "Trakt",
                        "trakt.scrobble": "true",
                        "resume.source": "1",
                    }.items():
                        addon.setSetting(k, v)
        except Exception as e:
            log_utils.error(f"Umbrella Trakt Failed: {e}")

        # ========================= Seren =========================
        try:
            if "Seren" in current and exists(var.chk_seren) and exists(var.chkset_seren):
                addon = xbmcaddon.Addon("plugin.video.seren")
                chk_auth = addon.getSetting("trakt.auth")
                if refresh_sync(mode, chk_auth, master_token):
                    with open(var.path_seren, "r") as f:
                        data = f.read()
                    if var.seren_client in data:
                        data = data.replace(var.seren_client, var.client_am).replace(var.seren_secret, var.secret_am)
                        with open(var.path_seren, "w") as f:
                            f.write(data)
                    your_expires_str = str(int(float(your_expires)))
                    for k, v in {
                        "trakt.auth": your_token,
                        "trakt.username": your_username,
                        "trakt.refresh": your_refresh,
                        "trakt.expires": your_expires_str,
                    }.items():
                        addon.setSetting(k, v)
        except Exception as e:
            log_utils.error(f"Seren Trakt Failed: {e}")

        # ========================= Fen =========================
        try:
            if "Fen" in current and exists(var.chk_fen) and exists(var.chkset_fen):
                addon = xbmcaddon.Addon("plugin.video.fen")
                chk_auth = addon.getSetting("trakt.token")
                if refresh_sync(mode, chk_auth, master_token):
                    with open(var.path_fen, "r") as f:
                        data = f.read()
                    if var.fen_client in data:
                        data = data.replace(var.fen_client, var.client_am).replace(var.fen_secret, var.secret_am)
                        with open(var.path_fen, "w") as f:
                            f.write(data)
                    for k, v in {
                        "trakt.token": your_token,
                        "trakt.user": your_username,
                        "trakt.refresh": your_refresh,
                        "trakt.expires": your_expires,
                        "trakt.indicators_active": "true",
                        "watched_indicators": "1",
                    }.items():
                        addon.setSetting(k, v)
                    if authorize(mode):
                        control.remake_fen_trakt_cache()
        except Exception as e:
            log_utils.error(f"Fen Trakt Failed: {e}")

        # ========================= POV =========================
        try:
            if "POV" in current and exists(var.chk_pov) and exists(var.chkset_pov):
                addon = xbmcaddon.Addon("plugin.video.pov")
                chk_auth = addon.getSetting("trakt.token")
                if refresh_sync(mode, chk_auth, master_token):
                    for k, v in {
                        "trakt.client_id": var.client_am,
                        "trakt.client_secret": var.secret_am,
                        "trakt.token": your_token,
                        "trakt_user": your_username,
                        "trakt.refresh": your_refresh,
                        "trakt.expires": your_expires,
                        "trakt_indicators_active": "true",
                        "watched_indicators": "1",
                    }.items():
                        addon.setSetting(k, v)
                    control.remake_pov_settings()
                    xbmc.sleep(500)
                    control.remake_pov_trakt_cache()
        except Exception as e:
            log_utils.error(f"POV Trakt Failed: {e}")
            
        # ============ The Coalition / Dradis / Genocide ============
        addons = [
            ("The Coalition", "plugin.video.coalition", var.chk_coal, var.chkset_coal),
            ("Dradis",        "plugin.video.dradis",    var.chk_dradis, var.chkset_dradis),
            ("Genocide",      "plugin.video.genocide",  var.chk_genocide, var.chkset_genocide),
        ]
        for name, plugin, chk_addon, chk_setting in addons:
            try:
                if name in current and exists(chk_addon) and exists(chk_setting):
                    addon = xbmcaddon.Addon(plugin)
                    chk_auth = addon.getSetting("trakt.token")
                    if refresh_sync(mode, chk_auth, master_token):
                        expires = int(time.time() + (8 * 86400))
                        for k, v in {
                            "trakt.client_id": var.client_am,
                            "trakt.client_secret": var.secret_am,
                            "trakt.username": your_username,
                            "trakt.token": your_token,
                            "trakt.refresh": your_refresh,
                            "trakt.expires": str(expires),
                            "trakt.isauthed": "true",
                        }.items():
                            addon.setSetting(k, v)
            except Exception as e:
                log_utils.error(f"{name} Trakt Failed: {e}")

        # ========================= Shadow / Ghost =========================
        addons = [
            ("Shadow", "plugin.video.shadow", var.chk_shadow, var.shadow_ud, var.chkset_shadow, var.shadow),
            ("Ghost",  "plugin.video.ghost",  var.chk_ghost,  var.ghost_ud,  var.chkset_ghost,  var.ghost),
        ]

        for name, plugin, chk_addon, ud_path, chk_setting, base_path in addons:
            try:
                if name in current and exists(chk_addon):
                    addon = xbmcaddon.Addon(plugin)
                    chk_auth = addon.getSetting("trakt_access_token")
                    if refresh_sync(mode, chk_auth, master_token):
                        for k, v in {
                            "trakt_access_token": your_token,
                            "trakt_refresh_token": your_refresh,
                            "trakt_expires_at": your_expires,
                        }.items():
                            addon.setSetting(k, v)
            except Exception as e:
                log_utils.error(f"{name} Trakt Failed: {e}")

        # ============= Homelander / Nightwing / Jokers Absolution =============
        addons = [
            ("Homelander",        "plugin.video.homelander", var.chk_home,  var.home_ud,  var.chkset_home,  var.home),
            ("Nightwing",         "plugin.video.nightwing",  var.chk_night, var.night_ud, var.chkset_night, var.night),
            ("Jokers Absolution", "plugin.video.absolution", var.chk_absol, var.absol_ud, var.chkset_absol, var.absol),
        ]

        for name, plugin, chk_addon, ud_path, chk_setting, base_path in addons:
            try:
                if name in current and exists(chk_addon):
                    addon = xbmcaddon.Addon(plugin)
                    chk_auth = addon.getSetting("trakt.token")
                    if refresh_sync(mode, chk_auth, master_token):
                        for k, v in {
                            "trakt.user": your_username,
                            "trakt.token": your_token,
                            "trakt.refresh": your_refresh,
                            "trakt.authed": "yes",
                            "trakt.client_id": var.client_am,
                            "trakt.client_secret": var.secret_am,
                        }.items():
                            addon.setSetting(k, v)
            except Exception as e:
                log_utils.error(f"{name} Trakt Failed: {e}")

        # ========================= The Crew =========================
        try:
            if "The Crew" in current:
                if exists(var.chk_crew) and exists(var.chkset_crew):
                    addon = xbmcaddon.Addon("plugin.video.thecrew")
                    chk_auth = addon.getSetting("trakt.token")
                    if refresh_sync(mode, chk_auth, master_token):
                        with open(var.path_crew, "r") as f:
                            data = f.read()
                        if var.crew_client in data:
                            data = data.replace(var.crew_client, var.client_am).replace(var.crew_secret, var.secret_am)
                            with open(var.path_crew, "w") as f:
                                f.write(data)
                        for k, v in {
                            "trakt.user": your_username,
                            "trakt.token": your_token,
                            "trakt.refresh": your_refresh,
                        }.items():
                            addon.setSetting(k, v)
        except Exception as e:
            log_utils.error(f"The Crew Trakt Failed: {e}")

        # ========================= Scrubs V2 =========================
        try:
            if "Scrubs V2" in current:
                if exists(var.chk_scrubs) and exists(var.chkset_scrubs):
                    addon = xbmcaddon.Addon("plugin.video.scrubsv2")
                    chk_auth = addon.getSetting("trakt.token")
                    if refresh_sync(mode, chk_auth, master_token):
                        with open(var.path_scrubs, "r") as f:
                            data = f.read()
                        if var.scrubs_client in data:
                            data = data.replace(var.scrubs_client, var.client_am).replace(var.scrubs_secret, var.secret_am)
                            with open(var.path_scrubs, "w") as f:
                                f.write(data)
                        for k, v in {
                            "trakt.user": your_username,
                            "trakt.token": your_token,
                            "trakt.refresh": your_refresh,
                            "trakt.authed": "yes",
                        }.items():
                            addon.setSetting(k, v)
        except Exception as e:
            log_utils.error(f"Scrubs V2 Trakt Failed: {e}")

        # ========================= TMDb Helper =========================
        try:
            if "TMDb Helper" in current and exists(var.chk_tmdbh):
                    addon = xbmcaddon.Addon("plugin.video.themoviedb.helper")
                    chk_auth = addon.getSetting("trakt_token")

                    if refresh_sync(mode, chk_auth, master_token):
                        with open(var.path_tmdbh, "r") as f:
                            data = f.read()
                        if var.tmdbh_client in data:
                            data = data.replace(var.tmdbh_client, var.client_am).replace(var.tmdbh_secret, var.secret_am)
                            with open(var.path_tmdbh, "w") as f:
                                f.write(data)

                        expires_int = int(float(your_expires or 0))
                        tmdbh_data = (
                            '{"access_token":"%s","token_type":"bearer",'
                            '"expires_in":7776000,"refresh_token":"%s",'
                            '"scope":"public","created_at":%s}'
                            % (your_token, your_refresh, expires_int)
                        )

                        addon.setSettingString("trakt_token", tmdbh_data)
                        addon.setSetting("startup_notifications", "false")
        except Exception as e:
            log_utils.error(f"TMDBh Trakt Failed: {e}")

        # ========================= Trakt Addon =========================
        try:
            if "Trakt Addon" in current and exists(var.chk_trakt) and exists(var.chkset_trakt):
                addon = xbmcaddon.Addon("script.trakt")
                chk_auth = addon.getSetting("trakt_token")

                if refresh_sync(mode, chk_auth, master_token):
                    with open(var.path_trakt, "r") as f:
                        data = f.read()
                    if var.trakt_client in data:
                        data = data.replace(var.trakt_client, var.client_am).replace(var.trakt_secret, var.secret_am)
                        with open(var.path_trakt, "w") as f:
                            f.write(data)

                    expires_int = int(float(your_expires or 0))
                    trakt_data = (
                        '{"access_token":"%s","token_type":"bearer",'
                        '"expires_in":7776000,"refresh_token":"%s",'
                        '"scope":"public","created_at":%s}'
                        % (your_token, your_refresh, expires_int)
                    )

                    addon.setSetting("user", your_username)
                    addon.setSetting("authorization", trakt_data)
        except Exception as e:
            log_utils.error(f"Trakt Addon Trakt Failed: {e}")
