# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — awards.py (v2.0.04)

	Oscar a la mejor pelicula: ganadoras y nominadas, con su id de TMDb.

	Antes salian de una busqueda de IMDb (groups=oscar_best_picture_winners)
	leida con el maquetado viejo de IMDb, que ya no existe. TMDb no tiene un
	filtro de premios, asi que la lista sale de Wikidata, que si los guarda y
	trae el id de TMDb de cada pelicula. El resto (titulo, poster, sinopsis...)
	lo pone TMDb como en cualquier otra lista.

	Wikidata:
	  Q102427  Academy Award for Best Picture
	  P166     award received        -> ganadoras
	  P1411    nominated for         -> nominadas
	  P585     point in time         -> ano de la ceremonia (calificador)
	  P577     publication date      -> si falta el anterior
	  P4947    TMDB movie ID
"""

from json import loads as jsloads
from urllib.parse import urlencode

SPARQL = 'https://query.wikidata.org/sparql'
BEST_PICTURE = 'Q102427'
_PROP = {'winners': 'P166', 'nominees': 'P1411'}
# Wikidata pide un User-Agent que identifique al cliente.
_HEADERS = {'User-Agent': 'plugin.video.luc_kodi (Kodi add-on; https://github.com/apoyotech/luc_repo)',
	'Accept': 'application/sparql-results+json'}

_QUERY = '''SELECT ?tmdb (MAX(YEAR(?d)) AS ?year) WHERE {
  ?film p:%(prop)s ?st .
  ?st ps:%(prop)s wd:%(award)s .
  ?film wdt:P4947 ?tmdb .
  OPTIONAL { ?st pq:P585 ?d1 }
  OPTIONAL { ?film wdt:P577 ?d2 }
  BIND(COALESCE(?d1, ?d2) AS ?d)
}
GROUP BY ?tmdb
ORDER BY DESC(?year)'''


def query_url(kind):
	prop = _PROP.get(kind, _PROP['winners'])
	return '%s?%s' % (SPARQL, urlencode({'format': 'json', 'query': _QUERY % {'prop': prop, 'award': BEST_PICTURE}}))


def parse(result):
	"""JSON de Wikidata -> [(tmdb, ano)], de la ceremonia mas reciente a la
	mas antigua, sin repetidos y solo con ids numericos."""
	out, seen = [], set()
	try: rows = result['results']['bindings']
	except Exception: return out
	for row in rows:
		try:
			tmdb = str(row['tmdb']['value']).strip()
			if not tmdb.isdigit() or tmdb in seen: continue
			seen.add(tmdb)
			year = str(row.get('year', {}).get('value', '') or '')[:4]
			out.append((tmdb, year))
		except Exception: continue
	return out


def best_picture(kind='winners'):
	"""Lista entera (unas 100 ganadoras, unas 600 nominadas). La cachea quien
	la llama: cambia una vez al ano."""
	from resources.lib.modules.client import _basic_request
	result = _basic_request(query_url(kind), headers=dict(_HEADERS), timeout='30')
	if not result: return None
	try: return parse(jsloads(result))
	except Exception:
		from resources.lib.modules import log_utils
		log_utils.error()
		return None


def page(full, page_no, limit):
	"""Trozo de la lista para la pagina pedida y si hay otra detras."""
	try: page_no = max(1, int(page_no))
	except Exception: page_no = 1
	try: limit = max(1, int(limit))
	except Exception: limit = 20
	full = full or []
	start = (page_no - 1) * limit
	return full[start:start + limit], (start + limit) < len(full)
