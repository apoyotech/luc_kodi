# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Sync windows (v2.0.15). Sync credentials with your devices and Premiere
	Lists > Sync your devices open in the context panel sheet (windows/sync_panel.py)
	when Context menu style is the luc_kodi panel; with the classic style, or if
	the panel cannot open, Kodi's own dialogs are used, as before.

	choose() -> the key of the row, BACK or None
	check()  -> the ticked keys, BACK or None
	wait()   -> what poll() returned, BACK or None
	BACK only comes from the panel (its Back key or button): the caller goes one
	step back. None means stop: Kodi dialog cancelled, time out, or Home pressed
	(Home already took the user to the luc_kodi main menu).
"""

import time
import xbmc
from resources.lib.modules import control
from resources.lib.modules import log_utils

BACK = '__back__'
HEADER_ICON = 'DefaultNetwork.png'
GREY = 'ff9e9e9e'
getLS = control.lang


def modern():
	try:
		from resources.lib.modules import context_hub
		return context_hub.is_modern()
	except Exception:
		return False


def crumb(*parts):
	from resources.lib.modules.context_hub import CHEVRON
	return ('  %s  ' % CHEVRON).join([p for p in parts if p])


def _header(title, crumb_text, meta):
	try: version = 'v%s' % control.addon('plugin.video.luc_kodi').getAddonInfo('version')
	except Exception: version = ''
	inside = xbmc.getInfoLabel('Container.PluginName') == 'plugin.video.luc_kodi'
	return {'poster': HEADER_ICON, 'artkind': 'icon', 'title': title, 'meta': meta or '', 'crumb': crumb_text or '',
			'back': getLS(48130), 'home': getLS(48132) if inside else '', 'version': version}


def _open(mode, title, crumb_text, meta, hint, **kwargs):
	"""The panel, or the exception that sends the caller to Kodi's dialogs."""
	from resources.lib.windows.sync_panel import SyncPanelXML
	window = SyncPanelXML('sync_panel.xml', control.addonPath(control.addonId()), mode=mode,
						  header=_header(title, crumb_text, meta), hint=hint, **kwargs)
	try: chosen = window.run()
	finally: del window
	control.sleep(80)  # let the panel finish closing before the next window takes focus
	if chosen == '__home__':
		from resources.lib.modules import navstate
		navstate.go_home()
		return None
	return chosen


def _classic_label(row):
	return row.get('classic') or row.get('label', '')


def choose(title, rows, crumb_text='', meta='', hint=None):
	"""rows: dicts with key, label, hint, icon, color, tile, logo, more, kind (header|action),
	classic (label for Kodi's list, by default label)."""
	if modern():
		try: return _open('menu', title, crumb_text, meta, getLS(48120) if hint is None else hint, rows=rows)
		except Exception: log_utils.error()
	acts = [r for r in rows if r.get('kind') != 'header' and not r.get('disabled')]
	pick = control.selectDialog([_classic_label(r) for r in acts], heading=title)
	return acts[pick]['key'] if 0 <= pick < len(acts) else None


def check(title, rows, checked, go_row, all_labels=None, crumb_text='', meta='', classic_heading=None):
	"""Rows to tick. go_row(count) -> (label, hint) of the first row, the one that confirms.
	Kodi's dialog shows each row with its art ('art', a full path) and its hint."""
	if modern():
		try:
			return _open('check', title, crumb_text, meta, getLS(32813), rows=rows, checked=checked,
						 go_row=go_row, all_labels=all_labels)
		except Exception: log_utils.error()
	acts = [r for r in rows if r.get('kind') != 'header']
	items = []
	for r in acts:
		li = control.item(label=_classic_label(r), label2=r.get('hint', ''), offscreen=True)
		if r.get('art'): li.setArt({'icon': r['art'], 'thumb': r['art']})
		items.append(li)
	pre = [i for i, r in enumerate(acts) if r['key'] in set(checked or [])]
	heading = classic_heading or title
	try: chosen = control.dialog.multiselect(heading, items, preselect=pre, useDetails=True)
	except TypeError: chosen = control.dialog.multiselect(heading, [i.getLabel() for i in items])
	return [acts[i]['key'] for i in chosen] if chosen else None


def _left(seconds):
	return getLS(32808) % ('%d:%02d' % (seconds // 60, seconds % 60))


def wait(title, poll, seconds, big='', text='', crumb_text='', meta='', classic_text=None):
	"""Waits until poll() returns something other than None (checked every half
	second) or the time runs out. poll() may return {'update': True, 'text': ...}
	to change the text while it waits. classic_text(big, text) -> the text of
	Kodi's progress dialog."""
	if modern():
		try:
			res = _open('wait', title, crumb_text, meta, getLS(32814), poll=poll, seconds=seconds,
						wait={'big': big, 'text': text, 'btn': getLS(32809), 'left': _left})
			return None if res in ('__timeout__', '__error__') else res
		except Exception: log_utils.error()
	pd = control.progressDialog
	pd.create(title)
	try:
		end = time.time() + seconds
		while True:
			left = end - time.time()
			if left <= 0: return None
			body = classic_text(big, text) if classic_text else '\n'.join([x for x in (big, text) if x])
			pd.update(int(left * 100 / seconds), body)
			if pd.iscanceled(): return None
			res = poll()
			if isinstance(res, dict) and res.get('update'):
				big, text = res.get('big', big), res.get('text', text)
				res = None
			if res is not None: return res
			if control.monitor.waitForAbort(0.5): return None
	finally: pd.close()
