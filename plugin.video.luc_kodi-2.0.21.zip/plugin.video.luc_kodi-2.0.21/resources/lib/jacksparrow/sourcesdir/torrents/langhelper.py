# -*- coding: utf-8 -*-
"""
	jacksparrowscrapers Project

	v2.0.08 langhelper: ayudante de busqueda para los titulos que el usuario
	abre desde Movies > Languages y TV Shows > Languages, en todos los idiomas
	de esas listas salvo el ingles (sin anime).

	Solo se lanza cuando sources.py le pasa data['lang_assist'] (el titulo esta
	registrado por modules/lang_assist.py); en cualquier otra busqueda ni
	siquiera se crea su hilo.

	Que hace distinto del resto:
	- busca por los titulos alternativos de TMDb (original, el del pais de
	  origen, los romanizados) y no solo por el titulo ingles;
	- compara transliterando (Kizil = Kızıl, Lodz = Łódź) y acepta el titulo
	  original en su escritura (kanji, hangul, cirilico, arabe, devanagari);
	- entiende la numeracion de estas releases: S01E05, E05/EP05, 05. Bolum,
	  第05集, 5화/5회, "Temporada 2", "Staffel 2", "Folge 5", "5 серия",
	  numeros absolutos ("45. Bolum" para la 2x10) y rangos;
	- no descarta la release por llevar el idioma original en el nombre
	  (TURKISH, FRENCH, CASTELLANO...), que es justo lo que se busca. Si
	  descarta los doblajes a un tercer idioma cuando el filtro de audio
	  extranjero esta activo.

	Fuentes: Knaben (agrega muchos trackers publicos) y The Pirate Bay, con
	las mismas peticiones que ya usan knaben.py y piratebay.py. Todo pasa
	despues por la comprobacion de cache del debrid como cualquier torrent.
"""

import re
from html import unescape as _html_unescape
from json import loads as jsloads
from urllib.parse import quote, quote_plus, unquote_plus
from resources.lib.jacksparrow import client
from resources.lib.jacksparrow import log_utils
from resources.lib.jacksparrow import source_utils
from resources.lib.jacksparrow import workers
from resources.lib.jacksparrow.control import setting as getSetting
from resources.lib.modules import lang_assist

PROVIDER = 'langhelper'
APIBAY = 'https://apibay.org/q.php?q=%s&cat=0'
KNABEN_TV = '/search/index.php?cat=002000000&q={0}&search=fast'
KNABEN_MOVIE = '/search/index.php?cat=003000000&q={0}&search=fast'
NO_HASH = '0' * 40

# Lo que puede seguir al titulo en un nombre de release sin que sea OTRO titulo
# ("Love" no debe casar con "Love Next Door").
# v2.0.08: palabra EXACTA (antes valia el prefijo y "Love" casaba con "Love
# Submarine" por 'sub'); solo las marcas tecnicas van como prefijo.
_TAG_WORDS = ('ep', 'eps', 'episode', 'episodes', 'bolum', 'bolumler', 'season', 'sezon', 'complete', 'end', 'fin', 'full', 'final',
	'uncut', 'special', 'vol', 'part', 'web', 'webrip', 'webdl', 'hdtv', 'bluray', 'bdrip', 'brrip', 'dvdrip', 'hdrip', 'hevc', 'avc',
	'multi', 'dual', 'tr', 'eng', 'english', 'sub', 'subs', 'subbed', 'hardsub', 'softsub', 'repack', 'proper', 'internal', 'limited',
	'extended', 'remastered', 'amzn', 'nf', 'dsnp', 'hmax', 'max', 'viki', 'iqiyi', 'wetv', 'youku', 'mgtv', 'tving', 'wavve', 'coupang',
	'disney', 'netflix', 'kdrama', 'cdrama', 'jdrama', 'drama', 'dizi', 'tv', 'series', 'mini', '4k', 'uhd', 'fhd', 'hd', 'aac', 'ddp',
	'dd', 'dts', 'atmos', 'hdr', 'dv', 'batch', 'temporada', 'saison', 'staffel', 'stagione', 'sezonul', 'sesong', 'sasong', 'kausi',
	'seizoen', 'episodio', 'capitulo', 'cap', 'folge', 'odcinek', 'aflevering', 'jakso', 'avsnitt', 'integrale', 'komplett', 'completa',
	'completo', 'kompletna', 'vostfr', 'subita', 'nordic')
_TAG_AFTER_TITLE = re.compile(
	r'^(?:(?:s|e|ep|sp|x26|h26|ddp?|aac|dts)\d|10bit|(?:%s)$)' % '|'.join(sorted(set(_TAG_WORDS) | lang_assist.LANGUAGE_WORDS, key=len, reverse=True)))

_YEAR = re.compile(r'(?<![0-9])(19[0-9]{2}|20[0-9]{2})(?![0-9])')
_SXE = re.compile(r'(?<![a-z0-9])s(\d{1,2})[ ._-]?e(\d{1,4})(?:[ ._]?[-~][ ._]?(?:s\d{1,2})?e?(\d{1,4}))?(?![0-9])')
_SEASON_WORDS = r'(?:season|sezon|temporada|saison|staffel|stagione|sezonul|sesong|sasong|kausi|seizoen|сезон)'
_SEASON_RANGE = (
	re.compile(r'(?<![a-z0-9])(?:seasons?|sezon|temporadas?|saison|staffel|сезон)[ ._:]*(\d{1,2})[ ._]?[-~][ ._]?(\d{1,2})(?![0-9])'),  # Season 1-2, Сезон: 1-2
	re.compile(r'(?<![a-z0-9])s(\d{1,2})[ ._]?[-~][ ._]?s?(\d{1,2})(?![0-9e])'),  # S01-S02, S1-2
	re.compile(r'(?<![a-z0-9])(\d{1,2})[ ._]?[-~][ ._]?(\d{1,2})(?=[ ._:-]*(?:e|ep|episodes?)[ ._-]?\d)'))  # 1-2 E1-80
_SEASON = (re.compile(r'(?<![a-z0-9])s(\d{1,2})(?![0-9e])'),
			re.compile(r'(?<![a-z0-9])' + _SEASON_WORDS + r'[ ._:-]*(\d{1,2})(?![0-9])'),
			re.compile(r'(?<![0-9])(\d{1,2})[ ._-]*\.?[ ._-]*' + _SEASON_WORDS + r'(?![a-z])'), # "3. Sezon" (log 15-oct)
			re.compile(r'(?<![0-9])(\d{1,2})(?:st|nd|rd|th)[ ._-]season'))
_EP_WORDS = r'(?:episodes|episode|episodio|capitulo|folge|odcinek|aflevering|jakso|avsnitt|серии|серия|eps|ep|e)'
_EP = re.compile(r'(?<![a-z0-9])' + _EP_WORDS + r'[ ._:-]{0,2}(\d{1,4})(?:[ ._]?[-~][ ._]?' + _EP_WORDS + r'?[ ._-]?(\d{1,4}))?(?![0-9])')
_EP_AFTER = re.compile(r'(?<![0-9])(\d{1,4})[ ._-]?(?:серия|серии|folge|odcinek|jakso)(?![a-z])')
_BOLUM_RANGE = re.compile(r'(?<![0-9])(\d{1,4})[ ._]?-[ ._]?(\d{1,4})[ ._-]*\.?[ ._-]*bolum')
_BOLUM = (re.compile(r'(?<![0-9])(\d{1,4})[ ._-]*\.?[ ._-]*bolum'), re.compile(r'bolum[ ._-]*(\d{1,4})(?![0-9])'))
_CJK_EP = re.compile(r'第\s*(\d{1,4})\s*(?:[-~至到]\s*(\d{1,4})\s*)?[集话話回]')
_CJK_ALL = re.compile(r'全\s*(\d{1,4})\s*[集话話回]')
_KO_EP = re.compile(r'(?:제\s*)?(?<![0-9])(\d{1,4})\s*[화회](?![a-z0-9])')
_BARE_RANGE = re.compile(r'(?<![a-z0-9.])(\d{1,3})[ ._]?[-~][ ._]?(\d{1,3})(?![0-9.])')
_COMPLETE = re.compile(r'(?<![a-z])(complete|batch|tam|全集|完结|完結)(?![a-z])')
_BARE_LEAD = re.compile(r'^[ ._-]*(\d{1,4})(?![0-9]|p\b|p[ ._-]|bit|k\b|[ ._-]?(?:sezon|season))')
_EPISODE_IN_MOVIE = re.compile(r'(?<![a-z0-9])(s\d{1,2}e\d{1,3}|s\d{1,2}(?![0-9])|ep[ ._-]?\d{1,4}|e\d{2,4})(?![0-9])|bolum|第\s*\d+\s*[集话話回]|' + _SEASON_WORDS)
_LEAD_GROUPS = re.compile(r'^\s*(?:\[[^\]]*\]|【[^】]*】|\([^)]*\)|\{[^}]*\})\s*')



def tidy_name(raw):
	"""v2.0.08: nombre para la lista de fuentes. Fuera saltos de linea y lo que
	no es latino (rutracker pone el titulo ruso delante: "Стамбульская невеста /
	Istanbullu Gelin / Сезон: 1-2..."), sin dejar los separadores huerfanos."""
	t = lang_assist.translit(raw or '')
	t = re.sub(r'[\r\n\t]+', ' ', t)
	t = ''.join(ch if ord(ch) < 128 else ' ' for ch in t)
	t = re.sub(r'\s*/\s*', ' ', t)
	t = re.sub(r'[(\[]\s*[,.;:_\s-]*[)\]]', ' ', t)
	t = re.sub(r'(?:\s*[,;:_]\s*)+', ' ', t)
	t = re.sub(r'(?:\s*\.\s+|\s+\.\s*)+', ' ', t)  # puntos que separaban texto borrado: "Gelin. . .1-2"
	t = re.sub(r'([(\[])[\s.]+', r'\1', t)
	t = re.sub(r'[\s.]+([)\]])', r'\1', t)
	t = re.sub(r'[(\[]\s*[)\]]', ' ', t)
	return re.sub(r'\s+', ' ', t).strip(' .-')


def _strip_groups(raw):
	prev = None
	while prev != raw:
		prev = raw
		raw = _LEAD_GROUPS.sub('', raw, 1)
	return raw


def _low(text):
	text = lang_assist.translit(text).lower().replace('&', ' and ')
	return re.sub(r"['’`]", '', text)


def _first_token(rest):
	m = re.match(r'[^a-z0-9]*([a-z0-9]+)', rest or '')
	return m.group(1) if m else ''


def parse_numbering(rest):
	"""Numeracion de lo que va DETRAS del titulo (ya en minusculas y
	transliterado). Devuelve season (o None), start, end, complete y marker:
	sxe | e | bolum | cjk | ko | bare | season | none."""
	out = {'season': None, 'start': None, 'end': None, 'complete': False, 'marker': 'none', 'seasons': None}
	if not rest: return out
	out['complete'] = bool(_COMPLETE.search(rest))
	# v2.0.08: pack de varias temporadas. "1-2 E1-80" se tomaba por E1-80 sin
	# temporada y se ofrecia para la 3x01 (log 16-oct, Istanbullu Gelin)
	for rx in _SEASON_RANGE:
		m = rx.search(rest)
		if m and int(m.group(2)) > int(m.group(1)):
			out['seasons'] = (int(m.group(1)), int(m.group(2)))
			break
	m = _SXE.search(rest)
	if m:
		a = int(m.group(2))
		b = int(m.group(3)) if m.group(3) else a
		out.update({'season': int(m.group(1)), 'start': a, 'end': b if b >= a else a, 'marker': 'sxe'})
		return out
	# la marca que aparece ANTES en el nombre: en "3. Sezon 64. Bolum" tambien
	# casa "Sezon 64", y la temporada es el 3
	found = [m for m in (rx.search(rest) for rx in _SEASON) if m]
	if found: out['season'] = int(min(found, key=lambda m: m.start()).group(1))
	if out['season'] is None:
		# "Hospital Playlist 2 E05": numero corto suelto delante del episodio
		m = re.match(r'^[ ._-]*(\d{1,2})[ ._-]+' + _EP_WORDS + r'[ ._-]?\d', rest)
		if m: out['season'] = int(m.group(1))
	m = _CJK_EP.search(rest)
	if m:
		a = int(m.group(1)); b = int(m.group(2)) if m.group(2) else a
		out.update({'start': a, 'end': max(a, b), 'marker': 'cjk'})
		return out
	m = _CJK_ALL.search(rest)
	if m:
		out.update({'start': 1, 'end': int(m.group(1)), 'complete': True, 'marker': 'cjk'})
		return out
	m = _BOLUM_RANGE.search(rest)
	if m:
		a, b = int(m.group(1)), int(m.group(2))
		if b > a:
			out.update({'start': a, 'end': b, 'marker': 'bolum'})
			return out
	for rx in _BOLUM:
		m = rx.search(rest)
		if m:
			a = int(m.group(1))
			out.update({'start': a, 'end': a, 'marker': 'bolum'})
			return out
	m = _EP.search(rest)
	if m:
		a = int(m.group(1)); b = int(m.group(2)) if m.group(2) else a
		out.update({'start': a, 'end': b if b >= a else a, 'marker': 'e'})
		return out
	m = _KO_EP.search(rest)
	if m:
		a = int(m.group(1))
		out.update({'start': a, 'end': a, 'marker': 'ko'})
		return out
	m = _EP_AFTER.search(rest)
	if m:
		a = int(m.group(1))
		out.update({'start': a, 'end': a, 'marker': 'e'})
		return out
	if out['complete'] or re.search(r'(?<![a-z])(end|fin)(?![a-z])', rest):
		m = _BARE_RANGE.search(rest)
		if m:
			a, b = int(m.group(1)), int(m.group(2))
			if b > a:
				out.update({'start': a, 'end': b, 'complete': True, 'marker': 'bare'})
				return out
	m = _BARE_LEAD.match(rest)
	if m:
		a = int(m.group(1))
		if not _YEAR.fullmatch(m.group(1)):
			out.update({'start': a, 'end': a, 'marker': 'bare'})
			return out
	if out['season'] is not None: out['marker'] = 'season'
	return out


class source:
	priority = 3
	pack_capable = False # los packs que casan los devuelve sources() junto con los sueltos
	hasMovies = True
	hasEpisodes = True
	languages_only = True # provider_test no lo prueba: sin titulo de Languages no busca

	def __init__(self):
		self.language = ['en']
		try: self.min_seeders = int(getSetting('langhelper.min.seeders') or 0)
		except: self.min_seeders = 0
		self.timeout = 8
		self.query_titles = 2

	# ── titulos ──────────────────────────────────────────────────────────────
	def _title_patterns(self):
		pats = []
		for t in self.latin:
			tokens = lang_assist.norm_latin(t).split()
			if not tokens: continue
			pats.append((len(''.join(tokens)), re.compile(r'^[^a-z0-9]*' + r'[^a-z0-9]+'.join(map(re.escape, tokens)) + r'(?![a-z0-9])')))
		pats.sort(key=lambda x: -x[0]) # el titulo mas largo primero: "Love Next Door" antes que "Love"
		return [p for _, p in pats]

	def match_title(self, raw):
		"""Lo que sigue al titulo en el nombre de la release (minusculas,
		transliterado), o None si la release es de otro titulo."""
		body = _strip_groups(raw or '')
		low = _low(body)
		for pat in self.patterns:
			m = pat.match(low)
			if not m: continue
			rest = low[m.end():]
			first = _first_token(rest)
			if not first or first[0].isdigit() or _TAG_AFTER_TITLE.match(first): return rest
		folded = body.casefold()
		for t in self.native:
			idx = folded.find(t.casefold())
			if idx < 0: continue
			rest = _low(body[idx + len(t):])
			first = _first_token(rest)
			if not first or first[0].isdigit() or _TAG_AFTER_TITLE.match(first): return rest
		return None

	def _foreign_dub(self, rest):
		"""Solo mira lo que va DETRAS del titulo: un titulo en turco o en
		italiano puede llevar palabras que parecen marcas de idioma."""
		if not self.check_foreign_audio: return False
		words = set(re.split(r'[^a-z0-9]+', rest or ''))
		if words & {'multi', 'dual', 'eng', 'english'}: return False
		own = set(lang_assist.ORIGINAL_MARKERS.get(self.lang, ()))
		if words & own: return False
		return bool(words & (lang_assist.DUB_WORDS - own))

	# ── decision por release ─────────────────────────────────────────────────
	def accept_episode(self, num):
		"""(ok, package, lang_season, lang_ep) para la release frente al
		episodio pedido. Los packs solo se aceptan con numeracion SxxEyy, Exx o
		de temporada: es la que el debrid sabe encontrar dentro del torrent."""
		S, E, A = self.season, self.episode, self.absolute
		season, start, end = num['season'], num['start'], num['end']
		# v2.0.08: un pack de varias temporadas no se ofrece. Si no incluye la pedida es
		# otro contenido, y si la incluye no se sabe como numera los ficheros dentro
		if num.get('seasons'): return False, None, None, None
		# v2.0.08: muchas turcas salen como S01Exx aunque TMDb tenga varias
		# temporadas, contando desde el primero ("Uzak Sehir S01E64" es la 3x01):
		# S01 con el numero absoluto vale para cualquier temporada (log 15-oct)
		if season == 1 and S > 1 and A and start is not None and start == end == A: return True, None, None, None
		if season is not None and season != S: return False, None, None, None
		# numeracion de la release: por temporada si la dice o si es la 1, absoluta si no
		target = E if (season is not None or S == 1) else A
		if start is not None:
			if start == end:
				if target and start == target: return True, None, None, None
				# las turcas dicen la temporada y cuentan el capitulo desde el primero:
				# "Yargi 3. Sezon 64. Bolum" es la 3x01 si la 1 y la 2 suman 63
				if season is not None and A and A != E and start == A: return True, None, None, None
				return False, None, None, None
			if num['marker'] not in ('sxe', 'e'): return False, None, None, None
			if target and start <= target <= end: return True, 'season', season or S, target
			return False, None, None, None
		if num['marker'] == 'season' and season == S: return True, 'season', S, E
		if num['complete'] and season is None and self.total_seasons == 1 and S == 1: return True, 'season', 1, E
		return False, None, None, None

	def accept_movie(self, rest):
		if _EPISODE_IN_MOVIE.search(rest): return False
		years = _YEAR.findall(rest)
		if years and self.year:
			try: y = int(self.year)
			except: return True
			return any(abs(int(i) - y) <= 1 for i in years)
		return True

	# ── fuentes ──────────────────────────────────────────────────────────────
	def _knaben(self, query):
		try:
			from resources.lib.jacksparrow.sourcesdir.torrents import knaben
			base = knaben.source().base_link
			link = (KNABEN_TV if self.is_episode else KNABEN_MOVIE).format(quote_plus(query))
			html = client.request('%s%s' % (base, link), timeout=self.timeout)
			if not html: return
			rows = client.parseDOM(html, 'tr', attrs={'class': 'text-nowrap border-start'})
		except:
			source_utils.scraper_error('LANGHELPER')
			return
		for row in rows:
			try:
				columns = re.findall(r'<td.*?>(.+?)</td>', row, re.DOTALL)
				# v2.0.08: solo el magnet del href. Si &dn= era su ultimo parametro, la
				# regex de antes se llevaba tambien el HTML que le sigue en la pagina
				# (<span class="badge...">, con salto de linea) y el nombre salia
				# montado sobre la linea de informacion en source_results.
				m = re.search(r'magnet:\?[^"\'<>]+', columns[1])
				if not m: continue
				url = unquote_plus(_html_unescape(m.group(0).strip()))
				hash_m = re.search(r'btih:([a-zA-Z0-9]{32,40})', url, re.I)
				if not hash_m: continue
				m = re.search(r'&dn=([^&]+)', url)
				name = m.group(1) if m else re.sub(r'<[^>]+>', '', columns[0]).strip()
				name = _html_unescape(name)
				try: seeders = int(columns[4].replace(',', ''))
				except: seeders = 0
				try: dsize, isize = source_utils._size(columns[2].split('<')[0])
				except: dsize, isize = 0, ''
				self.raw.append((name, hash_m.group(1), seeders, dsize, isize))
			except:
				source_utils.scraper_error('LANGHELPER')

	def _apibay(self, query):
		try:
			rjson = client.request(APIBAY % quote(query), timeout=self.timeout)
			if not rjson or rjson.lstrip()[:1] != '[': return
			files = jsloads(rjson)
		except:
			source_utils.scraper_error('LANGHELPER')
			return
		for f in files:
			try:
				hash = f.get('info_hash') or ''
				if not hash or hash == NO_HASH: continue
				try: seeders = int(f.get('seeders') or 0)
				except: seeders = 0
				try: dsize, isize = source_utils.convert_size(float(f.get('size') or 0), to='GB')
				except: dsize, isize = 0, ''
				self.raw.append((_html_unescape(f.get('name') or ''), hash, seeders, dsize, isize))
			except:
				source_utils.scraper_error('LANGHELPER')

	def _queries(self):
		qs = []
		for t in self.latin[:self.query_titles]:
			t = re.sub(r'[^A-Za-z0-9\s\.-]+', ' ', lang_assist.translit(t))
			t = re.sub(r'\s+', ' ', t).strip()
			if not t: continue
			if self.is_episode:
				qs += [t, '%s S%02dE%02d' % (t, self.season, self.episode)]
				if self.absolute and self.absolute != self.episode: qs.append('%s %d' % (t, self.absolute))
				elif self.season == 1: qs.append('%s %d' % (t, self.episode))
			else:
				qs.append('%s %s' % (t, self.year) if self.year else t)
		if self.native:
			qs.append(self.native[0] if self.is_episode or not self.year else '%s %s' % (self.native[0], self.year))
		out = []
		for q in qs:
			if q.lower() not in [x.lower() for x in out]: out.append(q)
		return out

	# ── entrada ──────────────────────────────────────────────────────────────
	def sources(self, data, hostDict):
		results = []
		if not data: return results
		la = data.get('lang_assist')
		if not la or not la.get('tmdb'): return results
		try:
			self.lang = la.get('lang') or ''
			self.is_episode = 'tvshowtitle' in data
			info = lang_assist.titles(la['tmdb'], 'tv' if self.is_episode else 'movie') or {}
			if info.get('animation'):
				log_utils.log('LANGHELPER: tmdb %s is animation, skipped' % la['tmdb'], level=log_utils.LOGDEBUG)
				return results
			main = data['tvshowtitle'] if self.is_episode else data['title']
			self.year = str(data.get('year') or info.get('year') or '')
			latin = [main] + list(info.get('latin') or []) + list(source_utils.aliases_to_array(data.get('aliases') or []) or [])
			self.latin, seen = [], set()
			for t in latin:
				if not lang_assist.is_latin(t): continue
				n = lang_assist.norm_latin(t)
				if n in seen: continue
				seen.add(n); self.latin.append(t)
			self.native = [t for t in (info.get('native') or []) if len(t) >= 2]
			self.patterns = self._title_patterns()
			seasons = info.get('seasons') or {}
			self.total_seasons = len(seasons) or int(data.get('total_seasons') or 0)
			if self.is_episode:
				self.season, self.episode = int(data['season']), int(data['episode'])
				try: tvdb_abs = int(data.get('absolute_episode') or 0)
				except: tvdb_abs = 0
				self.absolute = tvdb_abs or lang_assist.absolute_number(seasons, self.season, self.episode) or (self.episode if self.season == 1 else 0)
			self.check_foreign_audio = source_utils.check_foreign_audio()
			self.undesirables = source_utils.get_undesirables()
			queries = self._queries()
			self.raw = []
			threads = []
			for q in queries:
				threads.append(workers.Thread(self._knaben, q))
				threads.append(workers.Thread(self._apibay, q))
			[i.start() for i in threads]
			[i.join() for i in threads]
			results = self._build()
			log_utils.log('LANGHELPER: %s %s tmdb %s%s: %d queries, %d raw, %d kept' % (
				self.lang, 'tv' if self.is_episode else 'movie', la['tmdb'],
				(' S%02dE%02d (abs %s)' % (self.season, self.episode, self.absolute)) if self.is_episode else '',
				len(queries), len(self.raw), len(results)), level=log_utils.LOGDEBUG)
			if self.rejected:
				log_utils.log('LANGHELPER: right title, wrong episode or year (sample): %s' % ' | '.join(self.rejected), level=log_utils.LOGDEBUG)
			if not results and self.other_titles:
				log_utils.log('LANGHELPER: nothing kept; titles searched %s; other titles found (sample): %s' % (
					' / '.join(self.latin[:3] + self.native[:1]), ' | '.join(self.other_titles)), level=log_utils.LOGDEBUG)
			return results
		except:
			source_utils.scraper_error('LANGHELPER')
			return results

	def _build(self):
		results, seen = [], set()
		self.rejected = [] # titulo correcto, numeracion u otra cosa no: para el log de depuracion
		self.other_titles = [] # lo que trajo la busqueda y no casa con ningun titulo
		main = self.latin[0] if self.latin else ''
		self.latin_norms = [n for n in (lang_assist.norm_latin(t) for t in self.latin) if n]
		for raw, hash, seeders, dsize, isize in self.raw:
			try:
				h = hash.lower()
				if h in seen: continue
				if self.min_seeders > seeders: continue
				# v2.0.08: el porno comparte titulos ("Family Secrets 2015 XXX"); fuera siempre
				if re.search(r'(?<![a-z0-9])xxx(?![a-z0-9])', raw.lower()): continue
				rest = self.match_title(raw)
				if rest is None:
					if len(self.other_titles) < 4: self.other_titles.append(raw[:70])
					continue
				package = lang_season = lang_ep = None
				if self.is_episode:
					ok, package, lang_season, lang_ep = self.accept_episode(parse_numbering(rest))
					if not ok:
						if len(self.rejected) < 6: self.rejected.append(raw[:90])
						continue
				elif not self.accept_movie(rest):
					if len(self.rejected) < 6: self.rejected.append(raw[:90])
					continue
				if self._foreign_dub(rest): continue
				name = source_utils.clean_name(tidy_name(raw))
				name = re.sub(r'\.{2,}', '.', name or '').strip('.') # "45. Bolum" -> 45.Bolum, no 45..Bolum
				# el titulo ingles delante solo si el nombre no lleva ninguno legible
				# (release con el titulo en hangul o en kanji, que clean_name borra)
				name_norm = ' %s ' % lang_assist.norm_latin(name or '')
				if not name or not any(' %s ' % n in name_norm for n in self.latin_norms):
					name = '%s.%s' % (re.sub(r'\s+', '.', lang_assist.translit(main)), name or '')
					name = name.strip('.')
				name_info = source_utils.info_from_name(name, lang_assist.translit(main), self.year)
				if self.undesirables and source_utils.remove_undesirables(name_info, self.undesirables): continue
				seen.add(h)
				url = 'magnet:?xt=urn:btih:%s&dn=%s' % (hash, quote(name))
				quality, info = source_utils.get_release_quality(name_info, url)
				info += [t for t in source_utils.get_extra_tags(name) if t not in info]
				if isize: info.insert(0, isize)
				item = {'provider': PROVIDER, 'source': 'torrent', 'seeders': seeders, 'hash': hash, 'name': name, 'name_info': name_info,
						'quality': quality, 'language': self.lang or 'en', 'url': url, 'info': ' | '.join(info), 'direct': False,
						'debridonly': True, 'size': dsize}
				if package:
					item.update({'package': package, 'lang_season': str(lang_season), 'lang_ep': str(lang_ep)})
					# v2.0.08: el otro numero del mismo episodio (en la temporada / absoluto)
					_alt = self.absolute if str(lang_ep) == str(self.episode) else self.episode
					if _alt and str(_alt) != str(lang_ep): item['lang_ep_alt'] = str(_alt)
				results.append(item)
			except:
				source_utils.scraper_error('LANGHELPER')
		return results
