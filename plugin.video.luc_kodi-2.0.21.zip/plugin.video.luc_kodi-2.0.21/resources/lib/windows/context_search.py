# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Search luc_kodi window (v2.0.09) - right side panel like the context panel,
	see modules/spotlight.py
"""

from threading import Thread
from resources.lib.windows.base import BaseDialog

EDIT_ID = 1000
LIST_ID = 2000
ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT, ACTION_MOVE_UP = 1, 2, 3
ACTION_PARENT_DIR = 9


class ContextSearchXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.items = kwargs.get('items') or []
		self.query = kwargs.get('query') or ''
		self.last_query = self.query
		self.results = []
		self.result = None
		self._closing = False
		self._changed = False
		try:
			from resources.lib.modules import control
			self.setProperty('ctx.version', 'v%s' % control.addon('plugin.video.luc_kodi').getAddonInfo('version'))
		except Exception: pass

	# ── list ──
	def _make_item(self, e):
		from resources.lib.modules import spotlight
		li = self.make_listitem()
		li.setLabel(e.get('l') or '')
		li.setProperty('crumb', e.get('c') or '')
		kind = e.get('k')
		icon, color = spotlight.KIND_STYLE.get(kind, ('dot', 'FFB0B0D0'))
		li.setProperty('icon', 'ctx/ic_%s.png' % icon)
		li.setProperty('color', color)
		li.setProperty('tile', '2E' + color[2:])
		if e.get('g'): li.setProperty('logo', e['g'])
		if kind == 'setting': value = spotlight.current_value(e)
		elif kind == 'menu': value = '»'
		else: value = ''
		li.setLabel2(value)
		return li

	def _refresh(self, text):
		from resources.lib.modules import spotlight, control
		text = text or ''
		if text.strip():
			self.results = spotlight.search(text, self.items)
			n = len(self.results)
			self.setProperty('ctx.count', control.lang(48141) % n if n else control.lang(48142))
		else:
			self.results = spotlight.suggestions(self.items)
			self.setProperty('ctx.count', control.lang(48140))
		try:
			lst = self.getControl(LIST_ID)
			lst.reset()
			lst.addItems([self._make_item(e) for e in self.results])
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def _poll(self):
		"""Kodi's edit control has no 'text changed' event: read it four times a
		second, so results follow the typing (keyboard) or appear as soon as the
		on-screen keyboard is confirmed (remote, touch)."""
		from resources.lib.modules import control
		monitor = control.monitor
		while not self._closing and not monitor.abortRequested():
			try:
				text = self.getControl(EDIT_ID).getText()
				if text != self.last_query:
					self.last_query = text
					self._refresh(text)
			except Exception: pass
			monitor.waitForAbort(0.25)

	def onInit(self):
		try:
			if self.query:
				try: self.getControl(EDIT_ID).setText(self.query)
				except Exception: pass
			self._refresh(self.query)
			self.setFocusId(LIST_ID if (self.query and self.results) else EDIT_ID)
			Thread(target=self._poll).start()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def run(self):
		self.doModal()
		self._closing = True
		self.clearProperties()
		if self._changed:
			from resources.lib.modules import spotlight
			spotlight.clear_index()  # a menu switch may have changed the menus
		return self.result

	def close(self):
		self._closing = True
		BaseDialog.close(self)

	# ── input ──
	def _selected(self):
		pos = self.get_position(LIST_ID)
		return (pos, self.results[pos]) if 0 <= pos < len(self.results) else (pos, None)

	def _change(self, pos, entry, step=1, pick=False):
		from resources.lib.modules import spotlight
		if spotlight.change_value(entry, step=step, pick=pick):
			self._changed = True
			spotlight.add_recent(entry)
			try: self.getControl(LIST_ID).getListItem(pos).setLabel2(spotlight.current_value(entry))
			except Exception: pass

	def onClick(self, controlID):
		try:
			if controlID != LIST_ID: return
			from resources.lib.modules import spotlight
			pos, entry = self._selected()
			if not entry: return
			if spotlight.is_inline(entry):
				self._change(pos, entry, pick=entry.get('t') != 'bool')
				return
			self.result = ('settings', entry) if entry.get('k') == 'setting' else ('run', entry)
			self.close()
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def onAction(self, action):
		try:
			action_id = action.getId()
			focus = self.getFocusId()
			if focus == EDIT_ID and action_id == ACTION_PARENT_DIR: return  # backspace while typing
			if action_id in self.closing_actions or action_id in self.context_actions:
				self.close()
				return
			if focus == LIST_ID and action_id in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT):
				from resources.lib.modules import spotlight
				pos, entry = self._selected()
				if entry and spotlight.is_inline(entry):
					self._change(pos, entry, step=1 if action_id == ACTION_MOVE_RIGHT else -1)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
