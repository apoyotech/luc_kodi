# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Sync panel window (v2.0.15): the context panel sheet for Sync credentials
	with your devices and Premiere TV Shows / Premiere Movies > Sync your devices.
	See modules/sync_ui.py, which opens it and falls back to Kodi's own dialogs.

	Three modes:
	  menu   one row is chosen, its key is returned
	  check  rows are ticked with OK; the first row ('__go__') returns the ticked keys
	  wait   no list: a big line, a text, a countdown and Cancel. A thread calls
	         poll() every half second; whatever it returns other than None closes
	         the panel and is returned.
	Back (key or button) returns '__back__', Home returns '__home__'.
"""

import threading
import time
from resources.lib.windows.base import BaseDialog

LIST_ID = 2000
EXITS_ID = 3000
BACK_ID = 3002
HOME_ID = 3003
WAIT_TEXT_ID = 2100
WAIT_CANCEL_ID = 2102
WAIT_PROGRESS_ID = 2103
ACTION_MOVE_UP, ACTION_MOVE_DOWN = 3, 4
ACTION_PAGE_UP, ACTION_PAGE_DOWN = 5, 6
GO, ALL = '__go__', '__all__'
TILE_OFF, TILE_ON = '2EB0B0D0', '3800FA9A'


class SyncPanelXML(BaseDialog):
	def __init__(self, *args, **kwargs):
		BaseDialog.__init__(self, args)
		self.mode = kwargs.get('mode') or 'menu'
		self.rows = list(kwargs.get('rows') or [])
		self.header = kwargs.get('header') or {}
		self.hint = kwargs.get('hint') or ''
		# check
		self.go_row = kwargs.get('go_row')  # callable(count) -> (label, hint)
		self.all_labels = kwargs.get('all_labels')  # (select all, select none) or None
		self.checked = set(kwargs.get('checked') or [])
		# wait
		self.poll = kwargs.get('poll')
		self.seconds = kwargs.get('seconds') or 0
		self.wait = kwargs.get('wait') or {}  # big, text, btn, left (callable(seconds) -> text)
		self._stop = threading.Event()
		self._thread = None
		self._last_pos = 0
		self.chosen = None
		self.item_list = []
		if self.mode == 'check': self._add_check_rows()
		self.make_items()
		self.set_properties()

	# ------------------------------------------------------------- rows
	def _add_check_rows(self):
		top = [{'key': GO, 'icon': 'ctx/ic_check.png', 'color': 'FF00FA9A', 'tile': '2E00FA9A'}]
		if self.all_labels:
			top.append({'key': ALL, 'icon': 'ctx/ic_list.png', 'color': 'FF00C8FF', 'tile': '2E00C8FF'})
		self.rows = top + self.rows

	def _keys(self):
		return [r['key'] for r in self.rows if r.get('kind') != 'header' and r['key'] not in (GO, ALL)]

	def _texts(self, row):
		key = row.get('key')
		if key == GO: return self.go_row(len(self.checked))
		if key == ALL:
			every = bool(self._keys()) and all(k in self.checked for k in self._keys())
			return self.all_labels[1] if every else self.all_labels[0], ''
		return row.get('label', ''), row.get('hint', '')

	def make_items(self):
		for row in self.rows:
			li = self.make_listitem()
			li.setProperty('kind', row.get('kind', 'action'))
			label, hint = self._texts(row)
			li.setLabel(label)
			if row.get('kind') == 'header': # titulo de seccion: su glifo en el color del grupo
				li.setProperty('icon', row.get('icon') or 'ctx/ic_dot.png')
				li.setProperty('color', row.get('color') or 'FF00C8FF')
			else:
				li.setLabel2(hint)
				li.setProperty('icon', row.get('icon') or 'ctx/ic_dot.png')
				li.setProperty('color', row.get('color') or 'FFB0B0D0')
				li.setProperty('tile', row.get('tile') or '2EB0B0D0')
				if row.get('logo'): li.setProperty('logo', row['logo'])
				if row.get('more'): li.setProperty('more', row['more'])
				if self.mode == 'check' and row['key'] not in (GO, ALL): self._paint(li, row['key'] in self.checked)
			self.item_list.append(li)

	def _paint(self, li, on):
		li.setProperty('check', 'on' if on else 'off')
		li.setProperty('checktile', TILE_ON if on else TILE_OFF)

	def _refresh_check(self):
		for i, row in enumerate(self.rows):
			if row.get('key') in (GO, ALL):
				label, hint = self._texts(row)
				self.item_list[i].setLabel(label)
				self.item_list[i].setLabel2(hint)
			elif row.get('kind') != 'header':
				self._paint(self.item_list[i], row['key'] in self.checked)

	def set_properties(self):
		for key in ('poster', 'artkind', 'title', 'meta', 'crumb', 'back', 'home', 'version'):
			self.setProperty('ctx.%s' % key, self.header.get(key, '') or '')
		self.setProperty('sp.hint', self.hint)
		if self.mode == 'wait':
			self.setProperty('sp.big', self.wait.get('big', '') or '')
			self.setProperty('sp.text', self.wait.get('text', '') or '')
			self.setProperty('sp.btn', self.wait.get('btn', '') or '')
			self.setProperty('sp.mode', 'wait')
		else:
			self.setProperty('sp.mode', self.mode)

	def _first_action(self, start=0, step=1):
		i = start
		while 0 <= i < len(self.rows):
			if self.rows[i].get('kind') != 'header': return i
			i += step
		return -1

	def _has_exits(self):
		return any(self.header.get(k) for k in ('back', 'home'))

	# ------------------------------------------------------------- life
	def onInit(self):
		try:
			if self.mode == 'wait':
				self._tick()
				self.setFocusId(WAIT_CANCEL_ID)
				if self._thread is None:
					self._thread = threading.Thread(target=self._loop)
					self._thread.daemon = True
					self._thread.start()
				return
			lst = self.getControl(LIST_ID)
			lst.reset()
			lst.addItems(self.item_list)
			first = self._first_action()
			if first >= 0:
				lst.selectItem(first)
				self.setFocusId(LIST_ID)
			elif self._has_exits():
				self.setFocusId(EXITS_ID)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def run(self):
		self.started = time.time()
		try: self.doModal()
		finally:
			self._stop.set()
			if self._thread is not None: self._thread.join(2)
			self.clearProperties()
		return self.chosen

	def _finish(self, value):
		if self.chosen is None: self.chosen = value
		self.close()

	# ------------------------------------------------------------- wait
	def _tick(self):
		left = max(0, self.seconds - (time.time() - getattr(self, 'started', time.time()))) if self.seconds else 0
		if self.seconds:
			try: self.getControlProgress(WAIT_PROGRESS_ID).setPercent(left * 100.0 / self.seconds)
			except Exception: pass
			fmt = self.wait.get('left')
			self.setProperty('sp.left', fmt(int(left + 0.999)) if fmt else '')
		return left

	def _loop(self):
		from resources.lib.modules import control
		while not self._stop.is_set():
			try:
				left = self._tick()
				res = self.poll() if self.poll else None
				if isinstance(res, dict) and res.get('update'):
					# the poll can change the text while it waits
					for key in ('big', 'text'):
						if key in res: self.setProperty('sp.%s' % key, res[key] or '')
					res = None
				if res is not None: return self._finish(res)
				if self.seconds and left <= 0: return self._finish('__timeout__')
			except Exception:
				from resources.lib.modules import log_utils
				log_utils.error()
				return self._finish('__error__')
			if control.monitor.waitForAbort(0.5): return self._finish('__back__')

	# ------------------------------------------------------------- input
	def onClick(self, controlID):
		try:
			if controlID == LIST_ID:
				pos = self.get_position(LIST_ID)
				if not 0 <= pos < len(self.rows): return
				row = self.rows[pos]
				if row.get('kind') == 'header' or row.get('disabled'): return
				if self.mode != 'check': return self._finish(row['key'])
				key = row['key']
				if key == GO:
					if self.checked: self._finish([k for k in self._keys() if k in self.checked])
					return
				if key == ALL:
					keys = self._keys()
					if all(k in self.checked for k in keys): self.checked.clear()
					else: self.checked.update(keys)
				elif key in self.checked: self.checked.discard(key)
				else: self.checked.add(key)
				self._refresh_check()
			elif controlID in (BACK_ID, WAIT_CANCEL_ID):
				self._finish('__back__')
			elif controlID == HOME_ID:
				self._finish('__home__')
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()

	def onAction(self, action):
		try:
			action_id = action.getId()
			if action_id in self.closing_actions:
				return self._finish('__back__')
			focus = self.getFocusId()
			if self.mode == 'wait':
				# the list is hidden: Down from Back / Home lands on Cancel
				if action_id == ACTION_MOVE_DOWN and focus in (EXITS_ID, BACK_ID, HOME_ID): self.setFocusId(WAIT_CANCEL_ID)
				return
			if focus == LIST_ID and action_id in (ACTION_MOVE_UP, ACTION_MOVE_DOWN, ACTION_PAGE_UP, ACTION_PAGE_DOWN):
				pos = self.get_position(LIST_ID)
				if 0 <= pos < len(self.rows) and self.rows[pos].get('kind') == 'header':
					step = -1 if action_id in (ACTION_MOVE_UP, ACTION_PAGE_UP) else 1
					target = self._first_action(pos + step, step)
					if target < 0:
						if step < 0 and self._has_exits():
							self.setFocusId(EXITS_ID)
							return
						target = self._first_action(pos - step, -step)
					if target >= 0: self.getControl(LIST_ID).selectItem(target)
		except Exception:
			from resources.lib.modules import log_utils
			log_utils.error()
