# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on
	Global context entry "Exit ... list" (addon.xml kodi.context.item, v2.0.09).
	Shown only inside a luc_kodi list in the Videos window; see modules/navstate.py
"""

import xbmc

if __name__ == '__main__':
	xbmc.executebuiltin('RunPlugin(plugin://plugin.video.luc_kodi/?action=ctx_ExitList)')
