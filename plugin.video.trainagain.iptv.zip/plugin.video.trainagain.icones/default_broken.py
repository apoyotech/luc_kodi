# -*- coding: utf-8 -*-

import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
from urllib.parse import parse_qsl, urlencode
import urllib.parse
import requests
import json
import time
import hashlib
import os
import re
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Importar gestor de ícones de países
from country_icon_manager import CountryIconManager

# Importar gestor de Stalker Portal
from mac_manager import MacManager

# Configuração global
addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
addon_url = sys.argv[0]
addon_path = addon.getAddonInfo('path')

def log(message, level=xbmc.LOGINFO):
    """Log de mensagens"""
    xbmc.log(f"[TRAINAGAIN-ICONES] {message}", level)

def notify(title, message, icon=xbmcgui.NOTIFICATION_INFO, time=5000):
    """Mostrar notificação"""
    xbmcgui.Dialog().notification(title, message, icon, time)

class ImprovedHTTPSession:
    """Classe HTTP melhorada para requisições"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def get(self, url, timeout=15, **kwargs):
        """GET request com tratamento de erros"""
        try:
            response = self.session.get(url, timeout=timeout, **kwargs)
            return response
        except Exception as e:
            log(f"Erro HTTP GET: {e}")
            return None
    
    def post(self, url, data=None, timeout=15, **kwargs):
        """POST request com tratamento de erros"""
        try:
            response = self.session.post(url, data=data, timeout=timeout, **kwargs)
            return response
        except Exception as e:
            log(f"Erro HTTP POST: {e}")
            return None

class LogoManager:
    """Gestor de logos para canais"""
    
    def __init__(self):
        self.logos = {}
    
    def get_logo(self, channel_name):
        """Obter logo para canal"""
        return self.logos.get(channel_name.lower(), "")

class TrainAgainIcones:
    """Classe principal do add-on com funcionalidades Xtream"""
    
    def __init__(self):
        self.addon = addon
        self.handle = addon_handle
        self.url = addon_url
        self.http = ImprovedHTTPSession()
        self.logo_manager = LogoManager()
        
        # Definir addon_path localmente para garantir que está disponível
        self.addon_path = self.addon.getAddonInfo('path')
        
        # Inicializar gestor de ícones de países
        self.country_icon_manager = CountryIconManager(self.addon_path)
        
        # Inicializar gestor de Stalker Portal
        self.mac_manager = MacManager(self.addon)
        
        log("TrainAgainIcones inicializado com funcionalidades Xtream e MAC")    
    def router(self, paramstring):
        """Router principal do add-on"""
        params = dict(parse_qsl(paramstring))
        action = params.get('action')
        
        log(f"Ação recebida: {action}")
        
        if action is None:
            self.show_main_menu()
        elif action == 'xtream_codes':
            self.show_xtream_codes()
        elif action == 'xtream_multiple':
            self.show_xtream_multiple()
        elif action == 'xtream_codes_for_list':
            list_num = params.get('list_num', '1')
            self.show_xtream_codes_for_list(list_num)
        elif action == 'xtream_list':
            list_num = params.get('list_num', '1')
            self.show_xtream_codes_for_list(list_num)
        elif action == 'xtream_live':
            # Verificar se tem list_num para usar nova função ou função original
            list_num = params.get('list_num', '')
            if list_num:
                self.show_xtream_live_for_list(list_num)
            else:
                self.show_xtream_live()
        elif action == 'xtream_live_by_category':
            category_id = params.get('category_id', '')
            list_num = params.get('list_num', '')
            if list_num:
                self.show_xtream_live_by_category_for_list(category_id, list_num)
            else:
                self.show_xtream_live_by_category(category_id)
        elif action == 'xtream_vod_categories':
            list_num = params.get('list_num', '')
            if list_num:
                self.show_xtream_vod_categories_for_list(list_num)
            else:
                self.show_xtream_vod_categories()
        elif action == 'xtream_vod_by_category':
            category_id = params.get('category_id', '')
            list_num = params.get('list_num', '')
            if list_num:
                self.show_xtream_vod_by_category_for_list(category_id, list_num)
            else:
                self.show_xtream_vod_by_category(category_id)
        elif action == 'xtream_series_categories':
            list_num = params.get('list_num', '')
            if list_num:
                self.show_xtream_series_categories_for_list(list_num)
            else:
                self.show_xtream_series_categories()
        elif action == 'xtream_series_by_category':
            category_id = params.get('category_id', '')
            list_num = params.get('list_num', '')
            if list_num:
                self.show_xtream_series_by_category_for_list(category_id, list_num)
            else:
                self.show_xtream_series_by_category(category_id)
        elif action == 'xtream_series_episodes':
            series_id = params.get('series_id', '')
            list_num = params.get('list_num', '')
            if list_num:
                self.show_xtream_series_episodes_for_list(series_id, list_num)
            else:
                self.show_xtream_series_episodes(series_id)
        elif action == 'play_xtream':
            stream_id = params.get('stream_id', '')
            stream_type = params.get('stream_type', 'live')
            episode_id = params.get('episode_id', '')
            list_num = params.get('list_num', '')
            if list_num:
                self.play_xtream_stream_for_list(stream_id, stream_type, episode_id, list_num)
            else:
                self.play_xtream_stream(stream_id, stream_type, episode_id)
        elif action == 'test_connection':
            self.test_connection()
        # NOVA FUNCIONALIDADE M3U - Adicionar ações M3U CORRIGIDAS
        elif action == 'm3u_playlists':
            self.show_m3u_playlists()
        elif action == 'local_media':
            self.show_local_media()
        elif action == 'browse_m3u':
            source = params.get('source', '')
            self.browse_m3u_playlist(source)
        elif action == 'browse_m3u_category':
            source = params.get('source', '')
            category = params.get('category', '')
            self.browse_m3u_category(source, category)
        elif action == 'browse_local_dir':
            path = params.get('path', '')
            self.browse_local_directory(path)
        elif action == 'play_m3u_item':
            url = params.get('url', '')
            title = params.get('title', 'Stream')
            self.play_m3u_item(url, title)
        elif action == 'settings':
            self.addon.openSettings()
        # FUNCIONALIDADES MAC - Adicionar ações MAC
        elif action == 'mac_portal':
            self.show_mac_portal()
        elif action == 'mac_multiple':
            self.show_mac_multiple()
        elif action == 'mac_portal_for_config':
            config_id = params.get('config_id', 'main')
            self.show_mac_portal_for_config(config_id)
        elif action == 'mac_genres':
            # Manter compatibilidade com versão original (sem argumentos)
            # e nova versão (com config_id)
            config_id = params.get('config_id', 'main')
            if config_id == 'main' and not params.get('config_id'):
                # Chamada original sem argumentos
                self.show_mac_genres()
            else:
                # Nova chamada com config_id
                self.show_mac_genres_for_config(config_id)
        elif action == 'mac_channels':
            genre_id = params.get('genre_id', '')
            config_id = params.get('config_id', 'main')
            if config_id == 'main' and not params.get('config_id'):
                # Compatibilidade com versão original
                genre_title = params.get('genre_title', '')
                self.show_mac_channels(genre_id, genre_title)
            else:
                # Nova versão com config_id
                self.show_mac_channels_for_config(genre_id, config_id)
        elif action == 'play_mac_channel':
            ch_id = params.get('ch_id', '')
            config_id = params.get('config_id', 'main')
            if config_id == 'main' and not params.get('config_id'):
                # Compatibilidade com versão original
                title = params.get('title', '')
                self.play_mac_channel(ch_id, title)
            else:
                # Nova versão com config_id
                self.play_mac_channel_for_config(ch_id, config_id)
        elif action == 'test_mac_connection':
            config_id = params.get('config_id', 'main')
            if config_id == 'main' and not params.get('config_id'):
                # Compatibilidade com versão original
                self.test_mac_connection()
            else:
                # Nova versão com config_id
                self.test_mac_connection_for_config(config_id)
        else:
            log(f"Ação desconhecida: {action}")
            self.show_main_menu()
    
    def show_main_menu(self):
        """Mostrar menu principal com ícones e fanart"""
        log("Mostrando menu principal com ícones e fanart")
        
        xtream_server = self.addon.getSetting('xtream_server')
        
        # Mapeamento de fanart para cada ação - USAR LOGO TRAINAGAIN EM TUDO
        trainagain_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/trainagain_main_fanart.png"
        
        fanart_map = {
            "xtream_codes": trainagain_fanart,
            "xtream_multiple": trainagain_fanart,
            "test_connection": trainagain_fanart,
            "settings": trainagain_fanart,
            # NOVA FUNCIONALIDADE M3U
            "m3u_playlists": trainagain_fanart,
            "local_media": trainagain_fanart,
            # STALKER PORTAL
            "mac_portal": trainagain_fanart
        }
        
        menu_items = []
        
        if xtream_server:
            # Verificar se há múltiplas listas Xtream configuradas
            additional_lists = []
            for i in range(2, 6):  # Listas 2-5
                if (self.addon.getSetting(f'xtream_{i}_enabled') == 'true' and 
                    self.addon.getSetting(f'xtream_{i}_server')):
                    additional_lists.append(i)
            
            if additional_lists:
                menu_items.append(("🌐 Listas Xtream", "xtream_multiple", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/xtream_codes_icon.png"))
            else:
                menu_items.append(("🌐 Xtream Codes", "xtream_codes", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/xtream_codes_icon.png"))
        
        # NOVA FUNCIONALIDADE M3U - Adicionar opções M3U se habilitadas
        try:
            from m3u_extension import M3UExtension
            m3u_ext = M3UExtension(self.addon)
            
            if m3u_ext.is_m3u_enabled() and m3u_ext.get_m3u_sources():
                menu_items.append(("📺 Playlists M3U", "m3u_playlists", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/playlists_icon.png"))
            
            if m3u_ext.get_local_directories():
                menu_items.append(("📁 Mídia Local", "local_media", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/movies_icon.png"))
        except ImportError:
            log("Módulo M3U não encontrado - funcionalidade M3U desabilitada", xbmc.LOGWARNING)
        except Exception as e:
            log(f"Erro ao carregar extensão M3U: {e}", xbmc.LOGWARNING)
        
        # FUNCIONALIDADE MAC - Verificar múltiplas configurações MAC
        all_mac_configs = self.mac_manager.get_all_mac_configs()
        if all_mac_configs:
            if len(all_mac_configs) > 1:
                menu_items.append(("🔌 Portais MAC", "mac_multiple", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/stalker_portal_icon.png"))
            else:
                menu_items.append(("🔌 Stalker Portal", "mac_portal", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/stalker_portal_icon.png"))
        
        menu_items.extend([
            ("🔧 Teste de Conexão", "test_connection", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/test_connection_icon.png"),
            ("⚙️ Configurações", "settings", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/settings_icon.png")
        ])
        
        # Verificar se há pelo menos um serviço configurado
        has_service = False
        
        # Verificar Xtream Codes
        if xtream_server:
            has_service = True
        
        # Verificar Stalker Portal
        all_mac_configs = self.mac_manager.get_all_mac_configs()
        if all_mac_configs:
            has_service = True
        
        # Verificar M3U
        try:
            m3u_ext = M3UExtension(self.addon)
            if m3u_ext.is_m3u_enabled() and m3u_ext.get_m3u_sources():
                has_service = True
        except:
            pass
        
        # Só mostrar mensagem se NÃO houver nenhum serviço configurado
        if not has_service:
            notify("GRUPO TRAINAGAIN", "Configure pelo menos um serviço nas configurações", xbmcgui.NOTIFICATION_WARNING)
        
        for title, action, icon_path in menu_items:
            url = f"{self.url}?action={action}"
            
            list_item = xbmcgui.ListItem(label=title)
            
            # Adicionar ícone e fanart
            art_dict = {
                'icon': icon_path, 
                'thumb': icon_path
            }
            
            # Adicionar fanart se disponível
            if action in fanart_map:
                art_dict['fanart'] = fanart_map[action]
            
            list_item.setArt(art_dict)
            
            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url=url,
                listitem=list_item,
                isFolder=True
            )
        
        xbmcplugin.endOfDirectory(self.handle)
    
    def show_xtream_codes(self):
        """Mostrar menu Xtream Codes"""
        log("Mostrando menu Xtream Codes")
        
        # Fanart específico para submenus do Xtream Codes
        xtream_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/trainagain_main_fanart.png"
        
        menu_items = [
            ("📺 TV ao Vivo", "xtream_live", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"),
            ("🎬 Filmes", "xtream_vod_categories", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/movies_icon.png"),
            ("📺 Séries", "xtream_series_categories", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/series_icon.png")
        ]
        
        for title, action, icon_path in menu_items:
            url = f"{self.url}?action={action}"
            
            list_item = xbmcgui.ListItem(label=title)
            list_item.setArt({
                'icon': icon_path, 
                'thumb': icon_path,
                'fanart': xtream_fanart
            })
            
            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url=url,
                listitem=list_item,
                isFolder=True
            )
        
        xbmcplugin.endOfDirectory(self.handle)
    
    def show_xtream_live(self):
        """Mostrar categorias de canais ao vivo Xtream Codes - VERSÃO CORRIGIDA"""
        log("Mostrando categorias de canais ao vivo Xtream")
        
        try:
            # CORREÇÃO: Mostrar categorias primeiro em vez de todos os canais
            categories = self.get_xtream_live_categories()
            
            if not categories:
                notify("Aviso", "Nenhuma categoria encontrada", xbmcgui.NOTIFICATION_WARNING)
                return
            
            # Mostrar categorias primeiro
            for category in categories:
                category_id = category.get('category_id', '')
                category_name = category.get('category_name', 'Sem nome')
                
                # Ícone específico para categorias de TV
                icon = self._get_xtream_category_icon(category_name)
                display_title = f"{icon} {category_name}"
                
                url = f"{self.url}?action=xtream_live_by_category&category_id={category_id}"
                
                list_item = xbmcgui.ListItem(label=display_title)
                
                # Tentar usar bandeira real se disponível
                flag_path = self._get_xtream_category_flag_path(category_name)
                if flag_path:
                    list_item.setArt({'icon': flag_path, 'thumb': flag_path})
                else:
                    # Usar ícone padrão se não houver bandeira
                    default_icon = "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"
                    list_item.setArt({'icon': default_icon, 'thumb': default_icon})
                
                list_item.setInfo('video', {
                    'title': category_name,
                    'plot': f'Categoria de canais: {category_name}'
                })
                
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=url,
                    listitem=list_item,
                    isFolder=True  # Importante: pasta navegável
                )
            
        except Exception as e:
            log(f"Erro ao mostrar categorias Xtream: {e}", xbmc.LOGERROR)
            notify("Erro", "Falha ao carregar categorias", xbmcgui.NOTIFICATION_ERROR)
        
        xbmcplugin.endOfDirectory(self.handle)
    
    def get_xtream_live_streams(self):
        """Obter streams ao vivo Xtream Codes"""
        try:
            server = self.addon.getSetting('xtream_server')
            username = self.addon.getSetting('xtream_username')
            password = self.addon.getSetting('xtream_password')
            
            if not all([server, username, password]):
                return []
            
            url = f"{server}/player_api.php?username={username}&password={password}&action=get_live_streams"
            response = self.http.get(url)
            
            if response and response.status_code == 200:
                return response.json()
            
            return []
            
        except Exception as e:
            log(f"Erro ao obter streams Xtream: {e}", xbmc.LOGERROR)
            return []
    
    def get_xtream_live_categories(self):
        """Obter categorias de canais ao vivo Xtream Codes - NOVA FUNÇÃO"""
        try:
            server = self.addon.getSetting('xtream_server')
            username = self.addon.getSetting('xtream_username')
            password = self.addon.getSetting('xtream_password')
            
            if not all([server, username, password]):
                return []
            
            url = f"{server}/player_api.php?username={username}&password={password}&action=get_live_categories"
            response = self.http.get(url)
            
            if response and response.status_code == 200:
                categories = response.json()
                log(f"Obtidas {len(categories)} categorias de live TV")
                return categories
            
            return []
            
        except Exception as e:
            log(f"Erro ao obter categorias live: {e}", xbmc.LOGERROR)
            return []
    
    def show_xtream_live_by_category(self, category_id):
        """Mostrar canais de uma categoria específica - NOVA FUNÇÃO"""
        log(f"Mostrando canais da categoria Xtream: {category_id}")
        
        try:
            channels = self.get_xtream_live_streams_by_category(category_id)
            
            if not channels:
                notify("Aviso", "Nenhum canal encontrado nesta categoria", xbmcgui.NOTIFICATION_WARNING)
                return
            
            for channel in channels:
                stream_id = channel.get('stream_id', '')
                name = channel.get('name', 'Sem nome')
                stream_icon = channel.get('stream_icon', '')
                category_name = channel.get('category_name', '')
                
                # Ícone para canal de TV
                display_title = f"📺 {name}"
                
                url = f"{self.url}?action=play_xtream&stream_id={stream_id}&stream_type=live"
                
                list_item = xbmcgui.ListItem(label=display_title)
                
                if stream_icon:
                    list_item.setArt({'icon': stream_icon, 'thumb': stream_icon})
                else:
                    logo = self.logo_manager.get_logo_for_channel(name)
                    list_item.setArt({'icon': logo, 'thumb': logo})
                
                list_item.setProperty('IsPlayable', 'true')
                list_item.setInfo('video', {
                    'title': name,
                    'plot': f'Canal: {name}\nCategoria: {category_name}',
                    'mediatype': 'video'
                })
                
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=url,
                    listitem=list_item,
                    isFolder=False
                )
            
        except Exception as e:
            log(f"Erro ao mostrar canais da categoria: {e}", xbmc.LOGERROR)
            notify("Erro", "Falha ao carregar canais", xbmcgui.NOTIFICATION_ERROR)
        
        xbmcplugin.endOfDirectory(self.handle)
    
    def get_xtream_live_streams_by_category(self, category_id):
        """Obter canais de uma categoria específica - NOVA FUNÇÃO"""
        try:
            server = self.addon.getSetting('xtream_server')
            username = self.addon.getSetting('xtream_username')
            password = self.addon.getSetting('xtream_password')
            
            if not all([server, username, password]):
                return []
            
            url = f"{server}/player_api.php?username={username}&password={password}&action=get_live_streams&category_id={category_id}"
            response = self.http.get(url)
            
            if response and response.status_code == 200:
                channels = response.json()
                log(f"Obtidos {len(channels)} canais da categoria {category_id}")
                return channels
            
            return []
            
        except Exception as e:
            log(f"Erro ao obter canais da categoria: {e}", xbmc.LOGERROR)
            return []
    
    def _get_xtream_category_icon(self, category_name):
        """Obter ícone específico para categoria Xtream - VERSÃO COM BANDEIRAS"""
        category_lower = category_name.lower()
        
        # Ícones específicos para tipos de categorias com bandeiras reais
        if any(keyword in category_lower for keyword in ['portugal', 'português', 'pt']):
            return '🇵🇹'
        elif any(keyword in category_lower for keyword in ['brasil', 'brazil', 'br']):
            return '🇧🇷'
        elif any(keyword in category_lower for keyword in ['espanha', 'spain', 'españa', 'es']):
            return '🇪🇸'
        elif any(keyword in category_lower for keyword in ['frança', 'france', 'fr']):
            return '🇫🇷'
        elif any(keyword in category_lower for keyword in ['itália', 'italy', 'italia', 'it']):
            return '🇮🇹'
        elif any(keyword in category_lower for keyword in ['alemanha', 'germany', 'deutschland', 'de']):
            return '🇩🇪'
        elif any(keyword in category_lower for keyword in ['reino unido', 'uk', 'united kingdom', 'gb']):
            return '🇬🇧'
        elif any(keyword in category_lower for keyword in ['estados unidos', 'usa', 'united states', 'us']):
            return '🇺🇸'
        elif any(keyword in category_lower for keyword in ['desporto', 'sport', 'futebol', 'football']):
            return '⚽'
        elif any(keyword in category_lower for keyword in ['notícias', 'news', 'informação']):
            return '📰'
        elif any(keyword in category_lower for keyword in ['música', 'music', 'musical']):
            return '🎵'
        elif any(keyword in category_lower for keyword in ['infantil', 'kids', 'criança']):
            return '👶'
        elif any(keyword in category_lower for keyword in ['filme', 'movie', 'cinema']):
            return '🎬'
        elif any(keyword in category_lower for keyword in ['documentário', 'documentary', 'cultura']):
            return '📚'
        elif any(keyword in category_lower for keyword in ['religioso', 'religious', 'igreja']):
            return '⛪'
        elif any(keyword in category_lower for keyword in ['adulto', 'adult', '+18']):
            return '🔞'
        elif any(keyword in category_lower for keyword in ['radios', 'radio', 'rádio']):
            return '📻'
        else:
            return '📺'  # Ícone padrão para TV
    
    def _get_xtream_category_flag_path(self, category_name):
        """Obter caminho da bandeira para categoria - NOVA FUNÇÃO AUXILIAR"""
        if not category_name:
            return None
            
        category_lower = category_name.lower()
        flags_path = os.path.join(self.addon_path, "resources", "media", "flags")
        
        # Mapear categorias para ficheiros de bandeiras
        if any(keyword in category_lower for keyword in ['portugal', 'português', 'pt']):
            flag_file = os.path.join(flags_path, 'portugal.png')
        elif any(keyword in category_lower for keyword in ['brasil', 'brazil', 'br']):
            flag_file = os.path.join(flags_path, 'brasil.png')
        elif any(keyword in category_lower for keyword in ['alemanha', 'germany', 'deutschland', 'de']):
            flag_file = os.path.join(flags_path, 'alemanha.png')
        elif any(keyword in category_lower for keyword in ['espanha', 'spain', 'españa', 'es']):
            flag_file = os.path.join(flags_path, 'espanha.png')
        elif any(keyword in category_lower for keyword in ['frança', 'france', 'fr']):
            flag_file = os.path.join(flags_path, 'franca.png')
        else:
            return None
            
        # Verificar se o ficheiro existe
        if os.path.exists(flag_file):
            return flag_file
        else:
            return None
    
    def show_xtream_vod_categories(self):
        """Mostrar categorias de filmes Xtream Codes"""
        log("Mostrando categorias de filmes Xtream")
        
        try:
            categories = self.get_xtream_vod_categories()
            
            if not categories:
                notify("Aviso", "Nenhuma categoria encontrada", xbmcgui.NOTIFICATION_WARNING)
                return
            
            for category in categories:
                category_id = category.get('category_id', '')
                category_name = category.get('category_name', 'Sem nome')
                
                url = f"{self.url}?action=xtream_vod_by_category&category_id={category_id}"
                
                list_item = xbmcgui.ListItem(label=f"🎬 {category_name}")
                list_item.setArt({'icon': 'DefaultMovies.png'})
                
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=url,
                    listitem=list_item,
                    isFolder=True
                )
            
        except Exception as e:
            log(f"Erro ao mostrar categorias VOD: {e}", xbmc.LOGERROR)
            notify("Erro", "Falha ao carregar categorias", xbmcgui.NOTIFICATION_ERROR)
        
        xbmcplugin.endOfDirectory(self.handle)
    
    def get_xtream_vod_categories(self):
        """Obter categorias de filmes Xtream Codes"""
        try:
            server = self.addon.getSetting('xtream_server')
            username = self.addon.getSetting('xtream_username')
            password = self.addon.getSetting('xtream_password')
            
            if not all([server, username, password]):
                return []
            
            url = f"{server}/player_api.php?username={username}&password={password}&action=get_vod_categories"
            response = self.http.get(url)
            
            if response and response.status_code == 200:
                return response.json()
            
            return []
            
        except Exception as e:
            log(f"Erro ao obter categorias VOD: {e}", xbmc.LOGERROR)
            return []
    
    def show_xtream_vod_by_category(self, category_id):
        """Mostrar filmes de uma categoria"""
        log(f"Mostrando filmes da categoria: {category_id}")
        
        try:
            movies = self.get_xtream_vod_by_category(category_id)
            
            if not movies:
                notify("Aviso", "Nenhum filme encontrado", xbmcgui.NOTIFICATION_WARNING)
                return
            
            for movie in movies[:50]:
                stream_id = movie.get('stream_id', '')
                name = movie.get('name', 'Sem nome')
                stream_icon = movie.get('stream_icon', '')
                
                url = f"{self.url}?action=play_xtream&stream_id={stream_id}&stream_type=movie"
                
                list_item = xbmcgui.ListItem(label=name)
                
                if stream_icon:
                    list_item.setArt({'icon': stream_icon, 'thumb': stream_icon, 'poster': stream_icon})
                else:
                    list_item.setArt({'icon': 'DefaultMovies.png'})
                
                list_item.setProperty('IsPlayable', 'true')
                list_item.setInfo('video', {
                    'title': name,
                    'mediatype': 'movie'
                })
                
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=url,
                    listitem=list_item,
                    isFolder=False
                )
            
        except Exception as e:
            log(f"Erro ao mostrar filmes: {e}", xbmc.LOGERROR)
            notify("Erro", "Falha ao carregar filmes", xbmcgui.NOTIFICATION_ERROR)
        
        xbmcplugin.endOfDirectory(self.handle)
    
    def get_xtream_vod_by_category(self, category_id):
        """Obter filmes de uma categoria"""
        try:
            server = self.addon.getSetting('xtream_server')
            username = self.addon.getSetting('xtream_username')
            password = self.addon.getSetting('xtream_password')
            
            if not all([server, username, password]):
                return []
            
            url = f"{server}/player_api.php?username={username}&password={password}&action=get_vod_streams&category_id={category_id}"
            response = self.http.get(url)
            
            if response and response.status_code == 200:
                return response.json()
            
            return []
            
        except Exception as e:
            log(f"Erro ao obter filmes da categoria: {e}", xbmc.LOGERROR)
            return []
    
    def show_xtream_series_categories(self):
        """Mostrar categorias de séries Xtream Codes"""
        log("Mostrando categorias de séries Xtream")
        
        try:
            categories = self.get_xtream_series_categories()
            
            if not categories:
                notify("Aviso", "Nenhuma categoria encontrada", xbmcgui.NOTIFICATION_WARNING)
                return
            
            for category in categories:
                category_id = category.get('category_id', '')
                category_name = category.get('category_name', 'Sem nome')
                
                url = f"{self.url}?action=xtream_series_by_category&category_id={category_id}"
                
                list_item = xbmcgui.ListItem(label=f"📺 {category_name}")
                list_item.setArt({'icon': 'DefaultTVShows.png'})
                
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=url,
                    listitem=list_item,
                    isFolder=True
                )
            
        except Exception as e:
            log(f"Erro ao mostrar categorias de séries: {e}", xbmc.LOGERROR)
            notify("Erro", "Falha ao carregar categorias", xbmcgui.NOTIFICATION_ERROR)
        
        xbmcplugin.endOfDirectory(self.handle)
    
    def get_xtream_series_categories(self):
        """Obter categorias de séries Xtream Codes"""
        try:
            server = self.addon.getSetting('xtream_server')
            username = self.addon.getSetting('xtream_username')
            password = self.addon.getSetting('xtream_password')
            
            if not all([server, username, password]):
                return []
            
            url = f"{server}/player_api.php?username={username}&password={password}&action=get_series_categories"
            response = self.http.get(url)
            
            if response and response.status_code == 200:
                return response.json()
            
            return []
            
        except Exception as e:
            log(f"Erro ao obter categorias de séries: {e}", xbmc.LOGERROR)
            return []
    
    def show_xtream_series_by_category(self, category_id):
        """Mostrar séries de uma categoria"""
        log(f"Mostrando séries da categoria: {category_id}")
        
        try:
            series = self.get_xtream_series_by_category(category_id)
            
            if not series:
                notify("Aviso", "Nenhuma série encontrada", xbmcgui.NOTIFICATION_WARNING)
                return
            
            for serie in series[:50]:
                series_id = serie.get('series_id', '')
                name = serie.get('name', 'Sem nome')
                cover = serie.get('cover', '')
                
                url = f"{self.url}?action=xtream_series_episodes&series_id={series_id}"
                
                list_item = xbmcgui.ListItem(label=name)
                
                if cover:
                    list_item.setArt({'icon': cover, 'thumb': cover, 'poster': cover})
                else:
                    list_item.setArt({'icon': 'DefaultTVShows.png'})
                
                list_item.setInfo('video', {
                    'title': name,
                    'mediatype': 'tvshow'
                })
                
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=url,
                    listitem=list_item,
                    isFolder=True
                )
            
        except Exception as e:
            log(f"Erro ao mostrar séries: {e}", xbmc.LOGERROR)
            notify("Erro", "Falha ao carregar séries", xbmcgui.NOTIFICATION_ERROR)
        
        xbmcplugin.endOfDirectory(self.handle)
    
    def get_xtream_series_by_category(self, category_id):
        """Obter séries de uma categoria"""
        try:
            server = self.addon.getSetting('xtream_server')
            username = self.addon.getSetting('xtream_username')
            password = self.addon.getSetting('xtream_password')
            
            if not all([server, username, password]):
                return []
            
            url = f"{server}/player_api.php?username={username}&password={password}&action=get_series&category_id={category_id}"
            response = self.http.get(url)
            
            if response and response.status_code == 200:
                return response.json()
            
            return []
            
        except Exception as e:
            log(f"Erro ao obter séries da categoria: {e}", xbmc.LOGERROR)
            return []
    
    def show_xtream_series_episodes(self, series_id):
        """Mostrar episódios de uma série"""
        log(f"Mostrando episódios da série: {series_id}")
        
        try:
            series_info = self.get_xtream_series_info(series_id)
            
            if not series_info or 'episodes' not in series_info:
                notify("Aviso", "Nenhum episódio encontrado", xbmcgui.NOTIFICATION_WARNING)
                return
            
            episodes = series_info['episodes']
            
            for season_num in sorted(episodes.keys()):
                season_episodes = episodes[season_num]
                
                for episode in season_episodes:
                    episode_id = episode.get('id', '')
                    title = episode.get('title', 'Sem título')
                    episode_num = episode.get('episode_num', '')
                    
                    display_title = f"S{season_num}E{episode_num} - {title}"
                    
                    url = f"{self.url}?action=play_xtream&stream_id={series_id}&stream_type=series&episode_id={episode_id}"
                    
                    list_item = xbmcgui.ListItem(label=display_title)
                    list_item.setArt({'icon': 'DefaultVideo.png'})
                    list_item.setProperty('IsPlayable', 'true')
                    list_item.setInfo('video', {
                        'title': display_title,
                        'season': int(season_num),
                        'episode': int(episode_num) if episode_num else 0,
                        'mediatype': 'episode'
                    })
                    
                    xbmcplugin.addDirectoryItem(
                        handle=self.handle,
                        url=url,
                        listitem=list_item,
                        isFolder=False
                    )
            
        except Exception as e:
            log(f"Erro ao mostrar episódios: {e}", xbmc.LOGERROR)
            notify("Erro", "Falha ao carregar episódios", xbmcgui.NOTIFICATION_ERROR)
        
        xbmcplugin.endOfDirectory(self.handle)
    
    def get_xtream_series_info(self, series_id):
        """Obter informações de uma série"""
        try:
            server = self.addon.getSetting('xtream_server')
            username = self.addon.getSetting('xtream_username')
            password = self.addon.getSetting('xtream_password')
            
            if not all([server, username, password]):
                return {}
            
            url = f"{server}/player_api.php?username={username}&password={password}&action=get_series_info&series_id={series_id}"
            response = self.http.get(url)
            
            if response and response.status_code == 200:
                return response.json()
            
            return {}
            
        except Exception as e:
            log(f"Erro ao obter info da série: {e}", xbmc.LOGERROR)
            return {}
    
    def play_xtream_stream(self, stream_id, stream_type, episode_id=''):
        """Reproduzir stream Xtream Codes"""
        log(f"Reproduzindo stream Xtream: {stream_id} ({stream_type})")
        
        try:
            server = self.addon.getSetting('xtream_server')
            username = self.addon.getSetting('xtream_username')
            password = self.addon.getSetting('xtream_password')
            
            if stream_type == 'live':
                stream_url = f"{server}/live/{username}/{password}/{stream_id}.m3u8"
            elif stream_type == 'movie':
                stream_url = f"{server}/movie/{username}/{password}/{stream_id}.mp4"
            elif stream_type == 'series' and episode_id:
                stream_url = f"{server}/series/{username}/{password}/{episode_id}.mp4"
            else:
                stream_url = f"{server}/movie/{username}/{password}/{stream_id}.mp4"
            
            log(f"URL de reprodução Xtream: {stream_url}")
            
            list_item = xbmcgui.ListItem(path=stream_url)
            
            if stream_url.endswith('.m3u8'):
                list_item.setProperty('inputstream', 'inputstream.adaptive')
                list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            
            xbmcplugin.setResolvedUrl(self.handle, True, list_item)
            
        except Exception as e:
            log(f"Erro ao reproduzir stream Xtream: {e}", xbmc.LOGERROR)
            notify("Erro", "Falha na reprodução", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
    
    def test_connection(self):
        """Testar conexões"""
        log("Testando conexões")
        
        dialog = xbmcgui.DialogProgress()
        dialog.create("GRUPO TRAINAGAIN", "Testando conexões...")
        
        results = []
        
        # Testar Xtream Codes
        dialog.update(50, "Testando Xtream Codes...")
        xtream_server = self.addon.getSetting('xtream_server')
        xtream_username = self.addon.getSetting('xtream_username')
        xtream_password = self.addon.getSetting('xtream_password')
        
        if all([xtream_server, xtream_username, xtream_password]):
            try:
                test_url = f"{xtream_server}/player_api.php?username={xtream_username}&password={xtream_password}&action=get_live_categories"
                response = self.http.get(test_url)
                if response and response.status_code == 200:
                    data = response.json()
                    if isinstance(data, list) and len(data) > 0:
                        results.append("✅ Xtream Codes: OK")
                    else:
                        results.append("❌ Xtream Codes: Credenciais inválidas")
                else:
                    results.append("❌ Xtream Codes: Erro HTTP")
            except Exception as e:
                results.append(f"❌ Xtream Codes: {e}")
        else:
            results.append("⚠️ Xtream Codes: Não configurado")
        
        dialog.update(100, "Teste concluído!")
        time.sleep(1)
        dialog.close()
        
        result_text = "\n".join(results)
        xbmcgui.Dialog().textviewer("Resultado do Teste", result_text)
    
    # NOVA FUNCIONALIDADE M3U - Métodos para suporte M3U
    def show_m3u_playlists(self):
        """Mostrar playlists M3U configuradas - VERSÃO CORRIGIDA"""
        try:
            # CORREÇÃO: Importar da versão corrigida (agora é o ficheiro principal)
            from m3u_extension import M3UExtension
            m3u_ext = M3UExtension(self.addon)
            
            sources = m3u_ext.get_m3u_sources()
            
            if not sources:
                notify("M3U", "Nenhuma playlist M3U configurada", xbmcgui.NOTIFICATION_WARNING)
                return
            
            for i, source in enumerate(sources, 1):
                if source.startswith('http'):
                    title = f"📺 Playlist M3U {i} (Online)"
                else:
                    title = f"📺 Playlist M3U {i} (Local)"
                
                url = f"{self.url}?action=browse_m3u&source={urllib.parse.quote(source)}"
                
                list_item = xbmcgui.ListItem(label=title)
                list_item.setInfo('video', {'plot': f'Fonte: {source}'})
                
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=url,
                    listitem=list_item,
                    isFolder=True
                )
            
            xbmcplugin.endOfDirectory(self.handle)
            
        except ImportError:
            notify("Erro", "Módulo M3U corrigido não encontrado", xbmcgui.NOTIFICATION_ERROR)
        except Exception as e:
            log(f"Erro ao mostrar playlists M3U: {e}", xbmc.LOGERROR)
            notify("Erro", f"Erro ao carregar playlists: {e}", xbmcgui.NOTIFICATION_ERROR)
    
    def show_local_media(self):
        """Mostrar diretórios de mídia local - VERSÃO CORRIGIDA"""
        try:
            # CORREÇÃO: Importar da versão corrigida (agora é o ficheiro principal)
            from m3u_extension import M3UExtension
            m3u_ext = M3UExtension(self.addon)
            
            directories = m3u_ext.get_local_directories()
            
            if not directories:
                notify("Mídia Local", "Nenhum diretório configurado", xbmcgui.NOTIFICATION_WARNING)
                return
            
            for i, directory in enumerate(directories, 1):
                dir_name = os.path.basename(directory) or f"Diretório {i}"
                title = f"📁 {dir_name}"
                
                url = f"{self.url}?action=browse_local_dir&path={urllib.parse.quote(directory)}"
                
                list_item = xbmcgui.ListItem(label=title)
                list_item.setInfo('video', {'plot': f'Caminho: {directory}'})
                
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=url,
                    listitem=list_item,
                    isFolder=True
                )
            
            xbmcplugin.endOfDirectory(self.handle)
            
        except ImportError:
            notify("Erro", "Módulo M3U não encontrado", xbmcgui.NOTIFICATION_ERROR)
        except Exception as e:
            log(f"Erro ao mostrar mídia local: {e}", xbmc.LOGERROR)
            notify("Erro", f"Erro ao carregar mídia local: {e}", xbmcgui.NOTIFICATION_ERROR)
    
    def browse_m3u_playlist(self, source):
        """Navegar playlist M3U - VERSÃO COM CATEGORIAS OBRIGATÓRIAS"""
        try:
            log("Iniciando navegação de playlist M3U com categorias obrigatórias")
            
            # Tentar importar da versão melhorada primeiro
            try:
                from m3u_extension_improved import M3UExtension
                log("Usando módulo M3U melhorado")
            except ImportError:
                try:
                    from m3u_extension import M3UExtension
                    log("Usando módulo M3U original")
                except ImportError:
                    notify("Erro", "Módulo M3U não encontrado", xbmcgui.NOTIFICATION_ERROR)
                    log("Erro: Nenhum módulo M3U encontrado", xbmc.LOGERROR)
                    return
            
            m3u_ext = M3UExtension(self.addon)
            
            # Validar fonte antes de processar
            source = urllib.parse.unquote(source)
            log(f"Processando fonte M3U: {source[:100]}...")
            
            if not source or not source.strip():
                notify("M3U", "Fonte M3U vazia", xbmcgui.NOTIFICATION_WARNING)
                log("Erro: Fonte M3U vazia", xbmc.LOGWARNING)
                return
            
            # Processar arquivo M3U
            entries = m3u_ext.parse_m3u_file(source)
            
            if not entries:
                notify("M3U", "Nenhuma entrada válida encontrada na playlist", xbmcgui.NOTIFICATION_WARNING)
                log(f"Nenhuma entrada encontrada em: {source}", xbmc.LOGWARNING)
                return
            
            log(f"Processadas {len(entries)} entradas da playlist M3U")
            
            # CORREÇÃO PRINCIPAL: SEMPRE mostrar categorias primeiro
            # Não importa quantos itens há, sempre agrupa por categoria
            self._show_categories_first(entries, source)
            
        except Exception as e:
            log(f"Erro ao navegar playlist M3U: {e}", xbmc.LOGERROR)
            notify("Erro", f"Erro ao carregar playlist: {str(e)[:50]}...", xbmcgui.NOTIFICATION_ERROR)
    
    def _validate_m3u_source(self, source):
        """MELHORIA: Validar fonte M3U"""
        try:
            # Verificar se é URL válida
            if source.startswith(('http://', 'https://', 'ftp://')):
                parsed = urllib.parse.urlparse(source)
                return bool(parsed.netloc and parsed.scheme)
            
            # Verificar se é arquivo local
            elif os.path.exists(source) or xbmcvfs.exists(source):
                return True
            
            # Verificar se tem extensão M3U
            elif source.lower().endswith(('.m3u', '.m3u8')):
                return True
            
            return False
        except Exception:
            return False
    
    def _show_categories_first(self, entries, source):
        """NOVA FUNÇÃO: Sempre mostrar categorias primeiro"""
        try:
            log("Forçando exibição de categorias primeiro")
            
            # Agrupar entradas por categoria
            categories = {}
            for entry in entries:
                group = entry.get('group', 'Sem Categoria')
                if group not in categories:
                    categories[group] = []
                categories[group].append(entry)
            
            log(f"Encontradas {len(categories)} categorias")
            
            # Se só há uma categoria e é "Sem Categoria", mostrar itens diretamente
            if len(categories) == 1 and 'Sem Categoria' in categories:
                log("Apenas uma categoria 'Sem Categoria' encontrada, mostrando itens diretamente")
                self._browse_m3u_direct(entries)
                return
            
            # Mostrar categorias (países) primeiro
            for category_name, category_entries in sorted(categories.items()):
                # Ícone específico para países/categorias
                icon = self._get_category_icon(category_name)
                
                display_title = f"{icon} {category_name} ({len(category_entries)} canais)"
                
                # URL para navegar na categoria específica
                category_url = f"{self.url}?action=browse_m3u_category&source={urllib.parse.quote(source)}&category={urllib.parse.quote(category_name)}"
                
                list_item = xbmcgui.ListItem(label=display_title)
                list_item.setInfo('video', {
                    'title': category_name,
                    'plot': f'Categoria {category_name} com {len(category_entries)} canais disponíveis'
                })
                
                # Adicionar como pasta (isFolder=True) para navegação
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=category_url,
                    listitem=list_item,
                    isFolder=True  # IMPORTANTE: Isto faz com que seja uma pasta navegável
                )
            
            xbmcplugin.endOfDirectory(self.handle)
            log(f"Exibidas {len(categories)} categorias como pastas navegáveis")
            
        except Exception as e:
            log(f"Erro ao exibir categorias: {e}", xbmc.LOGERROR)
            # Fallback para exibição direta se houver erro
            self._browse_m3u_direct(entries)
    
    def _get_category_icon(self, category_name):
        """NOVA FUNÇÃO: Obter ícone específico para categoria/país"""
        category_lower = category_name.lower()
        
        # Ícones específicos para países
        if any(country in category_lower for country in ['portugal', 'português']):
            return '🇵🇹'
        elif any(country in category_lower for country in ['brasil', 'brazil']):
            return '🇧🇷'
        elif any(country in category_lower for country in ['espanha', 'spain', 'españa']):
            return '🇪🇸'
        elif any(country in category_lower for country in ['frança', 'france']):
            return '🇫🇷'
        elif any(country in category_lower for country in ['itália', 'italy', 'italia']):
            return '🇮🇹'
        elif any(country in category_lower for country in ['alemanha', 'germany', 'deutschland']):
            return '🇩🇪'
        elif any(country in category_lower for country in ['reino unido', 'uk', 'united kingdom']):
            return '🇬🇧'
        elif any(country in category_lower for country in ['estados unidos', 'usa', 'united states']):
            return '🇺🇸'
        elif any(country in category_lower for country in ['canadá', 'canada']):
            return '🇨🇦'
        elif any(country in category_lower for country in ['méxico', 'mexico']):
            return '🇲🇽'
        elif any(country in category_lower for country in ['argentina']):
            return '🇦🇷'
        elif any(country in category_lower for country in ['chile']):
            return '🇨🇱'
        elif any(country in category_lower for country in ['colômbia', 'colombia']):
            return '🇨🇴'
        elif any(country in category_lower for country in ['peru', 'perú']):
            return '🇵🇪'
        elif any(country in category_lower for country in ['venezuela']):
            return '🇻🇪'
        elif any(country in category_lower for country in ['uruguai', 'uruguay']):
            return '🇺🇾'
        elif any(country in category_lower for country in ['paraguai', 'paraguay']):
            return '🇵🇾'
        elif any(country in category_lower for country in ['bolívia', 'bolivia']):
            return '🇧🇴'
        elif any(country in category_lower for country in ['equador', 'ecuador']):
            return '🇪🇨'
        # Ícones por tipo de conteúdo
        elif any(keyword in category_lower for keyword in ['tv', 'canal', 'channel']):
            return '📺'
        elif any(keyword in category_lower for keyword in ['filme', 'movie']):
            return '🎬'
        elif any(keyword in category_lower for keyword in ['música', 'music', 'audio']):
            return '🎵'
        elif any(keyword in category_lower for keyword in ['rádio', 'radio']):
            return '📻'
        elif any(keyword in category_lower for keyword in ['desporto', 'sport']):
            return '⚽'
        elif any(keyword in category_lower for keyword in ['notícias', 'news']):
            return '📰'
        elif any(keyword in category_lower for keyword in ['infantil', 'kids']):
            return '👶'
        elif any(keyword in category_lower for keyword in ['documentário', 'documentary']):
            return '📚'
        else:
            return '📂'  # Ícone padrão para categoria
    
    def _browse_m3u_direct(self, entries):
        """MELHORIA: Navegar M3U com exibição direta"""
        try:
            log("Exibindo M3U com listagem direta")
            
            for entry in entries:
                title = entry.get('title', 'Sem Título')
                url = entry.get('url', '')
                group = entry.get('group', 'Sem Categoria')
                logo = entry.get('logo', '')
                media_type = entry.get('type', 'unknown')
                
                # MELHORIA: Validar entrada antes de exibir
                if not url or not title:
                    log(f"Entrada inválida ignorada: {entry}", xbmc.LOGDEBUG)
                    continue
                
                # Ícone baseado no tipo
                if media_type == 'audio':
                    icon = '🎵'
                elif media_type == 'video':
                    icon = '🎬'
                elif media_type == 'hls':
                    icon = '📺'
                elif media_type == 'stream':
                    icon = '🌐'
                elif media_type == 'live_tv':
                    icon = '📺'
                elif media_type == 'movie':
                    icon = '🎬'
                else:
                    icon = '📄'
                
                display_title = f"{icon} {title}"
                
                # MELHORIA: Adicionar informação da categoria no título se não for "Sem Categoria"
                if group and group != 'Sem Categoria':
                    display_title += f" [{group}]"
                
                play_url = f"{self.url}?action=play_m3u_item&url={urllib.parse.quote(url)}&title={urllib.parse.quote(title)}"
                
                list_item = xbmcgui.ListItem(label=display_title)
                list_item.setInfo('video', {
                    'title': title,
                    'plot': f'Grupo: {group}\nTipo: {media_type}\nURL: {url[:100]}...'
                })
                
                if logo:
                    list_item.setArt({'thumb': logo, 'icon': logo})
                
                # MELHORIA: Marcar como reproduzível
                list_item.setProperty('IsPlayable', 'true')
                
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=play_url,
                    listitem=list_item,
                    isFolder=False
                )
            
            xbmcplugin.endOfDirectory(self.handle)
            
        except Exception as e:
            log(f"Erro ao exibir entradas M3U: {e}", xbmc.LOGERROR)
            notify("Erro", "Erro ao exibir lista M3U", xbmcgui.NOTIFICATION_ERROR)
    
    def browse_m3u_category(self, source, category):
        """FUNÇÃO MELHORADA: Navegar categoria específica (país)"""
        try:
            log(f"Navegando categoria específica: {category}")
            
            # Importar módulo M3U
            try:
                from m3u_extension_improved import M3UExtension
            except ImportError:
                from m3u_extension import M3UExtension
            
            m3u_ext = M3UExtension(self.addon)
            
            # Processar arquivo M3U
            source = urllib.parse.unquote(source)
            category = urllib.parse.unquote(category)
            
            entries = m3u_ext.parse_m3u_file(source)
            
            if not entries:
                notify("M3U", "Nenhuma entrada encontrada", xbmcgui.NOTIFICATION_WARNING)
                return
            
            # Filtrar por categoria específica
            category_entries = [entry for entry in entries if entry.get('group', 'Sem Categoria') == category]
            
            if not category_entries:
                notify("M3U", f"Nenhum canal encontrado na categoria {category}", xbmcgui.NOTIFICATION_WARNING)
                return
            
            log(f"Exibindo {len(category_entries)} canais da categoria {category}")
            
            # Mostrar canais da categoria específica
            for entry in category_entries:
                title = entry.get('title', 'Sem Título')
                url = entry.get('url', '')
                logo = entry.get('logo', '')
                media_type = entry.get('type', 'unknown')
                
                # Validar entrada
                if not url or not title:
                    continue
                
                # Ícone baseado no tipo de canal
                if media_type in ['stream', 'live_tv']:
                    icon = '📺'
                elif media_type == 'hls':
                    icon = '📡'
                elif media_type == 'video':
                    icon = '🎬'
                elif media_type == 'audio':
                    icon = '🎵'
                else:
                    icon = '📺'  # Padrão para canais de TV
                
                display_title = f"{icon} {title}"
                
                play_url = f"{self.url}?action=play_m3u_item&url={urllib.parse.quote(url)}&title={urllib.parse.quote(title)}"
                
                list_item = xbmcgui.ListItem(label=display_title)
                list_item.setInfo('video', {
                    'title': title,
                    'plot': f'Canal: {title}\nCategoria: {category}\nTipo: {media_type}'
                })
                
                if logo:
                    list_item.setArt({'thumb': logo, 'icon': logo})
                
                # Marcar como reproduzível
                list_item.setProperty('IsPlayable', 'true')
                
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=play_url,
                    listitem=list_item,
                    isFolder=False  # Não é pasta, é item reproduzível
                )
            
            xbmcplugin.endOfDirectory(self.handle)
            log(f"Exibidos {len(category_entries)} canais da categoria {category}")
            
        except Exception as e:
            log(f"Erro ao navegar categoria: {e}", xbmc.LOGERROR)
            notify("Erro", f"Erro ao carregar categoria {category}", xbmcgui.NOTIFICATION_ERROR)
    
    def browse_local_directory(self, path):
        """Navegar diretório local - VERSÃO CORRIGIDA"""
        try:
            # CORREÇÃO: Importar da versão corrigida (agora é o ficheiro principal)
            from m3u_extension import M3UExtension
            m3u_ext = M3UExtension(self.addon)
            
            path = urllib.parse.unquote(path)
            
            if not os.path.exists(path):
                notify("Erro", "Diretório não encontrado", xbmcgui.NOTIFICATION_ERROR)
                return
            
            # Adicionar subdiretórios
            try:
                for item in os.listdir(path):
                    item_path = os.path.join(path, item)
                    if os.path.isdir(item_path):
                        url = f"{self.url}?action=browse_local_dir&path={urllib.parse.quote(item_path)}"
                        
                        list_item = xbmcgui.ListItem(label=f"📁 {item}")
                        list_item.setInfo('video', {'plot': f'Diretório: {item_path}'})
                        
                        xbmcplugin.addDirectoryItem(
                            handle=self.handle,
                            url=url,
                            listitem=list_item,
                            isFolder=True
                        )
            except Exception as e:
                log(f"Erro ao listar subdiretórios: {e}", xbmc.LOGWARNING)
            
            # Adicionar arquivos de mídia
            entries = m3u_ext.scan_local_directory(path, recursive=False)
            
            for entry in entries:
                title = entry.get('title', 'Sem Título')
                file_path = entry.get('url', '')
                media_type = entry.get('type', 'unknown')
                
                # Ícone baseado no tipo
                if media_type == 'audio':
                    icon = '🎵'
                elif media_type == 'video':
                    icon = '🎬'
                else:
                    icon = '📄'
                
                display_title = f"{icon} {title}"
                
                play_url = f"{self.url}?action=play_m3u_item&url={urllib.parse.quote(file_path)}&title={urllib.parse.quote(title)}"
                
                list_item = xbmcgui.ListItem(label=display_title)
                list_item.setInfo('video', {
                    'title': title,
                    'plot': f'Arquivo: {file_path}\nTipo: {media_type}'
                })
                
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=play_url,
                    listitem=list_item,
                    isFolder=False
                )
            
            xbmcplugin.endOfDirectory(self.handle)
            
        except ImportError:
            notify("Erro", "Módulo M3U não encontrado", xbmcgui.NOTIFICATION_ERROR)
        except Exception as e:
            log(f"Erro ao navegar diretório: {e}", xbmc.LOGERROR)
            notify("Erro", f"Erro ao navegar diretório: {e}", xbmcgui.NOTIFICATION_ERROR)
    
    def play_m3u_item(self, url, title):
        """Reproduzir item M3U"""
        try:
            url = urllib.parse.unquote(url)
            title = urllib.parse.unquote(title)
            
            log(f"Reproduzindo item M3U: {title} - {url}")
            
            list_item = xbmcgui.ListItem(label=title, path=url)
            
            # Configurar inputstream se necessário
            if '.m3u8' in url.lower():
                list_item.setProperty('inputstream', 'inputstream.adaptive')
                list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            elif '.mpd' in url.lower():
                list_item.setProperty('inputstream', 'inputstream.adaptive')
                list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            
            # CORREÇÃO: Headers especiais para get.php e similares com melhor deteção
            if any(pattern in url for pattern in ['get.php', 'stream.php', 'play.php', 'player.php', 'live.php']):
                # CORREÇÃO: Headers mais completos para streams
                headers = (
                    'User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36&'
                    'Referer=' + url.split('?')[0] + '&'
                    'Accept=*/*&'
                    'Accept-Language=pt-PT,pt;q=0.9,en;q=0.8&'
                    'Connection=keep-alive'
                )
                url = f"{url}|{headers}"
                
                # CORREÇÃO: Forçar inputstream.adaptive para streams get.php
                list_item.setProperty('inputstream', 'inputstream.adaptive')
                list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                
                self.log(f"Stream get.php configurado com headers: {url[:100]}...")
            elif '.m3u8' in url.lower():
                list_item.setProperty('inputstream', 'inputstream.adaptive')
                list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            elif '.mpd' in url.lower():
                list_item.setProperty('inputstream', 'inputstream.adaptive')
                list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            
            list_item.setInfo('video', {'title': title})
            
            xbmc.Player().play(url, list_item)
            
        except Exception as e:
            log(f"Erro ao reproduzir item M3U: {e}", xbmc.LOGERROR)
            notify("Erro", f"Não foi possível reproduzir: {title}", xbmcgui.NOTIFICATION_ERROR)

    def build_url(self, action):
        """Construir URL para ações do plugin"""
        return f"{self.url}?action={action}"

    def show_xtream_codes_for_list(self, list_num):
        """Mostrar menu Xtream Codes para uma lista específica"""
        log(f"Mostrando menu Xtream Codes para lista {list_num}")
        
        # Obter configurações da lista
        config = self.get_xtream_config_for_list(list_num)
        if not config or not config['server']:
            notify("Erro", f"Lista {list_num} não configurada", xbmcgui.NOTIFICATION_ERROR)
            return
        
        menu_items = [
            ("📺 TV ao Vivo", f"xtream_live&list_num={list_num}", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"),
            ("🎬 Filmes", f"xtream_vod_categories&list_num={list_num}", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/movies_icon.png"),
            ("📺 Séries", f"xtream_series_categories&list_num={list_num}", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/series_icon.png")
        ]
        
        # Fanart do TrainAgain para todas as secções
        trainagain_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/trainagain_main_fanart.png"
        
        for title, action, icon in menu_items:
            url = self.build_url(action)
            list_item = xbmcgui.ListItem(label=title)
            list_item.setArt({
                'icon': icon, 
                'thumb': icon,
                'fanart': trainagain_fanart
            })
            xbmcplugin.addDirectoryItem(self.handle, url, list_item, True)
        
        xbmcplugin.endOfDirectory(self.handle)

    def show_xtream_live_for_list(self, list_num):
        """Mostrar categorias de TV ao vivo para uma lista específica"""
        log(f"Mostrando categorias TV ao vivo para lista {list_num}")
        
        categories = self.get_xtream_live_categories_for_list(list_num)
        if not categories:
            notify("Aviso", "Nenhuma categoria encontrada", xbmcgui.NOTIFICATION_WARNING)
            return
        
        for category in categories:
            category_id = category.get('category_id', '')
            category_name = category.get('category_name', 'Sem nome')
            
            # Obter ícone da bandeira
            flag_path, emoji = self.country_icon_manager.get_category_icon(category_name)
            
            url = self.build_url(f"xtream_live_by_category&category_id={category_id}&list_num={list_num}")
            list_item = xbmcgui.ListItem(label=f"{emoji} {category_name}")
            list_item.setArt({'icon': flag_path, 'thumb': flag_path})
            xbmcplugin.addDirectoryItem(self.handle, url, list_item, True)
        
        xbmcplugin.endOfDirectory(self.handle)

    def get_xtream_config_for_list(self, list_num):
        """Obter configurações Xtream para uma lista específica"""
        log(f"Obtendo configurações para lista {list_num}")
        
        if list_num == '1':
            # Lista principal (configurações originais)
            config = {
                'server': self.addon.getSetting('xtream_server'),
                'username': self.addon.getSetting('xtream_username'),
                'password': self.addon.getSetting('xtream_password'),
                'timeout': int(self.addon.getSetting('xtream_timeout') or 15),
                'retries': int(self.addon.getSetting('xtream_retries') or 3)
            }
        else:
            # Listas adicionais - usar configurações corretas do settings.xml
            config = {
                'server': self.addon.getSetting(f'xtream_{list_num}_server'),
                'username': self.addon.getSetting(f'xtream_{list_num}_username'),
                'password': self.addon.getSetting(f'xtream_{list_num}_password'),
                'timeout': int(self.addon.getSetting(f'xtream_{list_num}_timeout') or 15),
                'retries': int(self.addon.getSetting(f'xtream_{list_num}_retries') or 3)
            }
        
        # Log detalhado das configurações (sem mostrar password completo)
        log(f"Lista {list_num} - Servidor: {config['server']}")
        log(f"Lista {list_num} - Username: {config['username']}")
        log(f"Lista {list_num} - Password: {'***' if config['password'] else 'VAZIO'}")
        log(f"Lista {list_num} - Timeout: {config['timeout']}")
        
        return config

    def get_xtream_live_categories_for_list(self, list_num):
        """Obter categorias de TV ao vivo para uma lista específica"""
        log(f"Obtendo categorias TV ao vivo para lista {list_num}")
        
        config = self.get_xtream_config_for_list(list_num)
        if not config:
            log(f"ERRO: Configuração não encontrada para lista {list_num}", xbmc.LOGERROR)
            notify("Erro", f"Lista {list_num} não configurada", xbmcgui.NOTIFICATION_ERROR)
            return []
            
        if not config['server']:
            log(f"ERRO: Servidor vazio para lista {list_num}", xbmc.LOGERROR)
            notify("Erro", f"Servidor da Lista {list_num} não configurado", xbmcgui.NOTIFICATION_ERROR)
            return []
            
        if not config['username']:
            log(f"ERRO: Username vazio para lista {list_num}", xbmc.LOGERROR)
            notify("Erro", f"Username da Lista {list_num} não configurado", xbmcgui.NOTIFICATION_ERROR)
            return []
            
        if not config['password']:
            log(f"ERRO: Password vazio para lista {list_num}", xbmc.LOGERROR)
            notify("Erro", f"Password da Lista {list_num} não configurado", xbmcgui.NOTIFICATION_ERROR)
            return []
        
        try:
            url = f"{config['server']}/player_api.php?username={config['username']}&password={config['password']}&action=get_live_categories"
            log(f"Chamando API para lista {list_num}: {url}")
            
            response = requests.get(url, timeout=config['timeout'])
            log(f"Resposta HTTP para lista {list_num}: {response.status_code}")
            
            response.raise_for_status()
            categories = response.json()
            
            log(f"Lista {list_num}: {len(categories)} categorias encontradas")
            return categories
            
        except requests.exceptions.Timeout:
            log(f"ERRO: Timeout ao conectar à lista {list_num}", xbmc.LOGERROR)
            notify("Erro", f"Timeout na Lista {list_num}", xbmcgui.NOTIFICATION_ERROR)
            return []
        except requests.exceptions.ConnectionError:
            log(f"ERRO: Falha de conexão à lista {list_num}", xbmc.LOGERROR)
            notify("Erro", f"Falha de conexão à Lista {list_num}", xbmcgui.NOTIFICATION_ERROR)
            return []
        except requests.exceptions.HTTPError as e:
            log(f"ERRO HTTP na lista {list_num}: {e}", xbmc.LOGERROR)
            notify("Erro", f"Erro HTTP na Lista {list_num}: {e.response.status_code}", xbmcgui.NOTIFICATION_ERROR)
            return []
        except ValueError as e:
            log(f"ERRO: Resposta JSON inválida da lista {list_num}: {e}", xbmc.LOGERROR)
            notify("Erro", f"Resposta inválida da Lista {list_num}", xbmcgui.NOTIFICATION_ERROR)
            return []
        except Exception as e:
            log(f"ERRO: Erro inesperado na lista {list_num}: {e}", xbmc.LOGERROR)
            notify("Erro", f"Erro na Lista {list_num}: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
            return []

    def show_xtream_multiple(self):
        """Mostrar menu de seleção de múltiplas listas Xtream"""
        log("Mostrando menu de múltiplas listas Xtream")
        
        # Fanart TrainAgain para todas as listas
        trainagain_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/trainagain_main_fanart.png"
        
        # Lista principal (sempre disponível se configurada)
        xtream_server = self.addon.getSetting('xtream_server')
        if xtream_server:
            url = f"{self.url}?action=xtream_list&list_num=1"
            list_item = xbmcgui.ListItem(label="🇵🇹 Lista Principal")
            list_item.setArt({
                'icon': "special://home/addons/plugin.video.trainagain.icones/resources/media/flags/portugal.png",
                'thumb': "special://home/addons/plugin.video.trainagain.icones/resources/media/flags/portugal.png",
                'fanart': trainagain_fanart
            })
            xbmcplugin.addDirectoryItem(self.handle, url, list_item, True)
        
        # Listas adicionais
        for i in range(2, 6):
            if (self.addon.getSetting(f'xtream_{i}_enabled') == 'true' and 
                self.addon.getSetting(f'xtream_{i}_server')):
                
                list_name = self.addon.getSetting(f'xtream_{i}_name') or f"Lista {i}"
                url = f"{self.url}?action=xtream_list&list_num={i}"
                
                list_item = xbmcgui.ListItem(label=f"🌐 {list_name}")
                list_item.setArt({
                    'icon': "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/xtream_codes_icon.png",
                    'thumb': "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/xtream_codes_icon.png",
                    'fanart': trainagain_fanart
                })
                xbmcplugin.addDirectoryItem(self.handle, url, list_item, True)
        
        xbmcplugin.endOfDirectory(self.handle)

    def show_xtream_live_by_category_for_list(self, category_id, list_num):
        """Mostrar canais de uma categoria específica para lista específica"""
        log(f"Mostrando canais da categoria {category_id} para lista {list_num}")
        
        try:
            channels = self.get_xtream_live_streams_by_category_for_list(category_id, list_num)
            
            if not channels:
                notify("Aviso", "Nenhum canal encontrado nesta categoria", xbmcgui.NOTIFICATION_WARNING)
                return
            
            for channel in channels:
                stream_id = channel.get('stream_id', '')
                name = channel.get('name', 'Sem nome')
                stream_icon = channel.get('stream_icon', '')
                category_name = channel.get('category_name', '')
                
                # Ícone para canal de TV
                display_title = f"📺 {name}"
                
                url = f"{self.url}?action=play_xtream&stream_id={stream_id}&stream_type=live&list_num={list_num}"
                
                list_item = xbmcgui.ListItem(label=display_title)
                
                if stream_icon:
                    list_item.setArt({'icon': stream_icon, 'thumb': stream_icon})
                else:
                    logo = self.logo_manager.get_logo_for_channel(name)
                    list_item.setArt({'icon': logo, 'thumb': logo})
                
                list_item.setProperty('IsPlayable', 'true')
                list_item.setInfo('video', {
                    'title': name,
                    'plot': f'Canal: {name}\nCategoria: {category_name}',
                    'mediatype': 'video'
                })
                
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=url,
                    listitem=list_item,
                    isFolder=False
                )
            
        except Exception as e:
            log(f"Erro ao mostrar canais da categoria: {e}", xbmc.LOGERROR)
            notify("Erro", "Falha ao carregar canais", xbmcgui.NOTIFICATION_ERROR)
        
        xbmcplugin.endOfDirectory(self.handle)

    def get_xtream_live_streams_by_category_for_list(self, category_id, list_num):
        """Obter streams de TV ao vivo por categoria para lista específica"""
        config = self.get_xtream_config_for_list(list_num)
        if not config or not config['server']:
            return []
        
        try:
            url = f"{config['server']}/player_api.php?username={config['username']}&password={config['password']}&action=get_live_streams&category_id={category_id}"
            response = requests.get(url, timeout=config['timeout'])
            response.raise_for_status()
            return response.json()
        except Exception as e:
            log(f"Erro ao obter streams TV para lista {list_num}: {e}", xbmc.LOGERROR)
            return []

    def show_xtream_vod_categories_for_list(self, list_num):
        """Mostrar categorias de filmes para lista específica"""
        log(f"Mostrando categorias de filmes para lista {list_num}")
        
        categories = self.get_xtream_vod_categories_for_list(list_num)
        if not categories:
            notify("Aviso", "Nenhuma categoria encontrada", xbmcgui.NOTIFICATION_WARNING)
            return
        
        for category in categories:
            category_id = category.get('category_id', '')
            category_name = category.get('category_name', 'Sem nome')
            
            url = self.build_url(f"xtream_vod_by_category&category_id={category_id}&list_num={list_num}")
            list_item = xbmcgui.ListItem(label=f"🎬 {category_name}")
            list_item.setArt({
                'icon': "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/movies_icon.png",
                'thumb': "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/movies_icon.png"
            })
            xbmcplugin.addDirectoryItem(self.handle, url, list_item, True)
        
        xbmcplugin.endOfDirectory(self.handle)

    def get_xtream_vod_categories_for_list(self, list_num):
        """Obter categorias de filmes para lista específica"""
        config = self.get_xtream_config_for_list(list_num)
        if not config or not config['server']:
            return []
        
        try:
            url = f"{config['server']}/player_api.php?username={config['username']}&password={config['password']}&action=get_vod_categories"
            response = requests.get(url, timeout=config['timeout'])
            response.raise_for_status()
            return response.json()
        except Exception as e:
            log(f"Erro ao obter categorias VOD para lista {list_num}: {e}", xbmc.LOGERROR)
            return []

    def show_xtream_vod_by_category_for_list(self, category_id, list_num):
        """Mostrar filmes de uma categoria específica para lista específica"""
        log(f"Mostrando filmes da categoria {category_id} para lista {list_num}")
        
        try:
            movies = self.get_xtream_vod_streams_by_category_for_list(category_id, list_num)
            
            if not movies:
                notify("Aviso", "Nenhum filme encontrado nesta categoria", xbmcgui.NOTIFICATION_WARNING)
                return
            
            for movie in movies:
                stream_id = movie.get('stream_id', '')
                name = movie.get('name', 'Sem nome')
                stream_icon = movie.get('stream_icon', '')
                category_name = movie.get('category_name', '')
                
                # Ícone para filme
                display_title = f"🎬 {name}"
                
                url = f"{self.url}?action=play_xtream&stream_id={stream_id}&stream_type=movie&list_num={list_num}"
                
                list_item = xbmcgui.ListItem(label=display_title)
                
                if stream_icon:
                    list_item.setArt({'icon': stream_icon, 'thumb': stream_icon})
                else:
                    list_item.setArt({
                        'icon': "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/movies_icon.png",
                        'thumb': "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/movies_icon.png"
                    })
                
                list_item.setProperty('IsPlayable', 'true')
                list_item.setInfo('video', {
                    'title': name,
                    'plot': f'Filme: {name}\nCategoria: {category_name}',
                    'mediatype': 'movie'
                })
                
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=url,
                    listitem=list_item,
                    isFolder=False
                )
            
        except Exception as e:
            log(f"Erro ao mostrar filmes da categoria: {e}", xbmc.LOGERROR)
            notify("Erro", "Falha ao carregar filmes", xbmcgui.NOTIFICATION_ERROR)
        
        xbmcplugin.endOfDirectory(self.handle)

    def get_xtream_vod_streams_by_category_for_list(self, category_id, list_num):
        """Obter filmes por categoria para lista específica"""
        config = self.get_xtream_config_for_list(list_num)
        if not config or not config['server']:
            return []
        
        try:
            url = f"{config['server']}/player_api.php?username={config['username']}&password={config['password']}&action=get_vod_streams&category_id={category_id}"
            response = requests.get(url, timeout=config['timeout'])
            response.raise_for_status()
            return response.json()
        except Exception as e:
            log(f"Erro ao obter filmes para lista {list_num}: {e}", xbmc.LOGERROR)
            return []

    def show_xtream_series_categories_for_list(self, list_num):
        """Mostrar categorias de séries para lista específica"""
        log(f"Mostrando categorias de séries para lista {list_num}")
        
        categories = self.get_xtream_series_categories_for_list(list_num)
        if not categories:
            notify("Aviso", "Nenhuma categoria encontrada", xbmcgui.NOTIFICATION_WARNING)
            return
        
        for category in categories:
            category_id = category.get('category_id', '')
            category_name = category.get('category_name', 'Sem nome')
            
            url = self.build_url(f"xtream_series_by_category&category_id={category_id}&list_num={list_num}")
            list_item = xbmcgui.ListItem(label=f"📺 {category_name}")
            list_item.setArt({
                'icon': "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/series_icon.png",
                'thumb': "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/series_icon.png"
            })
            xbmcplugin.addDirectoryItem(self.handle, url, list_item, True)
        
        xbmcplugin.endOfDirectory(self.handle)

    def get_xtream_series_categories_for_list(self, list_num):
        """Obter categorias de séries para lista específica"""
        config = self.get_xtream_config_for_list(list_num)
        if not config or not config['server']:
            return []
        
        try:
            url = f"{config['server']}/player_api.php?username={config['username']}&password={config['password']}&action=get_series_categories"
            response = requests.get(url, timeout=config['timeout'])
            response.raise_for_status()
            return response.json()
        except Exception as e:
            log(f"Erro ao obter categorias de séries para lista {list_num}: {e}", xbmc.LOGERROR)
            return []

    def play_xtream_stream_for_list(self, stream_id, stream_type, episode_id='', list_num='1'):
        """Reproduzir stream Xtream Codes para lista específica"""
        log(f"Reproduzindo stream Xtream: {stream_id} ({stream_type}) da lista {list_num}")
        
        try:
            config = self.get_xtream_config_for_list(list_num)
            if not config or not config['server']:
                notify("Erro", f"Lista {list_num} não configurada", xbmcgui.NOTIFICATION_ERROR)
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
                return
            
            server = config['server']
            username = config['username']
            password = config['password']
            
            if stream_type == 'live':
                stream_url = f"{server}/live/{username}/{password}/{stream_id}.m3u8"
            elif stream_type == 'movie':
                stream_url = f"{server}/movie/{username}/{password}/{stream_id}.mp4"
            elif stream_type == 'series' and episode_id:
                stream_url = f"{server}/series/{username}/{password}/{episode_id}.mp4"
            else:
                stream_url = f"{server}/movie/{username}/{password}/{stream_id}.mp4"
            
            log(f"URL de reprodução Xtream: {stream_url}")
            
            list_item = xbmcgui.ListItem(path=stream_url)
            
            if stream_url.endswith('.m3u8'):
                list_item.setProperty('inputstream', 'inputstream.adaptive')
                list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            
            xbmcplugin.setResolvedUrl(self.handle, True, list_item)
            
        except Exception as e:
            log(f"Erro ao reproduzir stream Xtream: {e}", xbmc.LOGERROR)
            notify("Erro", "Falha na reprodução", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())

    # FUNCIONALIDADES MAC - Implementação das funções MAC
    
    def show_mac_portal(self):
        """Mostrar menu principal do Stalker Portal"""
        log("Mostrando menu Stalker Portal")
        
        trainagain_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/trainagain_main_fanart.png"
        
        # Obter configurações MAC
        mac_settings = self.mac_manager.get_mac_settings()
        
        if not mac_settings['enabled'] or not mac_settings['portal'] or not mac_settings['mac']:
            notify("Stalker Portal", "Configure Portal e MAC nas definições", xbmcgui.NOTIFICATION_WARNING)
            return
        
        # Adicionar opções do menu MAC
        menu_items = [
            ("📺 TV ao Vivo", "mac_genres", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"),
            ("🔧 Testar Conexão MAC", "test_mac_connection", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/test_connection_icon.png")
        ]
        
        for title, action, icon_path in menu_items:
            url = f"{self.url}?action={action}"
            
            list_item = xbmcgui.ListItem(label=title)
            
            # Adicionar ícone e fanart
            art_dict = {
                'icon': icon_path, 
                'thumb': icon_path,
                'fanart': trainagain_fanart
            }
            list_item.setArt(art_dict)
            
            xbmcplugin.addDirectoryItem(self.handle, url, list_item, True)
        
        xbmcplugin.endOfDirectory(self.handle)
    
    def show_mac_genres(self):
        """Mostrar géneros/categorias MAC"""
        log("Mostrando géneros MAC")
        
        trainagain_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/trainagain_main_fanart.png"
        
        # Obter configurações MAC
        mac_settings = self.mac_manager.get_mac_settings()
        portal = mac_settings['portal']
        mac = mac_settings['mac']
        
        try:
            # Processo de autenticação MAC
            token = self.mac_manager.mac_handshake(portal, mac)
            if not token:
                notify("Stalker Portal", "Falha na autenticação - Verifique Portal e MAC", xbmcgui.NOTIFICATION_ERROR)
                return
            
            profile = self.mac_manager.mac_get_profile(portal, mac, token)
            if not profile:
                notify("Stalker Portal", "Falha ao obter perfil", xbmcgui.NOTIFICATION_ERROR)
                return
            
            genres = self.mac_manager.mac_get_genres(portal, mac, token, profile)
            if not genres:
                notify("Stalker Portal", "Nenhum género encontrado", xbmcgui.NOTIFICATION_WARNING)
                return
            
            # Mostrar géneros com ícones de países
            for genre in genres:
                # Obter ícone do país para o género
                flag_path, emoji = self.country_icon_manager.get_category_icon(genre['title'])
                
                # Se não encontrar bandeira, usar ícone padrão
                if not flag_path:
                    icon_path = "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"
                    title = f"📂 {genre['title']}"
                else:
                    icon_path = flag_path
                    title = f"{emoji} {genre['title']}"
                
                url = f"{self.url}?action=mac_channels&genre_id={genre['id']}&genre_title={genre['title']}"
                
                list_item = xbmcgui.ListItem(label=title)
                
                # Adicionar ícone e fanart
                art_dict = {
                    'icon': icon_path,
                    'thumb': icon_path,
                    'fanart': trainagain_fanart
                }
                list_item.setArt(art_dict)
                
                xbmcplugin.addDirectoryItem(self.handle, url, list_item, True)
            
            xbmcplugin.endOfDirectory(self.handle)
            
        except Exception as e:
            log(f"Erro ao obter géneros MAC: {e}", xbmc.LOGERROR)
            notify("Stalker Portal", f"Erro: {e}", xbmcgui.NOTIFICATION_ERROR)
    
    def show_mac_channels(self, genre_id, genre_title):
        """Mostrar canais por género MAC"""
        log(f"Mostrando canais MAC para género {genre_id}")
        
        trainagain_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/trainagain_main_fanart.png"
        
        # Obter configurações MAC
        mac_settings = self.mac_manager.get_mac_settings()
        portal = mac_settings['portal']
        mac = mac_settings['mac']
        
        try:
            # Mostrar progresso de carregamento
            progress = xbmcgui.DialogProgress()
            progress.create("Stalker Portal", f"Carregando canais de {genre_title}...")
            progress.update(10, "Autenticando...")
            
            # Processo de autenticação MAC
            token = self.mac_manager.mac_handshake(portal, mac)
            if not token:
                progress.close()
                notify("Stalker Portal", "Falha na autenticação", xbmcgui.NOTIFICATION_ERROR)
                return
            
            progress.update(30, "Carregando lista de canais...")
            
            # Obter canais com paginação completa
            channels = self.mac_manager.mac_get_channels(portal, mac, token, genre_id)
            
            progress.update(90, f"Processando {len(channels)} canais...")
            
            if not channels:
                progress.close()
                notify("Stalker Portal", f"Nenhum canal encontrado em {genre_title}", xbmcgui.NOTIFICATION_WARNING)
                return
            
            progress.update(100, "Concluído!")
            progress.close()
            
            # Mostrar canais com logos otimizados
            for channel in channels:
                title = f"📺 {channel['name']}"
                url = f"{self.url}?action=play_mac_channel&ch_id={channel['ch_id']}&title={channel['name']}"
                
                list_item = xbmcgui.ListItem(label=title)
                list_item.setProperty('IsPlayable', 'true')
                
                # Usar logo do canal com validação MELHORADA
                logo_url = channel.get('logo', '').strip()
                
                # DEBUG: Log do logo recebido
                xbmc.log(f"[TrainAgain-MAC] Canal: {channel['name']}, Logo recebido: '{logo_url}'", xbmc.LOGINFO)
                
                if logo_url:
                    # Validar e construir URL do logo
                    if logo_url.startswith('http'):
                        # URL absoluta - usar diretamente
                        icon_path = logo_url
                        thumb_path = logo_url
                        xbmc.log(f"[TrainAgain-MAC] Logo absoluto: {logo_url}", xbmc.LOGINFO)
                    elif logo_url.startswith('/'):
                        # URL relativa - construir URL completa
                        portal_base = self.mac_manager.get_mac_settings()['portal'].rstrip('/')
                        full_logo_url = f"{portal_base}{logo_url}"
                        icon_path = full_logo_url
                        thumb_path = full_logo_url
                        xbmc.log(f"[TrainAgain-MAC] Logo relativo construído: {full_logo_url}", xbmc.LOGINFO)
                    elif '.' in logo_url and ('/' in logo_url or logo_url.endswith(('.png', '.jpg', '.jpeg', '.gif', '.svg'))):
                        # Caminho de imagem - construir URL
                        portal_base = self.mac_manager.get_mac_settings()['portal'].rstrip('/')
                        full_logo_url = f"{portal_base}/{logo_url}"
                        icon_path = full_logo_url
                        thumb_path = full_logo_url
                        xbmc.log(f"[TrainAgain-MAC] Logo caminho construído: {full_logo_url}", xbmc.LOGINFO)
                    else:
                        # Logo inválido - usar ícone padrão
                        icon_path = "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"
                        thumb_path = "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"
                        xbmc.log(f"[TrainAgain-MAC] Logo inválido '{logo_url}', usando ícone padrão", xbmc.LOGINFO)
                else:
                    # Sem logo - usar ícone padrão
                    icon_path = "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"
                    thumb_path = "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"
                    xbmc.log(f"[TrainAgain-MAC] Sem logo para {channel['name']}, usando ícone padrão", xbmc.LOGINFO)
                
                # Adicionar ícone e fanart
                art_dict = {
                    'icon': icon_path,
                    'thumb': thumb_path,
                    'fanart': trainagain_fanart
                }
                list_item.setArt(art_dict)
                
                xbmcplugin.addDirectoryItem(self.handle, url, list_item, False)
            
            xbmcplugin.endOfDirectory(self.handle)
            
        except Exception as e:
            log(f"Erro ao obter canais MAC: {e}", xbmc.LOGERROR)
            notify("Stalker Portal", f"Erro: {e}", xbmcgui.NOTIFICATION_ERROR)
    
    def play_mac_channel(self, ch_id, title):
        """Reproduzir canal MAC"""
        log(f"Reproduzindo canal MAC: {title} (ID: {ch_id})")
        
        # Obter configurações MAC
        mac_settings = self.mac_manager.get_mac_settings()
        portal = mac_settings['portal']
        mac = mac_settings['mac']
        
        try:
            # Processo de autenticação MAC
            token = self.mac_manager.mac_handshake(portal, mac)
            if not token:
                notify("Stalker Portal", "Falha na autenticação", xbmcgui.NOTIFICATION_ERROR)
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
                return
            
            # Obter URL de stream
            stream_url = self.mac_manager.mac_create_link(portal, mac, token, ch_id)
            if not stream_url:
                notify("Stalker Portal", f"Falha ao obter stream para {title}", xbmcgui.NOTIFICATION_ERROR)
                xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
                return
            
            log(f"URL de reprodução MAC: {stream_url}")
            
            # Criar item de reprodução
            list_item = xbmcgui.ListItem(path=stream_url)
            list_item.setInfo('video', {'title': title})
            
            # Configurar inputstream.adaptive para streams HLS
            if '.m3u8' in stream_url or 'hls' in stream_url.lower():
                list_item.setProperty('inputstream', 'inputstream.adaptive')
                list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            
            xbmcplugin.setResolvedUrl(self.handle, True, list_item)
            
        except Exception as e:
            log(f"Erro ao reproduzir canal MAC: {e}", xbmc.LOGERROR)
            notify("Stalker Portal", f"Erro na reprodução: {e}", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
    
    def test_mac_connection(self):
        """Testar conexão MAC"""
        log("Testando conexão MAC")
        
        # Obter configurações MAC
        mac_settings = self.mac_manager.get_mac_settings()
        
        if not mac_settings['enabled']:
            notify("Stalker Portal", "Stalker Portal não está ativado nas configurações", xbmcgui.NOTIFICATION_WARNING)
            return
        
        if not mac_settings['portal'] or not mac_settings['mac']:
            notify("Stalker Portal", "Configure Portal e MAC nas definições", xbmcgui.NOTIFICATION_WARNING)
            return
        
        portal = mac_settings['portal']
        mac = mac_settings['mac']
        
        # Mostrar progresso
        progress = xbmcgui.DialogProgress()
        progress.create("Stalker Portal", "Testando conexão...")
        
        try:
            progress.update(25, "Testando handshake...")
            success = self.mac_manager.test_mac_connection(portal, mac)
            
            progress.update(100, "Teste concluído")
            progress.close()
            
            if success:
                notify("Stalker Portal", "Conexão bem-sucedida!", xbmcgui.NOTIFICATION_INFO)
            else:
                notify("Stalker Portal", "Falha na conexão - Verifique configurações", xbmcgui.NOTIFICATION_ERROR)
                
        except Exception as e:
            progress.close()
            log(f"Erro no teste de conexão MAC: {e}", xbmc.LOGERROR)
            notify("Stalker Portal", f"Er            notify("GRUPO TRAINAGAIN", f"Erro no teste: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
    
    def show_mac_multiple(self):
        """Mostrar múltiplos portais MAC configurados"""
        log("Mostrando múltiplos portais MAC")
        
        all_configs = self.mac_manager.get_all_mac_configs()
        
        if not all_configs:
            notify("GRUPO TRAINAGAIN", "Nenhum portal MAC configurado", xbmcgui.NOTIFICATION_WARNING)
            return
        
        # Fanart específico para MAC
        mac_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/stalker_portal_fanart.png"
        
        for config in all_configs:
            title = f"🔌 {config['name']}"
            url = f"{self.url}?action=mac_portal_for_config&config_id={config['id']}"
            
            list_item = xbmcgui.ListItem(label=title)
            list_item.setArt({
                'icon': "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/stalker_portal_icon.png",
                'thumb': "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/stalker_portal_icon.png",
                'fanart': mac_fanart
            })
            
            # Adicionar informações do portal
            list_item.setInfo('video', {
                'title': title,
                'plot': f"Portal: {config['portal']}\nMAC: {config['mac']}"
            })
            
            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url=url,
                listitem=list_item,
                isFolder=True
            )
        
        xbmcplugin.endOfDirectory(self.handle)
    
    def show_mac_portal_for_config(self, config_id):
        """Mostrar portal MAC para configuração específica"""
        log(f"Mostrando portal MAC para configuração: {config_id}")
        
        config = self.mac_manager.get_mac_settings(config_id)
        
        if not config['enabled'] or not config['portal'] or not config['mac']:
            notify("GRUPO TRAINAGAIN", f"Configuração MAC {config_id} inválida", xbmcgui.NOTIFICATION_ERROR)
            return
        
        # Fanart específico para MAC
        mac_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/stalker_portal_fanart.png"
        
        menu_items = [
            ("📺 Géneros/Categorias", f"mac_genres&config_id={config_id}", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"),
            ("🔧 Testar Conexão", f"test_mac_connection&config_id={config_id}", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/test_connection_icon.png")
        ]
        
        for title, action_params, icon_path in menu_items:
            url = f"{self.url}?action={action_params}"
            
            list_item = xbmcgui.ListItem(label=title)
            list_item.setArt({
                'icon': icon_path,
                'thumb': icon_path,
                'fanart': mac_fanart
            })
            
            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url=url,
                listitem=list_item,
                isFolder=True
            )
        
        xbmcplugin.endOfDirectory(self.handle)
    
    def show_mac_genres_for_config(self, config_id='main'):
        """Mostrar géneros MAC para configuração específica (nova versão)"""
        log(f"Mostrando géneros MAC para configuração: {config_id}")
        
        config = self.mac_manager.get_mac_settings(config_id)
        
        if not config['enabled'] or not config['portal'] or not config['mac']:
            notify("GRUPO TRAINAGAIN", f"Configuração MAC {config_id} inválida", xbmcgui.NOTIFICATION_ERROR)
            return
        
        try:
            # Realizar handshake
            token = self.mac_manager.mac_handshake(config['portal'], config['mac'], config['user_agent'])
            
            if not token:
                notify("GRUPO TRAINAGAIN", "Falha na autenticação MAC", xbmcgui.NOTIFICATION_ERROR)
                return
            
            # Obter perfil
            profile = self.mac_manager.mac_get_profile(config['portal'], config['mac'], token)
            if not profile:
                notify("GRUPO TRAINAGAIN", "Falha ao obter perfil MAC", xbmcgui.NOTIFICATION_ERROR)
                return
            
            # Obter géneros
            genres = self.mac_manager.mac_get_genres(config['portal'], config['mac'], token, profile)
            
            if not genres:
                notify("GRUPO TRAINAGAIN", "Nenhum género encontrado", xbmcgui.NOTIFICATION_WARNING)
                return
            
            # Fanart específico para MAC
            mac_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/stalker_portal_fanart.png"
            
            for genre in genres:
                title = f"📂 {genre['title']}"
                url = f"{self.url}?action=mac_channels&genre_id={genre['id']}&config_id={config_id}"
                
                list_item = xbmcgui.ListItem(label=title)
                list_item.setArt({
                    'icon': "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png",
                    'thumb': "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png",
                    'fanart': mac_fanart
                })
                
                list_item.setInfo('video', {
                    'title': title,
                    'plot': f"Categoria: {genre['title']}"
                })
                
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=url,
                    listitem=list_item,
                    isFolder=True
                )
            
            xbmcplugin.endOfDirectory(self.handle)
            
        except Exception as e:
            log(f"Erro ao obter géneros MAC: {e}", xbmc.LOGERROR)
            notify("GRUPO TRAINAGAIN", f"Erro ao carregar géneros: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
    
    def show_mac_channels_for_config(self, genre_id, config_id='main'):
        """Mostrar canais MAC para configuração específica (nova versão)"""
        log(f"Mostrando canais MAC para género {genre_id}, configuração: {config_id}")
        
        config = self.mac_manager.get_mac_settings(config_id)
        
        if not config['enabled'] or not config['portal'] or not config['mac']:
            notify("GRUPO TRAINAGAIN", f"Configuração MAC {config_id} inválida", xbmcgui.NOTIFICATION_ERROR)
            return
        
        try:
            # Realizar handshake
            token = self.mac_manager.mac_handshake(config['portal'], config['mac'], config['user_agent'])
            
            if not token:
                notify("GRUPO TRAINAGAIN", "Falha na autenticação MAC", xbmcgui.NOTIFICATION_ERROR)
                return
            
            # Obter canais
            channels = self.mac_manager.mac_get_channels(config['portal'], config['mac'], token, genre_id)
            
            if not channels:
                notify("GRUPO TRAINAGAIN", "Nenhum canal encontrado", xbmcgui.NOTIFICATION_WARNING)
                return
            
            # Fanart específico para MAC
            mac_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/stalker_portal_fanart.png"
            
            for channel in channels:
                title = f"📺 {channel['name']}"
                url = f"{self.url}?action=play_mac_channel&ch_id={channel['ch_id']}&config_id={config_id}"
                
                list_item = xbmcgui.ListItem(label=title)
                list_item.setProperty('IsPlayable', 'true')
                
                # Logo do canal
                logo_url = channel.get('logo', '').strip()
                if logo_url and logo_url.startswith('http'):
                    icon_path = logo_url
                else:
                    icon_path = "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"
                
                list_item.setArt({
                    'icon': icon_path,
                    'thumb': icon_path,
                    'fanart': mac_fanart
                })
                
                list_item.setInfo('video', {
                    'title': title,
                    'plot': f"Canal: {channel['name']}"
                })
                
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=url,
                    listitem=list_item,
                    isFolder=False
                )
            
            xbmcplugin.endOfDirectory(self.handle)
            
        except Exception as e:
            log(f"Erro ao obter canais MAC: {e}", xbmc.LOGERROR)
            notify("GRUPO TRAINAGAIN", f"Erro ao carregar canais: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
    
    def play_mac_channel_for_config(self, ch_id, config_id='main'):
        """Reproduzir canal MAC para configuração específica (nova versão)"""
        log(f"Reproduzindo canal MAC {ch_id} da configuração {config_id}")
        
        config = self.mac_manager.get_mac_settings(config_id)
        
        if not config['enabled'] or not config['portal'] or not config['mac']:
            notify("GRUPO TRAINAGAIN", f"Configuração MAC {config_id} inválida", xbmcgui.NOTIFICATION_ERROR)
            return
        
        try:
            # Realizar handshake
            token = self.mac_manager.mac_handshake(config['portal'], config['mac'], config['user_agent'])
            
            if not token:
                notify("GRUPO TRAINAGAIN", "Falha na autenticação MAC", xbmcgui.NOTIFICATION_ERROR)
                return
            
            # Obter URL do stream
            stream_url = self.mac_manager.mac_create_link(config['portal'], config['mac'], token, ch_id)
            
            if not stream_url:
                notify("GRUPO TRAINAGAIN", "Falha ao obter URL do stream", xbmcgui.NOTIFICATION_ERROR)
                return
            
            # Criar item de reprodução
            list_item = xbmcgui.ListItem(path=stream_url)
            list_item.setProperty('IsPlayable', 'true')
            
            # Configurar para usar inputstream.adaptive se necessário
            if '.m3u8' in stream_url or 'mpd' in stream_url:
                list_item.setProperty('inputstream', 'inputstream.adaptive')
                if '.m3u8' in stream_url:
                    list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                elif 'mpd' in stream_url:
                    list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            
            # Reproduzir
            xbmc.Player().play(stream_url, list_item)
            log(f"Reproduzindo stream MAC: {stream_url}")
            
        except Exception as e:
            log(f"Erro ao reproduzir canal MAC: {e}", xbmc.LOGERROR)
            notify("GRUPO TRAINAGAIN", f"Erro na reprodução: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
    
    def test_mac_connection_for_config(self, config_id='main'):
        """Testar conexão MAC para configuração específica"""
        log(f"Testando conexão MAC para configuração: {config_id}")
        
        config = self.mac_manager.get_mac_settings(config_id)
        
        if not config['enabled'] or not config['portal'] or not config['mac']:
            notify("GRUPO TRAINAGAIN", f"Configuração MAC {config_id} não está configurada", xbmcgui.NOTIFICATION_ERROR)
            return
        
        # Mostrar progresso
        progress = xbmcgui.DialogProgress()
        progress.create("GRUPO TRAINAGAIN", f"Testando conexão MAC {config_id}...")
        progress.update(10, "Iniciando teste...")
        
        try:
            progress.update(30, "Realizando handshake...")
            
            # Testar handshake
            token = self.mac_manager.mac_handshake(config['portal'], config['mac'], config['user_agent'])
            
            if token:
                progress.update(60, "Obtendo perfil...")
                
                # Testar perfil
                profile = self.mac_manager.mac_get_profile(config['portal'], config['mac'], token)
                
                if profile:
                    progress.update(100, "Teste concluído!")
                    progress.close()
                    notify("GRUPO TRAINAGAIN", f"Conexão MAC {config_id} bem-sucedida!", xbmcgui.NOTIFICATION_INFO)
                    log(f"Teste MAC {config_id} bem-sucedido - Token e perfil obtidos")
                else:
                    progress.close()
                    notify("GRUPO TRAINAGAIN", f"Falha ao obter perfil MAC {config_id}", xbmcgui.NOTIFICATION_WARNING)
            else:
                progress.close()
                notify("GRUPO TRAINAGAIN", f"Falha na autenticação MAC {config_id}", xbmcgui.NOTIFICATION_ERROR)
                
        except Exception as e:
            progress.close()
            log(f"Erro no teste de conexão MAC: {e}", xbmc.LOGERROR)
            notify("GRUPO TRAINAGAIN", f"Erro no teste: {str(e)}", xbmcgui.NOTIFICATION_ERROR)

# Ponto de entrada
if __name__ == '__main__':
    try:
        app = TrainAgainIcones()
        app.router(sys.argv[2][1:])
    except Exception as e:
        log(f"Erro fatal: {e}", xbmc.LOGERROR)
        notify("GRUPO TRAINAGAIN", f"Erro: {e}", xbmcgui.NOTIFICATION_ERROR)f"Erro na reprodução: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.setResolvedUrl(self.handle, False, xbmcgui.ListItem())
    
    def test_mac_connection(self):
        """Testar conexão MAC (versão original)"""
        log("Testando conexão MAC")
        
        # Obter configurações MAC
        mac_settings = self.mac_manager.get_mac_settings()
        
        if not mac_settings['enabled']:
            notify("Stalker Portal", "Stalker Portal não está ativado nas configurações", xbmcgui.NOTIFICATION_WARNING)
            return
        
        if not mac_settings['portal'] or not mac_settings['mac']:
            notify("Stalker Portal", "Configure Portal e MAC nas definições", xbmcgui.NOTIFICATION_WARNING)
            return
        
        portal = mac_settings['portal']
        mac = mac_settings['mac']
        
        # Mostrar progresso
        progress = xbmcgui.DialogProgress()
        progress.create("Stalker Portal", "Testando conexão...")
        
        try:
            progress.update(25, "Testando handshake...")
            success = self.mac_manager.test_mac_connection(portal, mac)
            
            progress.update(100, "Teste concluído")
            progress.close()
            
            if success:
                notify("Stalker Portal", "Conexão bem-sucedida!", xbmcgui.NOTIFICATION_INFO)
            else:
                notify("Stalker Portal", "Falha na conexão - Verifique configurações", xbmcgui.NOTIFICATION_ERROR)
                
        except Exception as e:
            progress.close()
            log(f"Erro no teste de conexão MAC: {e}", xbmc.LOGERROR)
            notify("Stalker Portal", f"Erro no teste: {e}", xbmcgui.NOTIFICATION_ERROR)
    
    def test_mac_connection_for_config(self, config_id='main'):
        """Testar conexão MAC para configuração específica (nova versão)"""
        log(f"Testando conexão MAC para configuração: {config_id}")
        
        config = self.mac_manager.get_mac_settings(config_id)
        
        if not config['enabled'] or not config['portal'] or not config['mac']:
            notify("GRUPO TRAINAGAIN", f"Configuração MAC {config_id} inválida", xbmcgui.NOTIFICATION_ERROR)
            return
        
        # Mostrar progresso
        progress = xbmcgui.DialogProgress()
        progress.create("GRUPO TRAINAGAIN", f"Testando {config['name']}...")
        
        try:
            progress.update(25, "Testando handshake...")
            
            # Testar handshake
            token = self.mac_manager.mac_handshake(config['portal'], config['mac'], config['user_agent'])
            
            progress.update(75, "Verificando perfil...")
            
            if token:
                # Testar obtenção de perfil
                profile = self.mac_manager.mac_get_profile(config['portal'], config['mac'], token)
                success = profile is not None
            else:
                success = False
            
            progress.update(100, "Teste concluído")
            progress.close()
            
            if success:
                notify("GRUPO TRAINAGAIN", f"✅ {config['name']}: Conexão bem-sucedida!", xbmcgui.NOTIFICATION_INFO)
            else:
                notify("GRUPO TRAINAGAIN", f"❌ {config['name']}: Falha na conexão", xbmcgui.NOTIFICATION_ERROR)
                
        except Exception as e:
            progress.close()
            log(f"Erro no teste de conexão MAC: {e}", xbmc.LOGERROR)
            notify("GRUPO TRAINAGAIN", f"Erro no teste: {str(e)}", xbmcgui.NOTIFICATION_ERROR)

# Ponto de entrada
if __name__ == '__main__':
    try:
        app = TrainAgainIcones()
        app.router(sys.argv[2][1:])
    except Exception as e:
        log(f"Erro fatal: {e}", xbmc.LOGERROR)
        notify("GRUPO TRAINAGAIN", f"Erro: {e}", xbmcgui.NOTIFICATION_ERROR)