# -*- coding: utf-8 -*-
"""
Sistema Completo de Gestão de Bandeiras de Países
Plugin TrainAgain IPTV - Versão Final Completa
Suporte para TODOS os países identificados na lista IPTV do utilizador
"""

import os
import re
import unicodedata
import xbmc

class CountryIconManager:
    """Gestor completo de ícones de países com suporte expandido"""
    
    def __init__(self, addon_path):
        """
        Inicializar gestor de ícones
        
        Args:
            addon_path: Caminho para o addon
        """
        self.addon_path = addon_path
        self.flags_path = os.path.join(addon_path, "resources", "media", "flags")
        
        # Garantir que a pasta de bandeiras existe
        if not os.path.exists(self.flags_path):
            os.makedirs(self.flags_path, exist_ok=True)
            xbmc.log(f"[TrainAgain] Pasta de bandeiras criada: {self.flags_path}", xbmc.LOGINFO)
    
    def normalize_text(self, text):
        """
        Normalizar texto removendo acentos e caracteres especiais
        
        Args:
            text: Texto a normalizar
            
        Returns:
            Texto normalizado
        """
        if not text:
            return ""
        
        # Converter para minúsculas
        text = text.lower().strip()
        
        # Remover acentos
        text = unicodedata.normalize('NFD', text)
        text = ''.join(c for c in text if unicodedata.category(c) != 'Mn')
        
        # Remover caracteres especiais e espaços
        text = re.sub(r'[^a-z0-9]', '', text)
        
        return text
    
    def get_country_mapping(self):
        """
        Obter mapeamento completo de países para ficheiros de bandeiras
        
        Returns:
            Dicionário com mapeamento país -> ficheiro
        """
        return {
            # Países principais já existentes
            'portugal': ('portugal.png', '🇵🇹'),
            'brasil': ('brasil.png', '🇧🇷'),
            'brazil': ('brasil.png', '🇧🇷'),
            'alemanha': ('alemanha.png', '🇩🇪'),
            'germany': ('alemanha.png', '🇩🇪'),
            'deutschland': ('alemanha.png', '🇩🇪'),
            'espanha': ('espanha.png', '🇪🇸'),
            'spain': ('espanha.png', '🇪🇸'),
            'espana': ('espanha.png', '🇪🇸'),
            'franca': ('franca.png', '🇫🇷'),
            'france': ('franca.png', '🇫🇷'),
            'italia': ('italia.png', '🇮🇹'),
            'italy': ('italia.png', '🇮🇹'),
            'reinounido': ('reino_unido.png', '🇬🇧'),
            'unitedkingdom': ('reino_unido.png', '🇬🇧'),
            'uk': ('reino_unido.png', '🇬🇧'),
            'holanda': ('holanda.png', '🇳🇱'),
            'netherlands': ('holanda.png', '🇳🇱'),
            'russia': ('russia.png', '🇷🇺'),
            'turquia': ('turquia.png', '🇹🇷'),
            'turkey': ('turquia.png', '🇹🇷'),
            'dinamarca': ('dinamarca.png', '🇩🇰'),
            'denmark': ('dinamarca.png', '🇩🇰'),
            'noruega': ('noruega.png', '🇳🇴'),
            'norway': ('noruega.png', '🇳🇴'),
            'suecia': ('suecia.png', '🇸🇪'),
            'sweden': ('suecia.png', '🇸🇪'),
            'polonia': ('polonia.png', '🇵🇱'),
            'poland': ('polonia.png', '🇵🇱'),
            'argentina': ('argentina.png', '🇦🇷'),
            'mexico': ('mexico.png', '🇲🇽'),
            'chile': ('chile.png', '🇨🇱'),
            'estadosunidos': ('estados_unidos.png', '🇺🇸'),
            'usa': ('estados_unidos.png', '🇺🇸'),
            'unitedstates': ('estados_unidos.png', '🇺🇸'),
            
            # Países em falta - NOVOS
            'austria': ('austria.png', '🇦🇹'),
            'belgica': ('belgica.png', '🇧🇪'),
            'belgium': ('belgica.png', '🇧🇪'),
            'belgien': ('belgica.png', '🇧🇪'),  # Nome alemão
            'romania': ('romania.png', '🇷🇴'),
            'romenia': ('romania.png', '🇷🇴'),
            'canada': ('canada.png', '🇨🇦'),
            'india': ('india.png', '🇮🇳'),
            'colombia': ('colombia.png', '🇨🇴'),
            'marrocos': ('marrocos.png', '🇲🇦'),
            'morocco': ('marrocos.png', '🇲🇦'),
            'marocco': ('marrocos.png', '🇲🇦'),  # Variação italiana
            'england': ('england.png', '🏴󠁧󠁢󠁥󠁮󠁧󠁿'),
            'inglaterra': ('england.png', '🏴󠁧󠁢󠁥󠁮󠁧󠁿'),
            'suica': ('suica.png', '🇨🇭'),
            'switzerland': ('suica.png', '🇨🇭'),
            'australia': ('australia.png', '🇦🇺'),
            'bulgaria': ('bulgaria.png', '🇧🇬'),
            'albania': ('albania.png', '🇦🇱'),
            'grecia': ('grecia.png', '🇬🇷'),
            'greece': ('grecia.png', '🇬🇷'),
            
            # Regiões e categorias especiais
            'arab': ('arab.png', '🌍'),
            'arabe': ('arab.png', '🌍'),
            'arabic': ('arab.png', '🌍'),
            'africa': ('africa.png', '🌍'),
            'african': ('africa.png', '🌍'),
            'africano': ('africa.png', '🌍'),
            
            # Variações e sinónimos adicionais
            'pt': ('portugal.png', '🇵🇹'),
            'br': ('brasil.png', '🇧🇷'),
            'de': ('alemanha.png', '🇩🇪'),
            'es': ('espanha.png', '🇪🇸'),
            'fr': ('franca.png', '🇫🇷'),
            'it': ('italia.png', '🇮🇹'),
            'gb': ('reino_unido.png', '🇬🇧'),
            'nl': ('holanda.png', '🇳🇱'),
            'ru': ('russia.png', '🇷🇺'),
            'tr': ('turquia.png', '🇹🇷'),
            'dk': ('dinamarca.png', '🇩🇰'),
            'no': ('noruega.png', '🇳🇴'),
            'se': ('suecia.png', '🇸🇪'),
            'pl': ('polonia.png', '🇵🇱'),
            'ar': ('argentina.png', '🇦🇷'),
            'mx': ('mexico.png', '🇲🇽'),
            'cl': ('chile.png', '🇨🇱'),
            'us': ('estados_unidos.png', '🇺🇸'),
            'at': ('austria.png', '🇦🇹'),
            'be': ('belgica.png', '🇧🇪'),
            'ro': ('romania.png', '🇷🇴'),
            'ca': ('canada.png', '🇨🇦'),
            'in': ('india.png', '🇮🇳'),
            'co': ('colombia.png', '🇨🇴'),
            'ma': ('marrocos.png', '🇲🇦'),
            'ch': ('suica.png', '🇨🇭'),
            'au': ('australia.png', '🇦🇺'),
            'bg': ('bulgaria.png', '🇧🇬'),
            'al': ('albania.png', '🇦🇱'),
            'gr': ('grecia.png', '🇬🇷'),
        }
    
    def get_category_icon(self, category_name):
        """
        Obter ícone para uma categoria/país
        
        Args:
            category_name: Nome da categoria/país
            
        Returns:
            Tupla (caminho_ficheiro, emoji) ou (None, emoji_generico)
        """
        if not category_name:
            return None, "📺"
        
        # Normalizar nome da categoria
        normalized_name = self.normalize_text(category_name)
        
        xbmc.log(f"[TrainAgain] Procurando ícone para: '{category_name}' -> '{normalized_name}'", xbmc.LOGINFO)
        
        # Obter mapeamento de países
        country_mapping = self.get_country_mapping()
        
        # Procurar correspondência direta
        if normalized_name in country_mapping:
            flag_file, emoji = country_mapping[normalized_name]
            flag_path = os.path.join(self.flags_path, flag_file)
            
            if os.path.exists(flag_path):
                xbmc.log(f"[TrainAgain] Bandeira encontrada: {flag_path}", xbmc.LOGINFO)
                return flag_path, emoji
            else:
                xbmc.log(f"[TrainAgain] Ficheiro de bandeira não encontrado: {flag_path}", xbmc.LOGWARNING)
        
        # Procurar correspondência parcial
        for country_key, (flag_file, emoji) in country_mapping.items():
            if country_key in normalized_name or normalized_name in country_key:
                flag_path = os.path.join(self.flags_path, flag_file)
                
                if os.path.exists(flag_path):
                    xbmc.log(f"[TrainAgain] Bandeira encontrada (correspondência parcial): {flag_path}", xbmc.LOGINFO)
                    return flag_path, emoji
        
        # Categorias especiais sem bandeira específica
        special_categories = {
            'foradults': '🔞',
            'adult': '🔞',
            'adults': '🔞',
            'xxx': '🔞',
            'live': '📺',
            'tv': '📺',
            'movies': '🎬',
            'films': '🎬',
            'series': '📺',
            'sport': '⚽',
            'sports': '⚽',
            'news': '📰',
            'music': '🎵',
            'kids': '👶',
            'children': '👶'
        }
        
        for special_key, special_emoji in special_categories.items():
            if special_key in normalized_name:
                xbmc.log(f"[TrainAgain] Categoria especial identificada: {special_key} -> {special_emoji}", xbmc.LOGINFO)
                return None, special_emoji
        
        # Retornar emoji genérico se não encontrar nada
        xbmc.log(f"[TrainAgain] Nenhuma bandeira encontrada para: {category_name}", xbmc.LOGINFO)
        return None, "📺"
    
    def list_available_flags(self):
        """
        Listar todas as bandeiras disponíveis
        
        Returns:
            Lista de ficheiros de bandeiras disponíveis
        """
        if not os.path.exists(self.flags_path):
            return []
        
        flags = [f for f in os.listdir(self.flags_path) if f.endswith('.png')]
        xbmc.log(f"[TrainAgain] Bandeiras disponíveis: {len(flags)} ficheiros", xbmc.LOGINFO)
        
        return sorted(flags)
    
    def get_country_icon(self, category_name):
        """
        Obter ícone de país para uma categoria (alias para get_category_icon)
        
        Args:
            category_name: Nome da categoria/país
            
        Returns:
            Caminho do ficheiro da bandeira ou None
        """
        flag_path, emoji = self.get_category_icon(category_name)
        return flag_path
    
    def get_statistics(self):
        """
        Obter estatísticas do sistema de bandeiras
        
        Returns:
            Dicionário com estatísticas
        """
        available_flags = self.list_available_flags()
        country_mapping = self.get_country_mapping()
        
        stats = {
            'total_flags': len(available_flags),
            'total_mappings': len(country_mapping),
            'flags_path': self.flags_path,
            'available_flags': available_flags
        }
        
        xbmc.log(f"[TrainAgain] Estatísticas: {stats['total_flags']} bandeiras, {stats['total_mappings']} mapeamentos", xbmc.LOGINFO)
        
        return stats

