# -*- coding: utf-8 -*-
"""
Módulo M3U para TrainAgain - Extensão modular CORRIGIDA
Adiciona suporte M3U sem modificar funcionalidades existentes
CORREÇÃO: Melhor deteção de ficheiros get.php e streams
"""

import os
import re
import urllib.parse
import urllib.request
import xbmc
import xbmcvfs

class M3UExtension:
    """Extensão M3U para o plugin TrainAgain - VERSÃO CORRIGIDA"""
    
    def __init__(self, addon):
        self.addon = addon
        self.entries = []
        self.supported_extensions = ['.mp3', '.mp4', '.avi', '.mkv', '.flv', '.ts', '.m3u8']
        self.supported_protocols = ['http', 'https', 'ftp', 'file']
        # CORREÇÃO: Adicionar padrões específicos para deteção de streams
        self.stream_patterns = [
            'get.php', 'stream.php', 'play.php', 'player.php', 'live.php',
            'channel.php', 'tv.php', 'video.php', 'watch.php', 'streaming.php'
        ]
        self.stream_params = [
            'id=', 'channel=', 'stream=', 'user=', 'pass=', 'token=', 'key='
        ]
    
    def log(self, message, level=xbmc.LOGINFO):
        """Log de mensagens"""
        xbmc.log(f"[TRAINAGAIN-M3U-FIXED] {message}", level)
    
    def is_m3u_enabled(self):
        """Verifica se o suporte M3U está habilitado"""
        return self.addon.getSetting('m3u_enabled').lower() == 'true'
    
    def get_m3u_sources(self):
        """Obtém fontes M3U configuradas"""
        sources = []
        if not self.is_m3u_enabled():
            return sources
        
        for i in range(1, 6):
            source = self.addon.getSetting(f'm3u_source_{i}')
            if source and source.strip():
                sources.append(source.strip())
        
        return sources
    
    def get_local_directories(self):
        """Obtém diretórios locais configurados"""
        directories = []
        if not self.addon.getSetting('local_media_enabled').lower() == 'true':
            return directories
        
        for i in range(1, 6):
            directory = self.addon.getSetting(f'local_dir_{i}')
            if directory and directory.strip() and os.path.exists(directory.strip()):
                directories.append(directory.strip())
        
        return directories
    
    def parse_m3u_file(self, file_path):
        """Parse de arquivo M3U local ou remoto"""
        try:
            self.entries = []
            content = self._read_file_content(file_path)
            
            if not content:
                self.log(f"Não foi possível ler o arquivo: {file_path}", xbmc.LOGERROR)
                return []
            
            return self._parse_m3u_content(content)
            
        except Exception as e:
            self.log(f"Erro ao processar arquivo M3U: {e}", xbmc.LOGERROR)
            return []
    
    def _read_file_content(self, file_path):
        """Lê conteúdo de arquivo local ou remoto"""
        try:
            # Verificar se é URL
            if file_path.startswith(('http://', 'https://', 'ftp://')):
                self.log(f"Baixando M3U de URL: {file_path}")
                with urllib.request.urlopen(file_path, timeout=30) as response:
                    content = response.read().decode('utf-8', errors='ignore')
                return content
            
            # Arquivo local
            elif os.path.exists(file_path):
                self.log(f"Lendo arquivo M3U local: {file_path}")
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                return content
            
            # Tentar com xbmcvfs para compatibilidade com Kodi
            elif xbmcvfs.exists(file_path):
                self.log(f"Lendo arquivo M3U via xbmcvfs: {file_path}")
                file_obj = xbmcvfs.File(file_path)
                content = file_obj.read().decode('utf-8', errors='ignore')
                file_obj.close()
                return content
            
            else:
                self.log(f"Arquivo não encontrado: {file_path}", xbmc.LOGERROR)
                return None
                
        except Exception as e:
            self.log(f"Erro ao ler arquivo {file_path}: {e}", xbmc.LOGERROR)
            return None
    
    def _parse_m3u_content(self, content):
        """Parse do conteúdo M3U"""
        entries = []
        lines = content.split('\n')
        current_entry = {}
        
        for line in lines:
            line = line.strip()
            
            if not line:
                continue
            
            # Cabeçalho M3U
            if line.startswith('#EXTM3U'):
                continue
            
            # Informações da entrada
            elif line.startswith('#EXTINF:'):
                current_entry = self._parse_extinf_line(line)
            
            # Outras tags M3U
            elif line.startswith('#EXT'):
                self._parse_ext_tag(line, current_entry)
            
            # URL/caminho do arquivo
            elif not line.startswith('#'):
                # CORREÇÃO: Melhor validação de URLs de stream
                if current_entry or self._is_valid_media_url(line):
                    if not current_entry:
                        current_entry = {
                            'title': self._extract_title_from_url(line),
                            'duration': -1,
                            'group': 'Sem Categoria',
                            'logo': '',
                            'extra_info': {}
                        }
                    
                    current_entry['url'] = line.strip()
                    current_entry['type'] = self._detect_media_type(line)
                    
                    # CORREÇÃO: Log para debug
                    self.log(f"Entrada processada: {current_entry['title']} - Tipo: {current_entry['type']} - URL: {line[:50]}...")
                    
                    entries.append(current_entry)
                    current_entry = {}
                else:
                    # CORREÇÃO: Log para URLs rejeitadas
                    self.log(f"URL rejeitada: {line[:50]}...", xbmc.LOGWARNING)
        
        self.entries = entries
        self.log(f"Processadas {len(entries)} entradas do M3U")
        return entries
    
    def _parse_extinf_line(self, line):
        """Parse da linha EXTINF"""
        entry = {
            'duration': -1,
            'title': '',
            'group': 'Sem Categoria',
            'logo': '',
            'extra_info': {}
        }
        
        try:
            # Remover #EXTINF:
            line = line[8:]
            
            # Extrair atributos se existirem
            if ' ' in line and '=' in line:
                # Linha com atributos
                parts = line.split(',', 1)
                if len(parts) == 2:
                    attr_part = parts[0]
                    title_part = parts[1].strip()
                    
                    # Extrair duração
                    duration_match = re.match(r'^(-?\d+(?:\.\d+)?)', attr_part)
                    if duration_match:
                        entry['duration'] = float(duration_match.group(1))
                    
                    # Extrair atributos
                    attr_pattern = r'(\w+(?:-\w+)*)="([^"]*)"'
                    for match in re.finditer(attr_pattern, attr_part):
                        attr_name = match.group(1)
                        attr_value = match.group(2)
                        
                        if attr_name == 'tvg-logo':
                            entry['logo'] = attr_value
                        elif attr_name == 'group-title':
                            entry['group'] = attr_value
                        elif attr_name in ['tvg-id', 'tvg-name', 'tvg-shift']:
                            entry['extra_info'][attr_name] = attr_value
                        else:
                            entry['extra_info'][attr_name] = attr_value
                    
                    entry['title'] = title_part
            else:
                # Linha simples: duração,título
                parts = line.split(',', 1)
                if len(parts) >= 1:
                    try:
                        entry['duration'] = float(parts[0])
                    except ValueError:
                        entry['duration'] = -1
                
                if len(parts) >= 2:
                    entry['title'] = parts[1].strip()
        
        except Exception as e:
            self.log(f"Erro ao processar linha EXTINF: {e}", xbmc.LOGWARNING)
        
        return entry
    
    def _parse_ext_tag(self, line, current_entry):
        """Parse de outras tags EXT"""
        if line.startswith('#EXT-X-'):
            # Tags específicas de HLS
            if 'EXT-X-STREAM-INF' in line:
                # Informações de stream
                bandwidth_match = re.search(r'BANDWIDTH=(\d+)', line)
                if bandwidth_match:
                    current_entry['extra_info']['bandwidth'] = int(bandwidth_match.group(1))
                
                resolution_match = re.search(r'RESOLUTION=(\d+x\d+)', line)
                if resolution_match:
                    current_entry['extra_info']['resolution'] = resolution_match.group(1)
    
    def _is_valid_media_url(self, url):
        """CORREÇÃO: Verifica se a URL é um arquivo de mídia válido com melhor deteção"""
        try:
            url_lower = url.lower()
            parsed_url = urllib.parse.urlparse(url_lower)
            path = parsed_url.path
            query = parsed_url.query
            
            # CORREÇÃO 1: Verificar extensões suportadas
            for ext in self.supported_extensions:
                if path.endswith(ext):
                    self.log(f"URL válida por extensão {ext}: {url[:50]}...")
                    return True
            
            # CORREÇÃO 2: Verificar protocolos suportados com conteúdo
            if parsed_url.scheme in self.supported_protocols:
                # Se tem protocolo válido, verificar se parece ser stream
                
                # CORREÇÃO 3: Verificar padrões de stream no path
                for pattern in self.stream_patterns:
                    if pattern in path:
                        self.log(f"URL válida por padrão de stream {pattern}: {url[:50]}...")
                        return True
                
                # CORREÇÃO 4: Verificar parâmetros típicos de stream
                for param in self.stream_params:
                    if param in query:
                        self.log(f"URL válida por parâmetro de stream {param}: {url[:50]}...")
                        return True
                
                # CORREÇÃO 5: Verificar se tem parâmetros (pode ser stream dinâmico)
                if query and len(query) > 5:  # Tem query string significativa
                    self.log(f"URL válida por query string: {url[:50]}...")
                    return True
            
            # CORREÇÃO 6: Verificar se é arquivo local
            if os.path.exists(url):
                self.log(f"URL válida como arquivo local: {url[:50]}...")
                return True
            
            # CORREÇÃO 7: Verificar URLs que terminam com números (podem ser IDs de stream)
            if re.search(r'/\d+$', path) and parsed_url.scheme in self.supported_protocols:
                self.log(f"URL válida por ID numérico: {url[:50]}...")
                return True
            
            # CORREÇÃO 8: Log para debug de URLs rejeitadas
            self.log(f"URL rejeitada - Protocolo: {parsed_url.scheme}, Path: {path[:30]}, Query: {query[:30]}", xbmc.LOGDEBUG)
            return False
            
        except Exception as e:
            self.log(f"Erro ao validar URL {url}: {e}", xbmc.LOGWARNING)
            return False
    
    def _extract_title_from_url(self, url):
        """Extrai título do nome do arquivo na URL"""
        try:
            parsed_url = urllib.parse.urlparse(url)
            
            # CORREÇÃO: Tentar extrair título de parâmetros primeiro
            query_params = urllib.parse.parse_qs(parsed_url.query)
            
            # Procurar parâmetros comuns que podem conter o nome
            for param_name in ['name', 'title', 'channel', 'stream']:
                if param_name in query_params:
                    title = query_params[param_name][0]
                    if title and len(title) > 2:
                        return title.replace('_', ' ').replace('-', ' ').title()
            
            # Se não encontrou nos parâmetros, usar o nome do arquivo
            filename = os.path.basename(parsed_url.path)
            
            if filename and filename != 'get.php':
                # Remover extensão
                name, _ = os.path.splitext(filename)
                return name.replace('_', ' ').replace('-', ' ').title()
            else:
                # Para get.php e similares, tentar usar o host
                if parsed_url.netloc:
                    return f"Stream {parsed_url.netloc}"
                else:
                    return "Stream"
                
        except Exception:
            return "Mídia"
    
    def _detect_media_type(self, url):
        """CORREÇÃO: Detecta o tipo de mídia baseado na URL com melhor precisão"""
        try:
            url_lower = url.lower()
            parsed_url = urllib.parse.urlparse(url_lower)
            path = parsed_url.path
            query = parsed_url.query
            
            # CORREÇÃO 1: Verificar extensões específicas
            if any(ext in url_lower for ext in ['.mp3', '.aac', '.flac', '.ogg', '.wav']):
                return 'audio'
            elif any(ext in url_lower for ext in ['.mp4', '.avi', '.mkv', '.flv', '.ts', '.mov', '.wmv']):
                return 'video'
            elif '.m3u8' in url_lower:
                return 'hls'
            
            # CORREÇÃO 2: Verificar padrões de stream específicos
            elif any(pattern in path for pattern in self.stream_patterns):
                # Para get.php e similares, assumir que é stream de vídeo
                return 'stream'
            
            # CORREÇÃO 3: Verificar por parâmetros
            elif any(param in query for param in ['channel=', 'tv=', 'live=']):
                return 'live_tv'
            elif any(param in query for param in ['movie=', 'film=', 'video=']):
                return 'video'
            elif any(param in query for param in ['audio=', 'music=', 'radio=']):
                return 'audio'
            
            # CORREÇÃO 4: Verificar por domínio/host
            elif any(keyword in parsed_url.netloc for keyword in ['tv', 'stream', 'live', 'radio']):
                return 'stream'
            
            else:
                return 'unknown'
                
        except Exception:
            return 'unknown'
    
    def scan_local_directory(self, directory_path, recursive=True):
        """Escaneia diretório local em busca de arquivos de mídia"""
        try:
            media_files = []
            
            if not os.path.exists(directory_path):
                self.log(f"Diretório não encontrado: {directory_path}", xbmc.LOGERROR)
                return []
            
            self.log(f"Escaneando diretório: {directory_path}")
            
            if recursive:
                for root, dirs, files in os.walk(directory_path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        if self._is_media_file(file_path):
                            media_files.append(self._create_entry_from_file(file_path))
            else:
                for item in os.listdir(directory_path):
                    item_path = os.path.join(directory_path, item)
                    if os.path.isfile(item_path) and self._is_media_file(item_path):
                        media_files.append(self._create_entry_from_file(item_path))
            
            self.log(f"Encontrados {len(media_files)} arquivos de mídia")
            return media_files
            
        except Exception as e:
            self.log(f"Erro ao escanear diretório: {e}", xbmc.LOGERROR)
            return []
    
    def _is_media_file(self, file_path):
        """Verifica se o arquivo é um arquivo de mídia suportado"""
        try:
            _, ext = os.path.splitext(file_path.lower())
            return ext in self.supported_extensions
        except Exception:
            return False
    
    def _create_entry_from_file(self, file_path):
        """Cria entrada a partir de arquivo local"""
        try:
            filename = os.path.basename(file_path)
            name, ext = os.path.splitext(filename)
            
            entry = {
                'title': name.replace('_', ' ').replace('-', ' ').title(),
                'url': file_path,
                'duration': -1,
                'group': 'Arquivos Locais',
                'logo': '',
                'type': self._detect_media_type(file_path),
                'extra_info': {
                    'file_size': os.path.getsize(file_path),
                    'file_extension': ext
                }
            }
            
            return entry
            
        except Exception as e:
            self.log(f"Erro ao criar entrada para arquivo {file_path}: {e}", xbmc.LOGWARNING)
            return None
    
    def get_entries_by_group(self, group_name=None):
        """Obtém entradas filtradas por grupo"""
        if group_name is None:
            return self.entries
        
        return [entry for entry in self.entries if entry.get('group', '').lower() == group_name.lower()]
    
    def get_groups(self):
        """Obtém lista de grupos únicos"""
        groups = set()
        for entry in self.entries:
            groups.add(entry.get('group', 'Sem Categoria'))
        
        return sorted(list(groups))
    
    def get_entries_by_type(self, media_type):
        """Obtém entradas filtradas por tipo de mídia"""
        return [entry for entry in self.entries if entry.get('type', '').lower() == media_type.lower()]

