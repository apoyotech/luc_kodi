# -*- coding: utf-8 -*-
"""
Módulo M3U para TrainAgain - Extensão modular MELHORADA
Adiciona suporte M3U sem modificar funcionalidades existentes
MELHORIAS: Robustez, tratamento de erros, logs detalhados, validações adicionais
"""

import os
import re
import urllib.parse
import urllib.request
import xbmc
import xbmcvfs

class M3UExtension:
    """Extensão M3U para o plugin TrainAgain - VERSÃO MELHORADA"""
    
    def __init__(self, addon):
        self.addon = addon
        self.entries = []
        self.supported_extensions = ['.mp3', '.mp4', '.avi', '.mkv', '.flv', '.ts', '.m3u8', '.aac', '.flac', '.ogg', '.wav', '.mov', '.wmv']
        self.supported_protocols = ['http', 'https', 'ftp', 'file']
        # MELHORIA: Padrões expandidos para melhor deteção de streams
        self.stream_patterns = [
            'get.php', 'stream.php', 'play.php', 'player.php', 'live.php',
            'channel.php', 'tv.php', 'video.php', 'watch.php', 'streaming.php',
            'playlist.php', 'media.php', 'content.php', 'api.php'
        ]
        self.stream_params = [
            'id=', 'channel=', 'stream=', 'user=', 'pass=', 'token=', 'key=',
            'auth=', 'c=', 'ch=', 'cid=', 'sid=', 'uid=', 'pid='
        ]
        # MELHORIA: Contadores para estatísticas
        self.stats = {
            'total_lines': 0,
            'processed_entries': 0,
            'rejected_urls': 0,
            'categories_found': set()
        }
    
    def log(self, message, level=xbmc.LOGINFO):
        """Log de mensagens melhorado"""
        xbmc.log(f"[TRAINAGAIN-M3U-IMPROVED] {message}", level)
    
    def is_m3u_enabled(self):
        """Verifica se o suporte M3U está habilitado"""
        try:
            enabled = self.addon.getSetting('m3u_enabled').lower() == 'true'
            self.log(f"M3U habilitado: {enabled}")
            return enabled
        except Exception as e:
            self.log(f"Erro ao verificar configuração M3U: {e}", xbmc.LOGERROR)
            return False
    
    def get_m3u_sources(self):
        """Obtém fontes M3U configuradas com validação melhorada"""
        sources = []
        if not self.is_m3u_enabled():
            self.log("M3U desabilitado nas configurações")
            return sources
        
        try:
            for i in range(1, 6):
                source = self.addon.getSetting(f'm3u_source_{i}')
                if source and source.strip():
                    source = source.strip()
                    # MELHORIA: Validação básica da fonte
                    if self._validate_source(source):
                        sources.append(source)
                        self.log(f"Fonte M3U {i} adicionada: {source[:50]}...")
                    else:
                        self.log(f"Fonte M3U {i} inválida: {source[:50]}...", xbmc.LOGWARNING)
            
            self.log(f"Total de fontes M3U válidas: {len(sources)}")
        except Exception as e:
            self.log(f"Erro ao obter fontes M3U: {e}", xbmc.LOGERROR)
        
        return sources
    
    def _validate_source(self, source):
        """MELHORIA: Validação básica de fonte M3U"""
        try:
            # Verificar se é URL válida
            if source.startswith(('http://', 'https://', 'ftp://')):
                parsed = urllib.parse.urlparse(source)
                return bool(parsed.netloc and parsed.scheme)
            
            # Verificar se é ficheiro local
            elif os.path.exists(source) or xbmcvfs.exists(source):
                return True
            
            # Verificar se tem extensão M3U
            elif source.lower().endswith(('.m3u', '.m3u8')):
                return True
            
            return False
        except Exception:
            return False
    
    def get_local_directories(self):
        """Obtém diretórios locais configurados com validação melhorada"""
        directories = []
        try:
            if not self.addon.getSetting('local_media_enabled').lower() == 'true':
                self.log("Mídia local desabilitada nas configurações")
                return directories
            
            for i in range(1, 6):
                directory = self.addon.getSetting(f'local_dir_{i}')
                if directory and directory.strip():
                    directory = directory.strip()
                    if os.path.exists(directory) or xbmcvfs.exists(directory):
                        directories.append(directory)
                        self.log(f"Diretório local {i} adicionado: {directory}")
                    else:
                        self.log(f"Diretório local {i} não encontrado: {directory}", xbmc.LOGWARNING)
            
            self.log(f"Total de diretórios locais válidos: {len(directories)}")
        except Exception as e:
            self.log(f"Erro ao obter diretórios locais: {e}", xbmc.LOGERROR)
        
        return directories
    
    def parse_m3u_file(self, file_path):
        """Parse de arquivo M3U local ou remoto com melhor tratamento de erros"""
        try:
            self.log(f"Iniciando parse do arquivo M3U: {file_path}")
            self.entries = []
            self.stats = {
                'total_lines': 0,
                'processed_entries': 0,
                'rejected_urls': 0,
                'categories_found': set()
            }
            
            content = self._read_file_content(file_path)
            
            if not content:
                self.log(f"Não foi possível ler o arquivo: {file_path}", xbmc.LOGERROR)
                return []
            
            if not content.strip():
                self.log(f"Arquivo vazio: {file_path}", xbmc.LOGWARNING)
                return []
            
            # MELHORIA: Verificar se é realmente um arquivo M3U
            if not self._is_valid_m3u_content(content):
                self.log(f"Conteúdo não parece ser M3U válido: {file_path}", xbmc.LOGWARNING)
                # Continuar mesmo assim, pode ser M3U sem cabeçalho
            
            entries = self._parse_m3u_content(content)
            
            # MELHORIA: Log de estatísticas
            self.log(f"Parse concluído - Linhas: {self.stats['total_lines']}, "
                    f"Entradas: {self.stats['processed_entries']}, "
                    f"Rejeitadas: {self.stats['rejected_urls']}, "
                    f"Categorias: {len(self.stats['categories_found'])}")
            
            return entries
            
        except Exception as e:
            self.log(f"Erro ao processar arquivo M3U: {e}", xbmc.LOGERROR)
            return []
    
    def _is_valid_m3u_content(self, content):
        """MELHORIA: Verificar se o conteúdo parece ser M3U válido"""
        try:
            lines = content.split('\n')
            # Verificar se tem cabeçalho M3U ou entradas EXTINF
            for line in lines[:10]:  # Verificar primeiras 10 linhas
                line = line.strip()
                if line.startswith('#EXTM3U') or line.startswith('#EXTINF'):
                    return True
            
            # Se não tem cabeçalho, verificar se tem URLs válidas
            url_count = 0
            for line in lines:
                line = line.strip()
                if line and not line.startswith('#'):
                    if self._looks_like_url(line):
                        url_count += 1
                        if url_count >= 2:  # Se tem pelo menos 2 URLs, provavelmente é M3U
                            return True
            
            return False
        except Exception:
            return True  # Em caso de erro, assumir que é válido
    
    def _looks_like_url(self, line):
        """MELHORIA: Verificar se uma linha parece ser uma URL"""
        try:
            return (line.startswith(('http://', 'https://', 'ftp://')) or 
                   os.path.isabs(line) or 
                   '.' in line)
        except Exception:
            return False
    
    def _read_file_content(self, file_path):
        """Lê conteúdo de arquivo local ou remoto com melhor tratamento de erros"""
        try:
            # MELHORIA: Normalizar caminho
            file_path = file_path.strip()
            
            # Verificar se é URL
            if file_path.startswith(('http://', 'https://', 'ftp://')):
                self.log(f"Baixando M3U de URL: {file_path}")
                try:
                    # MELHORIA: Headers para evitar bloqueios
                    req = urllib.request.Request(file_path, headers={
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                    })
                    with urllib.request.urlopen(req, timeout=30) as response:
                        content = response.read()
                        # MELHORIA: Tentar diferentes encodings
                        for encoding in ['utf-8', 'latin-1', 'cp1252']:
                            try:
                                return content.decode(encoding)
                            except UnicodeDecodeError:
                                continue
                        # Se nenhum encoding funcionou, usar utf-8 com ignore
                        return content.decode('utf-8', errors='ignore')
                except urllib.error.URLError as e:
                    self.log(f"Erro ao baixar URL {file_path}: {e}", xbmc.LOGERROR)
                    return None
            
            # Arquivo local
            elif os.path.exists(file_path):
                self.log(f"Lendo arquivo M3U local: {file_path}")
                # MELHORIA: Tentar diferentes encodings
                for encoding in ['utf-8', 'latin-1', 'cp1252']:
                    try:
                        with open(file_path, 'r', encoding=encoding) as f:
                            return f.read()
                    except UnicodeDecodeError:
                        continue
                # Se nenhum encoding funcionou, usar utf-8 com ignore
                with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                    return f.read()
            
            # Tentar com xbmcvfs para compatibilidade com Kodi
            elif xbmcvfs.exists(file_path):
                self.log(f"Lendo arquivo M3U via xbmcvfs: {file_path}")
                file_obj = xbmcvfs.File(file_path)
                content = file_obj.read()
                file_obj.close()
                # MELHORIA: Tentar diferentes encodings
                if isinstance(content, bytes):
                    for encoding in ['utf-8', 'latin-1', 'cp1252']:
                        try:
                            return content.decode(encoding)
                        except UnicodeDecodeError:
                            continue
                    return content.decode('utf-8', errors='ignore')
                return content
            
            else:
                self.log(f"Arquivo não encontrado: {file_path}", xbmc.LOGERROR)
                return None
                
        except Exception as e:
            self.log(f"Erro ao ler arquivo {file_path}: {e}", xbmc.LOGERROR)
            return None
    
    def _parse_m3u_content(self, content):
        """Parse do conteúdo M3U com melhor tratamento de erros"""
        entries = []
        lines = content.split('\n')
        current_entry = {}
        
        self.stats['total_lines'] = len(lines)
        self.log(f"Iniciando parse de {len(lines)} linhas")
        
        for line_num, line in enumerate(lines, 1):
            try:
                line = line.strip()
                
                if not line:
                    continue
                
                # Cabeçalho M3U
                if line.startswith('#EXTM3U'):
                    self.log("Encontrado cabeçalho M3U")
                    continue
                
                # Informações da entrada
                elif line.startswith('#EXTINF:'):
                    current_entry = self._parse_extinf_line(line)
                    if current_entry.get('group'):
                        self.stats['categories_found'].add(current_entry['group'])
                
                # Outras tags M3U
                elif line.startswith('#EXT'):
                    self._parse_ext_tag(line, current_entry)
                
                # URL/caminho do arquivo
                elif not line.startswith('#'):
                    # MELHORIA: Melhor validação de URLs
                    if current_entry or self._is_valid_media_url(line):
                        if not current_entry:
                            # MELHORIA: Criar entrada automática mais inteligente
                            current_entry = self._create_auto_entry(line)
                        
                        current_entry['url'] = line.strip()
                        current_entry['type'] = self._detect_media_type(line)
                        
                        # MELHORIA: Validação final da entrada
                        if self._validate_entry(current_entry):
                            entries.append(current_entry)
                            self.stats['processed_entries'] += 1
                            
                            if current_entry.get('group'):
                                self.stats['categories_found'].add(current_entry['group'])
                        else:
                            self.log(f"Entrada inválida rejeitada na linha {line_num}: {current_entry.get('title', 'Sem título')}", xbmc.LOGWARNING)
                        
                        current_entry = {}
                    else:
                        self.stats['rejected_urls'] += 1
                        self.log(f"URL rejeitada na linha {line_num}: {line[:50]}...", xbmc.LOGDEBUG)
            
            except Exception as e:
                self.log(f"Erro ao processar linha {line_num}: {e}", xbmc.LOGWARNING)
                continue
        
        self.entries = entries
        self.log(f"Parse concluído: {len(entries)} entradas válidas processadas")
        return entries
    
    def _create_auto_entry(self, url):
        """MELHORIA: Criar entrada automática mais inteligente"""
        return {
            'title': self._extract_title_from_url(url),
            'duration': -1,
            'group': 'Sem Categoria',
            'logo': '',
            'extra_info': {},
            'auto_created': True  # Marcar como criada automaticamente
        }
    
    def _validate_entry(self, entry):
        """MELHORIA: Validar entrada antes de adicionar"""
        try:
            # Verificar campos obrigatórios
            if not entry.get('url'):
                return False
            
            if not entry.get('title'):
                return False
            
            # Verificar se URL é válida
            if not self._is_valid_media_url(entry['url']):
                return False
            
            return True
        except Exception:
            return False
    
    def _parse_extinf_line(self, line):
        """Parse da linha EXTINF com melhor tratamento de erros"""
        entry = {
            'duration': -1,
            'title': '',
            'group': 'Sem Categoria',
            'logo': '',
            'extra_info': {}
        }
        
        try:
            # Remover #EXTINF:
            line = line[8:]
            
            # MELHORIA: Melhor parsing de atributos
            if ' ' in line and ('=' in line or ',' in line):
                # Tentar extrair duração primeiro
                duration_match = re.match(r'^(-?\d+(?:\.\d+)?)', line)
                if duration_match:
                    try:
                        entry['duration'] = float(duration_match.group(1))
                        line = line[len(duration_match.group(1)):].strip()
                    except ValueError:
                        pass
                
                # Procurar por vírgula que separa atributos do título
                comma_pos = -1
                in_quotes = False
                for i, char in enumerate(line):
                    if char == '"':
                        in_quotes = not in_quotes
                    elif char == ',' and not in_quotes:
                        comma_pos = i
                        break
                
                if comma_pos > 0:
                    attr_part = line[:comma_pos]
                    title_part = line[comma_pos + 1:].strip()
                    
                    # Extrair atributos
                    attr_pattern = r'(\w+(?:-\w+)*)="([^"]*)"'
                    for match in re.finditer(attr_pattern, attr_part):
                        attr_name = match.group(1).lower()
                        attr_value = match.group(2)
                        
                        if attr_name == 'tvg-logo':
                            entry['logo'] = attr_value
                        elif attr_name == 'group-title':
                            entry['group'] = attr_value if attr_value else 'Sem Categoria'
                        elif attr_name in ['tvg-id', 'tvg-name', 'tvg-shift']:
                            entry['extra_info'][attr_name] = attr_value
                        else:
                            entry['extra_info'][attr_name] = attr_value
                    
                    entry['title'] = title_part if title_part else 'Sem Título'
                else:
                    # Sem vírgula, toda a linha é o título
                    entry['title'] = line.strip() if line.strip() else 'Sem Título'
            else:
                # Linha simples: duração,título
                parts = line.split(',', 1)
                if len(parts) >= 1:
                    try:
                        entry['duration'] = float(parts[0])
                    except ValueError:
                        entry['duration'] = -1
                
                if len(parts) >= 2:
                    entry['title'] = parts[1].strip() if parts[1].strip() else 'Sem Título'
                else:
                    entry['title'] = 'Sem Título'
        
        except Exception as e:
            self.log(f"Erro ao processar linha EXTINF: {e}", xbmc.LOGWARNING)
            entry['title'] = 'Sem Título'
        
        return entry
    
    def _parse_ext_tag(self, line, current_entry):
        """Parse de outras tags EXT com melhorias"""
        try:
            if line.startswith('#EXT-X-'):
                # Tags específicas de HLS
                if 'EXT-X-STREAM-INF' in line:
                    # Informações de stream
                    bandwidth_match = re.search(r'BANDWIDTH=(\d+)', line)
                    if bandwidth_match:
                        current_entry['extra_info']['bandwidth'] = int(bandwidth_match.group(1))
                    
                    resolution_match = re.search(r'RESOLUTION=(\d+x\d+)', line)
                    if resolution_match:
                        current_entry['extra_info']['resolution'] = resolution_match.group(1)
            
            # MELHORIA: Suporte para outras tags comuns
            elif line.startswith('#EXTGRP:'):
                # Grupo alternativo
                group = line[8:].strip()
                if group and not current_entry.get('group') or current_entry.get('group') == 'Sem Categoria':
                    current_entry['group'] = group
        
        except Exception as e:
            self.log(f"Erro ao processar tag EXT: {e}", xbmc.LOGDEBUG)
    
    def _is_valid_media_url(self, url):
        """Verifica se a URL é um arquivo de mídia válido com melhor deteção"""
        try:
            if not url or not url.strip():
                return False
            
            url = url.strip()
            url_lower = url.lower()
            parsed_url = urllib.parse.urlparse(url_lower)
            path = parsed_url.path
            query = parsed_url.query
            
            # MELHORIA: Verificar extensões suportadas
            for ext in self.supported_extensions:
                if path.endswith(ext):
                    return True
            
            # MELHORIA: Verificar protocolos suportados
            if parsed_url.scheme in self.supported_protocols:
                # Verificar padrões de stream
                for pattern in self.stream_patterns:
                    if pattern in path:
                        return True
                
                # Verificar parâmetros de stream
                for param in self.stream_params:
                    if param in query:
                        return True
                
                # Verificar se tem query string significativa
                if query and len(query) > 3:
                    return True
                
                # MELHORIA: Verificar se path parece ser de mídia
                if re.search(r'\.(php|asp|jsp|cgi)$', path):
                    return True
            
            # Verificar arquivo local
            if os.path.exists(url):
                return True
            
            # MELHORIA: Verificar URLs que terminam com números (IDs de stream)
            if re.search(r'/\d+$', path) and parsed_url.scheme in self.supported_protocols:
                return True
            
            # MELHORIA: Verificar se parece ser um caminho de arquivo válido
            if os.path.isabs(url) and any(ext in url_lower for ext in self.supported_extensions):
                return True
            
            return False
            
        except Exception as e:
            self.log(f"Erro ao validar URL {url}: {e}", xbmc.LOGDEBUG)
            return False
    
    def _extract_title_from_url(self, url):
        """Extrai título do nome do arquivo na URL com melhorias"""
        try:
            parsed_url = urllib.parse.urlparse(url)
            
            # MELHORIA: Tentar extrair título de parâmetros primeiro
            query_params = urllib.parse.parse_qs(parsed_url.query)
            
            # Procurar parâmetros comuns que podem conter o nome
            for param_name in ['name', 'title', 'channel', 'stream', 'ch', 'c']:
                if param_name in query_params:
                    title = query_params[param_name][0]
                    if title and len(title) > 1:
                        return self._clean_title(title)
            
            # Se não encontrou nos parâmetros, usar o nome do arquivo
            filename = os.path.basename(parsed_url.path)
            
            if filename and filename not in ['get.php', 'stream.php', 'play.php', 'player.php']:
                # Remover extensão
                name, _ = os.path.splitext(filename)
                if name:
                    return self._clean_title(name)
            
            # Para scripts PHP e similares, tentar usar o host
            if parsed_url.netloc:
                return f"Stream {parsed_url.netloc}"
            else:
                return "Stream"
                
        except Exception:
            return "Mídia"
    
    def _clean_title(self, title):
        """MELHORIA: Limpar e formatar título"""
        try:
            # Substituir caracteres comuns
            title = title.replace('_', ' ').replace('-', ' ').replace('.', ' ')
            # Remover espaços extras
            title = ' '.join(title.split())
            # Capitalizar
            return title.title() if title else "Sem Título"
        except Exception:
            return "Sem Título"
    
    def _detect_media_type(self, url):
        """Detecta o tipo de mídia baseado na URL com melhor precisão"""
        try:
            url_lower = url.lower()
            parsed_url = urllib.parse.urlparse(url_lower)
            path = parsed_url.path
            query = parsed_url.query
            
            # MELHORIA: Verificar extensões específicas
            if any(ext in url_lower for ext in ['.mp3', '.aac', '.flac', '.ogg', '.wav']):
                return 'audio'
            elif any(ext in url_lower for ext in ['.mp4', '.avi', '.mkv', '.flv', '.ts', '.mov', '.wmv']):
                return 'video'
            elif '.m3u8' in url_lower:
                return 'hls'
            
            # MELHORIA: Verificar padrões de stream específicos
            elif any(pattern in path for pattern in self.stream_patterns):
                # Tentar determinar se é TV, filme ou outro
                if any(keyword in query.lower() for keyword in ['tv', 'channel', 'live']):
                    return 'live_tv'
                elif any(keyword in query.lower() for keyword in ['movie', 'film']):
                    return 'movie'
                else:
                    return 'stream'
            
            # MELHORIA: Verificar por parâmetros
            elif any(param in query for param in ['channel=', 'tv=', 'live=']):
                return 'live_tv'
            elif any(param in query for param in ['movie=', 'film=']):
                return 'movie'
            elif any(param in query for param in ['audio=', 'music=']):
                return 'audio'
            
            # Padrão
            else:
                return 'unknown'
                
        except Exception:
            return 'unknown'
    
    def scan_local_directory(self, directory_path, recursive=False):
        """Escanear diretório local para arquivos de mídia com melhorias"""
        entries = []
        
        try:
            self.log(f"Escaneando diretório: {directory_path} (recursivo: {recursive})")
            
            if not os.path.exists(directory_path):
                self.log(f"Diretório não encontrado: {directory_path}", xbmc.LOGERROR)
                return entries
            
            # MELHORIA: Usar os.walk para recursivo ou os.listdir para não recursivo
            if recursive:
                for root, dirs, files in os.walk(directory_path):
                    for file in files:
                        file_path = os.path.join(root, file)
                        if self._is_media_file(file_path):
                            entry = self._create_entry_from_file(file_path, directory_path)
                            if entry:
                                entries.append(entry)
            else:
                for item in os.listdir(directory_path):
                    item_path = os.path.join(directory_path, item)
                    if os.path.isfile(item_path) and self._is_media_file(item_path):
                        entry = self._create_entry_from_file(item_path, directory_path)
                        if entry:
                            entries.append(entry)
            
            self.log(f"Encontrados {len(entries)} arquivos de mídia em {directory_path}")
            
        except Exception as e:
            self.log(f"Erro ao escanear diretório {directory_path}: {e}", xbmc.LOGERROR)
        
        return entries
    
    def _is_media_file(self, file_path):
        """MELHORIA: Verificar se é arquivo de mídia"""
        try:
            _, ext = os.path.splitext(file_path.lower())
            return ext in self.supported_extensions
        except Exception:
            return False
    
    def _create_entry_from_file(self, file_path, base_directory):
        """MELHORIA: Criar entrada a partir de arquivo local"""
        try:
            filename = os.path.basename(file_path)
            name, _ = os.path.splitext(filename)
            
            # Determinar categoria baseada no caminho
            rel_path = os.path.relpath(file_path, base_directory)
            category = os.path.dirname(rel_path) if os.path.dirname(rel_path) else 'Local'
            
            return {
                'title': self._clean_title(name),
                'url': file_path,
                'group': category,
                'logo': '',
                'duration': -1,
                'type': self._detect_media_type(file_path),
                'extra_info': {
                    'file_size': self._get_file_size(file_path)
                }
            }
        except Exception as e:
            self.log(f"Erro ao criar entrada para arquivo {file_path}: {e}", xbmc.LOGWARNING)
            return None
    
    def _get_file_size(self, file_path):
        """MELHORIA: Obter tamanho do arquivo"""
        try:
            size = os.path.getsize(file_path)
            # Converter para formato legível
            for unit in ['B', 'KB', 'MB', 'GB']:
                if size < 1024.0:
                    return f"{size:.1f} {unit}"
                size /= 1024.0
            return f"{size:.1f} TB"
        except Exception:
            return "Desconhecido"
    
    def get_statistics(self):
        """MELHORIA: Obter estatísticas do último parse"""
        return self.stats.copy()

