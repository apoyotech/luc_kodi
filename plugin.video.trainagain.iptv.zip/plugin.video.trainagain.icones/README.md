# GRUPO TRAINAGAIN - Múltiplos Portais MAC

## Versão 3.6.1 - Suporte para Múltiplos MACs

### ✅ Funcionalidades Implementadas

#### 🔌 Múltiplos Portais MAC (7 Configurações)
- **Portal Principal**: Configuração original mantida
- **Portais 2-7**: Configurações adicionais independentes
- **Seleção Dinâmica**: Menu automático baseado em portais configurados
- **User-Agent Individual**: Cada portal pode ter seu próprio User-Agent

#### 📱 User-Agents Suportados
- **MAG200**: Para servidores antigos
- **MAG250**: Máxima compatibilidade (padrão)
- **MAG254**: Modelo popular
- **MAG256**: Versão melhorada
- **MAG322**: Modelo moderno
- **MAG324**: Versão avançada
- **MAG349**: Última geração
- **MAG351**: Mais recente
- **Custom**: Personalizado

#### 🎯 Configuração Simplificada
- Interface organizada por portal
- Configurações globais (timeout, tentativas)
- Ativação individual de cada portal
- Nomes personalizáveis para cada portal

### 🔧 Como Configurar

1. **Aceder às Configurações**
   - Abrir addon GRUPO TRAINAGAIN
   - Ir para "Configurações"
   - Selecionar categoria "Stalker Portal"

2. **Configurar Portal Principal**
   - Ativar "Ativar Stalker Portal"
   - Inserir URL do portal
   - Inserir endereço MAC
   - Escolher User-Agent apropriado

3. **Configurar Portais Adicionais**
   - Ativar "MAC 2 - Ativar" (ou MAC 3, 4, 5, 6, 7)
   - Definir nome personalizado
   - Inserir URL do portal
   - Inserir endereço MAC
   - Escolher User-Agent específico

### 🚀 Utilização

#### Menu Principal
- **Portal Único**: Mostra "🔌 Stalker Portal"
- **Múltiplos Portais**: Mostra "🔌 Portais MAC"

#### Navegação
1. Selecionar portal desejado
2. Escolher "📺 Géneros/Categorias"
3. Selecionar categoria
4. Escolher canal para reproduzir

### ⚡ Melhorias Técnicas

#### MacManager Melhorado
- Suporte para múltiplas configurações
- Gestão independente de tokens
- User-Agent configurável por portal
- Tratamento de erros melhorado

#### Interface Otimizada
- Menus dinâmicos baseados em configuração
- Ícones e fanart consistentes
- Informações detalhadas de cada portal
- Navegação intuitiva

### 🔄 Compatibilidade

#### ✅ Mantido
- **Xtream Codes**: Todas as funcionalidades preservadas
- **M3U Playlists**: Suporte completo mantido
- **Mídia Local**: Navegação e reprodução
- **Configurações Existentes**: Migração automática

#### ✅ Melhorado
- **Reprodução**: inputstream.adaptive otimizado
- **Autenticação**: Headers melhorados
- **Logos**: Suporte para logos de canais
- **Estabilidade**: Tratamento de erros robusto

### 📋 Exemplo de Configuração

```
Portal Principal:
- URL: http://portal1.exemplo.com:8080/
- MAC: 00:1a:79:12:34:56
- User-Agent: MAG250

Portal 2:
- Nome: "Servidor Backup"
- URL: http://portal2.exemplo.com:8080/
- MAC: 00:1a:79:12:34:57
- User-Agent: MAG254

Portal 3:
- Nome: "Servidor Internacional"
- URL: http://portal3.exemplo.com:8080/
- MAC: 00:1a:79:12:34:58
- User-Agent: MAG322
```

### 🎯 Benefícios

1. **Redundância**: Múltiplos servidores para maior disponibilidade
2. **Organização**: Separação por tipo de conteúdo ou região
3. **Flexibilidade**: User-Agents específicos para cada servidor
4. **Simplicidade**: Interface unificada para todos os portais
5. **Compatibilidade**: Funciona com servidores antigos e modernos



## Xtream Codes - Detalhes Adicionais

### Tipos de Player Suportados:
O addon é compatível com os seguintes tipos de player para streams Xtream Codes:
- **HLS (HTTP Live Streaming)**: Formato comum para streaming adaptativo.
- **MPEG-TS (Transport Stream)**: Utilizado para transmissão de vídeo e áudio.
- **RTMP (Real-Time Messaging Protocol)**: Protocolo para streaming de áudio, vídeo e dados.

### Configuração de Streams:
As configurações de Xtream Codes permitem a gestão de streams ao vivo, filmes e séries, com opções para:
- **Seleção de Qualidade**: Ajuste automático ou manual da qualidade do vídeo com base na sua conexão.
- **Legendas e Áudio**: Suporte para múltiplas faixas de áudio e legendas, se disponíveis no stream.

### Otimização de Conexão:
- **Timeout e Tentativas**: Definições personalizáveis para o tempo limite de conexão e o número de tentativas de reconexão, garantindo uma experiência de visualização mais estável.
- **User-Agent Personalizado**: Possibilidade de definir um User-Agent específico para as conexões Xtream Codes, o que pode ser útil para compatibilidade com certos servidores.


### 📞 Suporte

- **Telegram**: t.me/TrainAgain
- **Versão**: 3.4.0
- **Data**: 11 de Junho de 2025
- **Criado por**: @TrainAgain


