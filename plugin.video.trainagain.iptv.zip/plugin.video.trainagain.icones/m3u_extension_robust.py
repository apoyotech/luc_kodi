# -*- coding: utf-8 -*-
"""
Módulo M3U Extension - Versão Robusta para Detecção de Ficheiros M3U Locais
"""

import os
import re
import urllib.parse
import xbmc
import xbmcaddon

class M3UExtensionRobust:
    """Versão robusta do M3U Extension com detecção melhorada"""
    
    def __init__(self, addon):
        self.addon = addon
        # LISTA COMPLETA de extensões suportadas
        self.supported_extensions = [
            '.m3u', '.m3u8',  # Playlists M3U (prioridade máxima)
            '.mp4', '.avi', '.mkv', '.mov', '.wmv', '.flv', '.webm',  # Vídeo
            '.mp3', '.aac', '.flac', '.ogg', '.wav', '.wma',  # Áudio
            '.ts', '.m2ts', '.mts'  # Transport Stream
        ]
        
    def log(self, message, level=xbmc.LOGINFO):
        """Log melhorado"""
        xbmc.log(f"[M3U-ROBUST] {message}", level)
    
    def scan_local_directory_robust(self, directory_path, recursive=False):
        """Versão robusta de scan de diretório com detecção melhorada"""
        self.log(f"=== SCAN ROBUSTO INICIADO ===")
        self.log(f"Diretório: {directory_path}")
        self.log(f"Recursivo: {recursive}")
        
        media_files = []
        
        try:
            if not os.path.exists(directory_path):
                self.log(f"ERRO: Diretório não existe: {directory_path}", xbmc.LOGERROR)
                return []
            
            if not os.path.isdir(directory_path):
                self.log(f"ERRO: Caminho não é um diretório: {directory_path}", xbmc.LOGERROR)
                return []
            
            # Listar TODOS os ficheiros no diretório
            all_items = []
            try:
                all_items = os.listdir(directory_path)
                self.log(f"Total de itens encontrados: {len(all_items)}")
            except Exception as e:
                self.log(f"ERRO ao listar diretório: {e}", xbmc.LOGERROR)
                return []
            
            # Processar cada item
            for item in all_items:
                item_path = os.path.join(directory_path, item)
                self.log(f"Processando item: {item}")
                
                try:
                    if os.path.isfile(item_path):
                        # VERIFICAÇÃO ROBUSTA de ficheiro de mídia
                        if self._is_media_file_robust(item_path):
                            entry = self._create_entry_from_file_robust(item_path)
                            if entry:
                                media_files.append(entry)
                                self.log(f"✅ Ficheiro adicionado: {item} (Tipo: {entry.get('type', 'unknown')})")
                            else:
                                self.log(f"❌ Falha ao criar entrada para: {item}")
                        else:
                            self.log(f"⏭️ Ficheiro ignorado (não é mídia): {item}")
                    elif os.path.isdir(item_path) and recursive:
                        # Scan recursivo se solicitado
                        sub_files = self.scan_local_directory_robust(item_path, recursive=True)
                        media_files.extend(sub_files)
                        
                except Exception as e:
                    self.log(f"ERRO ao processar item {item}: {e}", xbmc.LOGWARNING)
                    continue
            
            self.log(f"=== SCAN CONCLUÍDO ===")
            self.log(f"Total de ficheiros de mídia encontrados: {len(media_files)}")
            
            # Log detalhado dos ficheiros encontrados
            for i, entry in enumerate(media_files):
                self.log(f"  {i+1}. {entry.get('title', 'Sem título')} ({entry.get('type', 'unknown')})")
            
            return media_files
            
        except Exception as e:
            self.log(f"ERRO CRÍTICO no scan: {e}", xbmc.LOGERROR)
            return []
    
    def _is_media_file_robust(self, file_path):
        """Verificação robusta se o ficheiro é de mídia"""
        try:
            # Verificar se o ficheiro existe
            if not os.path.exists(file_path):
                self.log(f"Ficheiro não existe: {file_path}", xbmc.LOGDEBUG)
                return False
            
            # Verificar se é realmente um ficheiro
            if not os.path.isfile(file_path):
                self.log(f"Não é um ficheiro: {file_path}", xbmc.LOGDEBUG)
                return False
            
            # Extrair extensão
            _, ext = os.path.splitext(file_path.lower())
            
            # Log da verificação
            self.log(f"Verificando ficheiro: {os.path.basename(file_path)} | Extensão: {ext}")
            
            # Verificar se a extensão está suportada
            is_supported = ext in self.supported_extensions
            
            if is_supported:
                self.log(f"✅ EXTENSÃO SUPORTADA: {ext} para ficheiro {os.path.basename(file_path)}")
            else:
                self.log(f"❌ Extensão não suportada: {ext} para ficheiro {os.path.basename(file_path)}")
            
            return is_supported
            
        except Exception as e:
            self.log(f"ERRO na verificação de ficheiro {file_path}: {e}", xbmc.LOGWARNING)
            return False
    
    def _create_entry_from_file_robust(self, file_path):
        """Criação robusta de entrada a partir de ficheiro"""
        try:
            if not os.path.exists(file_path):
                self.log(f"ERRO: Ficheiro não existe para criar entrada: {file_path}", xbmc.LOGERROR)
                return None
            
            # Informações básicas do ficheiro
            file_name = os.path.basename(file_path)
            file_size = os.path.getsize(file_path)
            _, ext = os.path.splitext(file_path.lower())
            
            # Determinar tipo de mídia
            media_type = self._detect_media_type_robust(file_path)
            
            # Criar título limpo
            title = self._extract_clean_title(file_name)
            
            # Criar entrada
            entry = {
                'title': title,
                'url': file_path,
                'type': media_type,
                'group': 'Local Files',
                'logo': '',
                'file_size': file_size,
                'file_extension': ext,
                'file_name': file_name
            }
            
            self.log(f"Entrada criada: {title} | Tipo: {media_type} | Tamanho: {file_size} bytes")
            
            return entry
            
        except Exception as e:
            self.log(f"ERRO ao criar entrada para {file_path}: {e}", xbmc.LOGERROR)
            return None
    
    def _detect_media_type_robust(self, file_path):
        """Detecção robusta do tipo de mídia"""
        try:
            _, ext = os.path.splitext(file_path.lower())
            
            # Mapeamento de extensões para tipos
            type_mapping = {
                # Playlists (prioridade máxima)
                '.m3u': 'playlist',
                '.m3u8': 'hls',
                
                # Vídeo
                '.mp4': 'video',
                '.avi': 'video',
                '.mkv': 'video',
                '.mov': 'video',
                '.wmv': 'video',
                '.flv': 'video',
                '.webm': 'video',
                '.ts': 'video',
                '.m2ts': 'video',
                '.mts': 'video',
                
                # Áudio
                '.mp3': 'audio',
                '.aac': 'audio',
                '.flac': 'audio',
                '.ogg': 'audio',
                '.wav': 'audio',
                '.wma': 'audio'
            }
            
            detected_type = type_mapping.get(ext, 'unknown')
            self.log(f"Tipo detectado para {ext}: {detected_type}")
            
            return detected_type
            
        except Exception as e:
            self.log(f"ERRO na detecção de tipo para {file_path}: {e}", xbmc.LOGWARNING)
            return 'unknown'
    
    def _extract_clean_title(self, file_name):
        """Extrai título limpo do nome do ficheiro"""
        try:
            # Remover extensão
            title = os.path.splitext(file_name)[0]
            
            # Substituir underscores e pontos por espaços
            title = title.replace('_', ' ').replace('.', ' ')
            
            # Remover espaços múltiplos
            title = re.sub(r'\s+', ' ', title).strip()
            
            # Se o título estiver vazio, usar o nome do ficheiro
            if not title:
                title = file_name
            
            return title
            
        except Exception as e:
            self.log(f"ERRO ao extrair título de {file_name}: {e}", xbmc.LOGWARNING)
            return file_name

