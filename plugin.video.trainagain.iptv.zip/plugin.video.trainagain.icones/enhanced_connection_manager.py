"""
Enhanced Connection Manager for IPTV Streaming
Baseado na análise do IPTV Extreme
Versão 2.0 - Melhorias de compatibilidade
"""

import requests
import time
import random
import os
import json
import xbmc
import xbmcvfs
from urllib.parse import urlparse, parse_qs, urlencode, urlunparse

class EnhancedConnectionManager:
    def __init__(self):
        self.user_agents = [
            # User-Agents do IPTV Extreme
            'Mozilla/5.0 (Linux; Android 10; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.120 Mobile Safari/537.36',
            'Mozilla/5.0 (Linux; Android 11; Pixel 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Mobile Safari/537.36',
            'Mozilla/5.0 (Linux; Android 9; SM-A505FN) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.210 Mobile Safari/537.36',
            'VLC/3.0.16 LibVLC/3.0.16',
            'ExoPlayerLib/2.18.1',
            'IPTV Extreme Pro/129.0',
            # User-Agents MAG
            'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3',
            'Mozilla/5.0 (DirectFB; Linux; ko-KR) AppleWebKit/534.26+ (KHTML, like Gecko) Version/5.0 Safari/534.26+ MAG250',
            'Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/534.26+ (KHTML, like Gecko) Version/5.0 Safari/534.26+ MAG254',
            'Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/537.36 (KHTML, like Gecko) Version/5.0 Safari/537.36 MAG256'
        ]
        
        # Configurações padrão
        self.default_timeout = 30
        self.max_retries = 3
        self.retry_delay = 2
        self.cache_enabled = True
        self.cache_duration = 3600  # 1 hora em segundos
        
        # Inicializar cache
        self.cache_dir = xbmcvfs.translatePath('special://temp/trainagain_cache/')
        if not os.path.exists(self.cache_dir):
            os.makedirs(self.cache_dir)
        
        xbmc.log("[TrainAgain-ECM] Enhanced Connection Manager 2.0 inicializado", xbmc.LOGINFO)
    
    def get_random_user_agent(self):
        """Retorna um User-Agent aleatório"""
        return random.choice(self.user_agents)
    
    def create_session(self, timeout=None):
        """Cria uma sessão HTTP otimizada"""
        session = requests.Session()
        
        # Headers baseados no IPTV Extreme
        session.headers.update({
            'User-Agent': self.get_random_user_agent(),
            'Accept': '*/*',
            'Accept-Language': 'pt-PT,pt;q=0.9,en;q=0.8',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Cache-Control': 'no-cache'
        })
        
        # Configurar timeout
        if timeout is None:
            timeout = self.default_timeout
            
        session.timeout = timeout
        
        return session
    
    def _get_cache_key(self, url, method, data=None):
        """Gera uma chave única para cache baseada na URL e parâmetros"""
        key = f"{method}_{url}"
        if data:
            if isinstance(data, dict):
                key += "_" + json.dumps(data, sort_keys=True)
            else:
                key += "_" + str(data)
        return key.replace('/', '_').replace(':', '_').replace('?', '_').replace('&', '_')[:100]
    
    def _get_from_cache(self, cache_key):
        """Recupera dados do cache se disponível e válido"""
        if not self.cache_enabled:
            return None
            
        cache_file = os.path.join(self.cache_dir, cache_key + '.json')
        
        if os.path.exists(cache_file):
            try:
                with open(cache_file, 'r') as f:
                    cache_data = json.load(f)
                
                # Verificar validade do cache
                if time.time() - cache_data['timestamp'] < self.cache_duration:
                    xbmc.log(f"[TrainAgain-ECM] Cache hit: {cache_key}", xbmc.LOGDEBUG)
                    return cache_data['data']
                else:
                    xbmc.log(f"[TrainAgain-ECM] Cache expirado: {cache_key}", xbmc.LOGDEBUG)
                    os.remove(cache_file)
            except Exception as e:
                xbmc.log(f"[TrainAgain-ECM] Erro ao ler cache: {e}", xbmc.LOGWARNING)
                try:
                    os.remove(cache_file)
                except:
                    pass
        
        return None
    
    def _save_to_cache(self, cache_key, data):
        """Salva dados no cache"""
        if not self.cache_enabled:
            return
            
        cache_file = os.path.join(self.cache_dir, cache_key + '.json')
        
        try:
            cache_data = {
                'timestamp': time.time(),
                'data': data
            }
            
            with open(cache_file, 'w') as f:
                json.dump(cache_data, f)
                
            xbmc.log(f"[TrainAgain-ECM] Cache salvo: {cache_key}", xbmc.LOGDEBUG)
        except Exception as e:
            xbmc.log(f"[TrainAgain-ECM] Erro ao salvar cache: {e}", xbmc.LOGWARNING)
    
    def enhanced_request(self, url, method='GET', headers=None, data=None, timeout=None, 
                         max_retries=None, use_cache=True, cache_duration=None):
        """
        Faz requisição HTTP com retry inteligente e cache
        Baseado no sistema do IPTV Extreme
        """
        # Configurar parâmetros
        if max_retries is None:
            max_retries = self.max_retries
            
        if timeout is None:
            timeout = self.default_timeout
        
        if cache_duration is not None:
            old_cache_duration = self.cache_duration
            self.cache_duration = cache_duration
        
        # Verificar cache para GET requests
        if method.upper() == 'GET' and use_cache and self.cache_enabled:
            cache_key = self._get_cache_key(url, method, data)
            cached_data = self._get_from_cache(cache_key)
            
            if cached_data:
                # Criar resposta simulada do cache
                response = requests.Response()
                response.status_code = 200
                response._content = cached_data.encode('utf-8') if isinstance(cached_data, str) else cached_data
                response.url = url
                
                # Restaurar cache_duration se foi alterado
                if cache_duration is not None:
                    self.cache_duration = old_cache_duration
                    
                return response
        
        # Criar sessão
        session = self.create_session(timeout)
        
        # Adicionar headers customizados
        if headers:
            session.headers.update(headers)
        
        last_exception = None
        
        for attempt in range(max_retries + 1):
            try:
                if method.upper() == 'GET':
                    response = session.get(url, timeout=timeout)
                elif method.upper() == 'POST':
                    response = session.post(url, data=data, timeout=timeout)
                else:
                    response = session.request(method, url, data=data, timeout=timeout)
                
                # Verificar se a resposta é válida
                if response.status_code == 200:
                    # Salvar no cache se for GET
                    if method.upper() == 'GET' and use_cache and self.cache_enabled:
                        cache_key = self._get_cache_key(url, method, data)
                        self._save_to_cache(cache_key, response.text)
                    
                    # Restaurar cache_duration se foi alterado
                    if cache_duration is not None:
                        self.cache_duration = old_cache_duration
                        
                    return response
                elif response.status_code in [403, 404, 500, 502, 503, 504]:
                    # Códigos que podem se beneficiar de retry
                    if attempt < max_retries:
                        time.sleep(self.retry_delay * (attempt + 1))
                        # Trocar User-Agent para próxima tentativa
                        session.headers['User-Agent'] = self.get_random_user_agent()
                        continue
                    else:
                        # Restaurar cache_duration se foi alterado
                        if cache_duration is not None:
                            self.cache_duration = old_cache_duration
                            
                        return response
                else:
                    # Restaurar cache_duration se foi alterado
                    if cache_duration is not None:
                        self.cache_duration = old_cache_duration
                        
                    return response
                    
            except (requests.exceptions.Timeout, 
                    requests.exceptions.ConnectionError,
                    requests.exceptions.RequestException) as e:
                last_exception = e
                if attempt < max_retries:
                    time.sleep(self.retry_delay * (attempt + 1))
                    # Trocar User-Agent para próxima tentativa
                    session.headers['User-Agent'] = self.get_random_user_agent()
                    continue
                else:
                    # Restaurar cache_duration se foi alterado
                    if cache_duration is not None:
                        self.cache_duration = old_cache_duration
                        
                    raise last_exception
        
        # Se chegou aqui, todas as tentativas falharam
        # Restaurar cache_duration se foi alterado
        if cache_duration is not None:
            self.cache_duration = old_cache_duration
            
        if last_exception:
            raise last_exception
        else:
            raise requests.exceptions.RequestException(f"Failed to connect to {url} after {max_retries} retries")
    
    def test_connection(self, url, timeout=10):
        """
        Testa conectividade com um URL
        Retorna True se conectar com sucesso
        """
        try:
            response = self.enhanced_request(url, timeout=timeout, max_retries=1, use_cache=False)
            return response.status_code == 200
        except:
            return False
    
    def get_stream_with_fallback(self, urls, headers=None, timeout=15):
        """
        Tenta múltiplas URLs até encontrar uma que funcione
        Baseado no sistema de fallback do IPTV Extreme
        """
        if isinstance(urls, str):
            urls = [urls]
        
        for url in urls:
            try:
                response = self.enhanced_request(
                    url, 
                    headers=headers, 
                    max_retries=2, 
                    timeout=timeout,
                    use_cache=False
                )
                if response.status_code == 200:
                    return response
            except:
                continue
        
        return None
    
    def optimize_for_streaming(self, url, stream_type=None):
        """
        Otimiza headers para streaming baseado no IPTV Extreme
        
        Args:
            url: URL do stream
            stream_type: Tipo de stream (mac, xtream, m3u, etc.)
        """
        parsed_url = urlparse(url)
        
        # Headers específicos para streaming
        streaming_headers = {
            'User-Agent': self.get_random_user_agent(),
            'Accept': '*/*',
            'Accept-Language': 'pt-PT,pt;q=0.9,en;q=0.8',
            'Accept-Encoding': 'identity',  # Sem compressão para streaming
            'Connection': 'keep-alive',
            'Range': 'bytes=0-',  # Suporte a range requests
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
        }
        
        # Headers específicos por tipo de stream
        if stream_type == 'mac' or 'stalker_portal' in url.lower() or 'portal.php' in url.lower():
            streaming_headers['User-Agent'] = 'Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/537.36 (KHTML, like Gecko) Version/5.0 Safari/537.36 MAG254'
            streaming_headers['X-User-Agent'] = 'Model: MAG254; Link: Ethernet'
            
        elif stream_type == 'xtream' or 'xtream' in parsed_url.netloc.lower():
            streaming_headers['X-Forwarded-For'] = '127.0.0.1'
            streaming_headers['User-Agent'] = 'VLC/3.0.16 LibVLC/3.0.16'
            
        elif stream_type == 'm3u' or url.lower().endswith('.m3u') or url.lower().endswith('.m3u8'):
            streaming_headers['User-Agent'] = 'ExoPlayerLib/2.18.1'
            
        return streaming_headers
    
    def detect_stream_type(self, url):
        """
        Detecta automaticamente o tipo de stream baseado na URL
        """
        url_lower = url.lower()
        parsed_url = urlparse(url)
        
        # Detecção por padrões na URL
        if 'portal.php' in url_lower or 'stalker_portal' in url_lower or 'c/portal.php' in url_lower:
            return 'mac'
        elif 'xtream' in url_lower or '/player_api.php' in url_lower:
            return 'xtream'
        elif url_lower.endswith('.m3u') or url_lower.endswith('.m3u8'):
            return 'm3u'
        elif url_lower.endswith('.ts') or url_lower.endswith('.mp4'):
            return 'direct'
        
        # Detecção por parâmetros
        query_params = parse_qs(parsed_url.query)
        if 'username' in query_params and 'password' in query_params:
            return 'xtream'
        
        # Fallback
        return 'unknown'
    
    def optimize_stream_url(self, url, stream_type=None):
        """
        Otimiza URL de stream baseado no tipo
        """
        if not stream_type:
            stream_type = self.detect_stream_type(url)
            
        parsed_url = urlparse(url)
        query_params = parse_qs(parsed_url.query)
        
        # Otimizações específicas por tipo
        if stream_type == 'xtream':
            # Adicionar parâmetros de otimização do IPTV Extreme
            query_params['_'] = [str(int(time.time() * 1000))]
            
            # Reconstruir URL
            new_query = urlencode(query_params, doseq=True)
            new_url = urlunparse((
                parsed_url.scheme,
                parsed_url.netloc,
                parsed_url.path,
                parsed_url.params,
                new_query,
                parsed_url.fragment
            ))
            
            return new_url
            
        elif stream_type == 'mac':
            # Otimizações específicas para MAC
            return url
            
        # Default: retornar URL original
        return url
    
    def clear_cache(self):
        """Limpa todo o cache"""
        try:
            for file in os.listdir(self.cache_dir):
                file_path = os.path.join(self.cache_dir, file)
                if os.path.isfile(file_path):
                    os.remove(file_path)
            xbmc.log("[TrainAgain-ECM] Cache limpo com sucesso", xbmc.LOGINFO)
            return True
        except Exception as e:
            xbmc.log(f"[TrainAgain-ECM] Erro ao limpar cache: {e}", xbmc.LOGERROR)
            return False
