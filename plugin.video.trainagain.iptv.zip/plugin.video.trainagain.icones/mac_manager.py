# -*- coding: utf-8 -*-
"""
Gestor de Portal MAC Múltiplo para Plugin TrainAgain
Versão melhorada com suporte para múltiplos portais MAC
Funcionalidades essenciais de autenticação e reprodução MAC
Enhanced Connection baseado no IPTV Extreme
"""

import requests
import re
import xbmc
import xbmcgui
import json
import time
from enhanced_connection_manager import EnhancedConnectionManager

class MacManager:
    """Gestor de funcionalidades Portal MAC com suporte múltiplo"""
    
    def __init__(self, addon):
        """
        Inicializar gestor MAC com Enhanced Connection
        
        Args:
            addon: Instância do addon
        """
        self.addon = addon
        self.session = requests.Session()
        
        # Inicializar Enhanced Connection Manager
        self.connection_manager = EnhancedConnectionManager()
        
        # User-Agent melhorado baseado no IPTV Extreme
        self.default_user_agent = 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3'
        
        # Headers padrão melhorados
        self.session.headers.update({
            'User-Agent': self.default_user_agent,
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Cache-Control': 'no-cache'
        })
        
        xbmc.log("[TrainAgain-MAC] MacManager inicializado com suporte múltiplo", xbmc.LOGINFO)
    
    def get_all_mac_configs(self):
        """
        Obter todas as configurações MAC ativas
        
        Returns:
            list: Lista de configurações MAC ativas
        """
        configs = []
        
        # MAC Principal
        if self.addon.getSetting('mac_enabled') == 'true':
            portal = self.addon.getSetting('mac_portal')
            mac = self.addon.getSetting('mac_address')
            if portal and mac:
                config = {
                    'config_id': 'main',
                    'id': 'main',
                    'name': 'Portal Principal',
                    'portal': portal,
                    'mac': mac,
                    'user_agent_setting': self.addon.getSetting('mac_user_agent') or 'MAG250',
                    'custom_user_agent': self.addon.getSetting('mac_custom_user_agent') or '',
                    'timeout': int(self.addon.getSetting('mac_timeout') or '15'),
                    'retries': int(self.addon.getSetting('mac_retries') or '3')
                }
                configs.append(config)
        
        # MACs 2-7
        for i in range(2, 8):
            enabled_setting = f'mac_{i}_enabled'
            if self.addon.getSetting(enabled_setting) == 'true':
                portal = self.addon.getSetting(f'mac_{i}_portal')
                mac = self.addon.getSetting(f'mac_{i}_address')
                if portal and mac:
                    config = {
                        'config_id': f'mac_{i}',
                        'id': f'mac_{i}',
                        'name': self.addon.getSetting(f'mac_{i}_name') or f'Portal {i}',
                        'portal': portal,
                        'mac': mac,
                        'user_agent_setting': self.addon.getSetting(f'mac_{i}_user_agent') or 'MAG250',
                        'custom_user_agent': self.addon.getSetting(f'mac_{i}_custom_user_agent') or '',
                        'timeout': int(self.addon.getSetting('mac_timeout') or '15'),
                        'retries': int(self.addon.getSetting('mac_retries') or '3')
                    }
                    configs.append(config)
        
        xbmc.log(f"[TrainAgain-MAC] {len(configs)} configurações MAC ativas encontradas", xbmc.LOGINFO)
        return configs
    
    def get_user_agent_string(self, user_agent_setting):
        """
        Obter string User-Agent baseada na configuração
        
        Args:
            user_agent_setting: Configuração do User-Agent
            
        Returns:
            str: String User-Agent
        """
        user_agents = {
            'MAG200': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3',
            'MAG250': 'Mozilla/5.0 (DirectFB; Linux; ko-KR) AppleWebKit/534.26+ (KHTML, like Gecko) Version/5.0 Safari/534.26+ MAG250',
            'MAG254': 'Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/534.26+ (KHTML, like Gecko) Version/5.0 Safari/534.26+ MAG254',
            'MAG256': 'Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/537.36 (KHTML, like Gecko) Version/5.0 Safari/537.36 MAG256',
            'MAG322': 'Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/537.36 (KHTML, like Gecko) Version/5.0 Safari/537.36 MAG322',
            'MAG324': 'Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/537.36 (KHTML, like Gecko) Version/5.0 Safari/537.36 MAG324',
            'MAG349': 'Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/537.36 (KHTML, like Gecko) Version/5.0 Safari/537.36 MAG349',
            'MAG351': 'Mozilla/5.0 (DirectFB; Linux armv7l) AppleWebKit/537.36 (KHTML, like Gecko) Version/5.0 Safari/537.36 MAG351'
        }
        
        # Mapear strings para valores
        if isinstance(user_agent_setting, str):
            if user_agent_setting in user_agents:
                return user_agents[user_agent_setting]
            elif user_agent_setting == 'Custom':
                return self.addon.getSetting('mac_custom_user_agent') or self.default_user_agent
        
        # Mapear índices para valores (compatibilidade)
        try:
            index = int(user_agent_setting)
            agent_list = list(user_agents.values())
            if 0 <= index < len(agent_list):
                return agent_list[index]
        except (ValueError, TypeError):
            pass
        
        return self.default_user_agent
    
    def get_mac_settings(self, config_id='main'):
        """
        Obter configurações MAC para um portal específico
        
        Args:
            config_id: ID da configuração MAC
            
        Returns:
            dict: Configurações MAC
        """
        configs = self.get_all_mac_configs()
        
        for config in configs:
            if config['id'] == config_id:
                return {
                    'portal': config['portal'],
                    'mac': config['mac'],
                    'enabled': True,
                    'user_agent': self.get_user_agent_string(config['user_agent_setting']),
                    'timeout': config['timeout'],
                    'retries': config['retries']
                }
        
        # Fallback para configuração principal
        return {
            'portal': self.addon.getSetting('mac_portal'),
            'mac': self.addon.getSetting('mac_address'),
            'enabled': self.addon.getSetting('mac_enabled') == 'true',
            'user_agent': self.get_user_agent_string(self.addon.getSetting('mac_user_agent') or 'MAG250'),
            'timeout': int(self.addon.getSetting('mac_timeout') or '15'),
            'retries': int(self.addon.getSetting('mac_retries') or '3')
        }
    
    def mac_handshake(self, portal, mac, user_agent=None):
        """
        Realizar handshake MAC com Enhanced Connection
        
        Args:
            portal: URL do portal MAC
            mac: Endereço MAC
            user_agent: User-Agent específico (opcional)
            
        Returns:
            str: Token de autenticação ou None se falhar
        """
        try:
            # Usar User-Agent específico se fornecido
            current_user_agent = user_agent or self.default_user_agent
            
            # Headers melhorados baseados no IPTV Extreme
            headers = {
                'User-Agent': current_user_agent,
                'Cookie': f'mac={mac}; stb_lang=pt; timezone=Europe/Lisbon',
                'Accept': '*/*',
                'Accept-Language': 'pt-PT,pt;q=0.9,en;q=0.8',
                'Accept-Encoding': 'gzip, deflate',
                'Connection': 'keep-alive',
                'Cache-Control': 'no-cache'
            }
            
            # Múltiplos endpoints para compatibilidade
            endpoints = [
                f'{portal}portal.php?type=stb&action=handshake&JsHttpRequest=1-xml',
                f'{portal}portal.php?action=handshake&type=stb&JsHttpRequest=1-xml',
                f'{portal}server/load.php?type=stb&action=handshake&JsHttpRequest=1-xml'
            ]
            
            for endpoint in endpoints:
                try:
                    xbmc.log(f"[TrainAgain-MAC] Tentando handshake: {endpoint}", xbmc.LOGINFO)
                    
                    # Usar Enhanced Connection Manager
                    response = self.connection_manager.enhanced_request(
                        endpoint, 
                        headers=headers, 
                        timeout=15, 
                        max_retries=2
                    )
                    
                    if response and response.status_code == 200:
                        # Múltiplos padrões de token para compatibilidade
                        token_patterns = [
                            r'"token":"([^"]+)"',
                            r'token":"([^"]+)"',
                            r'"token":([^,}]+)',
                            r'token=([^&\s]+)'
                        ]
                        
                        for pattern in token_patterns:
                            token_match = re.findall(pattern, response.text)
                            if token_match:
                                token = token_match[0].strip('"')
                                xbmc.log(f"[TrainAgain-MAC] Handshake bem-sucedido, token obtido", xbmc.LOGINFO)
                                return token
                                
                except Exception as e:
                    xbmc.log(f"[TrainAgain-MAC] Erro no endpoint {endpoint}: {e}", xbmc.LOGWARNING)
                    continue
                    
            xbmc.log(f"[TrainAgain-MAC] Falha no handshake em todos os endpoints", xbmc.LOGWARNING)
            return None
            
        except Exception as e:
            xbmc.log(f"[TrainAgain-MAC] Erro no handshake: {e}", xbmc.LOGERROR)
            return None
    
    def mac_get_profile(self, portal, mac, token):
        """
        Obter perfil MAC para autenticação
        
        Args:
            portal: URL do portal MAC
            mac: Endereço MAC
            token: Token de autenticação
            
        Returns:
            dict: Dados do perfil ou None se falhar
        """
        try:
            # Headers melhorados
            headers = {
                'User-Agent': self.default_user_agent,
                'Cookie': f'mac={mac}; stb_lang=pt; timezone=Europe/Lisbon',
                'Authorization': f'Bearer {token}',
                'Accept': '*/*',
                'Accept-Language': 'pt-PT,pt;q=0.9,en;q=0.8',
                'Connection': 'keep-alive'
            }
            
            # Múltiplos endpoints para get_profile
            endpoints = [
                f'{portal}portal.php?type=stb&action=get_profile&JsHttpRequest=1-xml',
                f'{portal}portal.php?action=get_profile&type=stb&JsHttpRequest=1-xml',
                f'{portal}server/load.php?type=stb&action=get_profile&JsHttpRequest=1-xml'
            ]
            
            for endpoint in endpoints:
                try:
                    response = self.session.get(endpoint, headers=headers, timeout=15)
                    
                    if response.status_code == 200:
                        # Múltiplos padrões para extrair dados do perfil
                        password_patterns = [
                            r'"password":"([^"]*)"',
                            r'password":"([^"]*)"',
                            r'"password":([^,}]+)'
                        ]
                        
                        stb_type_patterns = [
                            r'"stb_type":"([^"]+)"',
                            r'stb_type":"([^"]+)"',
                            r'"stb_type":([^,}]+)'
                        ]
                        
                        password = ""
                        stb_type = "MAG250"  # Default
                        
                        # Extrair password
                        for pattern in password_patterns:
                            password_match = re.findall(pattern, response.text)
                            if password_match:
                                password = password_match[0].strip('"')
                                break
                        
                        # Extrair stb_type
                        for pattern in stb_type_patterns:
                            stb_type_match = re.findall(pattern, response.text)
                            if stb_type_match:
                                stb_type = stb_type_match[0].strip('"')
                                break
                        
                        profile = {
                            'password': password,
                            'stb_type': stb_type,
                            'login': ''
                        }
                        xbmc.log(f"[TrainAgain-MAC] Perfil obtido: {stb_type}", xbmc.LOGINFO)
                        return profile
                        
                except Exception as e:
                    xbmc.log(f"[TrainAgain-MAC] Erro no endpoint profile {endpoint}: {e}", xbmc.LOGWARNING)
                    continue
                    
            xbmc.log(f"[TrainAgain-MAC] Falha ao obter perfil em todos os endpoints", xbmc.LOGWARNING)
            return None
            
        except Exception as e:
            xbmc.log(f"[TrainAgain-MAC] Erro ao obter perfil: {e}", xbmc.LOGERROR)
            return None
    
    def mac_get_genres(self, portal, mac, token, profile):
        """
        Obter géneros/categorias MAC
        
        Args:
            portal: URL do portal MAC
            mac: Endereço MAC
            token: Token de autenticação
            profile: Dados do perfil
            
        Returns:
            list: Lista de géneros ou lista vazia se falhar
        """
        try:
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0',
                'cookie': f'mac={mac}; stb_lang=pt; timezone=Europe/Lisbon',
                'Authorization': f'Bearer {token}'
            }
            
            payload = {
                'login': profile['login'],
                'password': profile['password'],
                'stb_type': profile['stb_type']
            }
            
            url = f'{portal}portal.php?type=itv&action=get_genres&JsHttpRequest=1-xml'
            
            response = self.session.post(url, headers=headers, data=str(payload), timeout=15)
            
            if response.status_code == 200:
                genres_matches = re.findall(r'"id":"(\d+.*?)".*?"title":"(.*?)"', response.text)
                
                genres = []
                for genre_id, title in genres_matches:
                    # Limpar título
                    clean_title = title.replace('\\u2b50', '').replace('\\/', '/')
                    genres.append({
                        'id': genre_id,
                        'title': clean_title
                    })
                
                xbmc.log(f"[TrainAgain-MAC] {len(genres)} géneros obtidos", xbmc.LOGINFO)
                return genres
                
            xbmc.log(f"[TrainAgain-MAC] Falha ao obter géneros: {response.status_code}", xbmc.LOGWARNING)
            return []
            
        except Exception as e:
            xbmc.log(f"[TrainAgain-MAC] Erro ao obter géneros: {e}", xbmc.LOGERROR)
            return []
    
    def mac_get_channels(self, portal, mac, token, genre_id, config_id='main'):
        """
        Obter todos os canais por género com carregamento ULTRA RÁPIDO
        
        Args:
            portal: URL do portal MAC
            mac: Endereço MAC
            token: Token de autenticação
            genre_id: ID do género
            config_id: ID da configuração MAC
            
        Returns:
            list: Lista completa de canais ou lista vazia se falhar
        """
        try:
            # Obter configurações específicas
            config = self.get_mac_settings(config_id)
            user_agent = config['user_agent']
            
            headers = {
                'User-Agent': user_agent,
                'cookie': f'mac={mac}; stb_lang=pt; timezone=Europe/Lisbon',
                'Authorization': f'Bearer {token}',
                'Accept': '*/*',
                'Accept-Language': 'pt-PT,pt;q=0.9,en;q=0.8',
                'Accept-Encoding': 'gzip, deflate',
                'Connection': 'keep-alive',
                'Cache-Control': 'no-cache'
            }
            
            # ULTRA OTIMIZAÇÃO: Só um endpoint mais rápido
            url_template = f'{portal}portal.php?type=itv&action=get_ordered_list&genre={genre_id}&p={{page}}&JsHttpRequest=1-xml'
            
            all_channels = []
            page = 1
            max_pages = 10  # Reduzido drasticamente para velocidade
            
            xbmc.log(f"[TrainAgain-MAC] CARREGAMENTO ULTRA RÁPIDO para género {genre_id} (Config: {config_id})", xbmc.LOGINFO)
            
            while page <= max_pages:
                try:
                    url = url_template.format(page=page)
                    
                    # TIMEOUT MÍNIMO para velocidade máxima
                    response = self.session.get(url, headers=headers, timeout=2)
                    
                    if response.status_code == 200 and response.text:
                        # REGEX ULTRA OTIMIZADO - múltiplos padrões para logos
                        patterns = [
                            # Padrão 1: Mais comum - name, logo, ch_id
                            r'"name":"([^"]+)"[^}]*?"logo":"([^"]*?)"[^}]*?"ch_id":"([^"]+)"',
                            # Padrão 2: Ordem alternativa - id, name, logo, ch_id  
                            r'"id":"([^"]+)","name":"([^"]+)"[^}]*?"logo":"([^"]*?)"[^}]*?"ch_id":"([^"]+)"',
                            # Padrão 3: Logo sem aspas
                            r'"name":"([^"]+)"[^}]*?logo:([^,}]+)[^}]*?"ch_id":"([^"]+)"',
                            # Padrão 4: Sem logo (fallback)
                            r'"name":"([^"]+)"[^}]*?"ch_id":"([^"]+)"'
                        ]
                        
                        channels_matches = []
                        
                        # Testar padrões em ordem de prioridade
                        for i, pattern in enumerate(patterns):
                            matches = re.findall(pattern, response.text)
                            if matches:
                                xbmc.log(f"[TrainAgain-MAC] Padrão {i+1} funcionou: {len(matches)} canais", xbmc.LOGINFO)
                                
                                # Processar matches baseado no padrão
                                if i == 0:  # Padrão 1: name, logo, ch_id
                                    channels_matches = [(name, logo, ch_id) for name, logo, ch_id in matches]
                                elif i == 1:  # Padrão 2: id, name, logo, ch_id
                                    channels_matches = [(name, logo, ch_id) for id, name, logo, ch_id in matches]
                                elif i == 2:  # Padrão 3: name, logo_sem_aspas, ch_id
                                    channels_matches = [(name, logo.strip().strip('"').strip("'"), ch_id) for name, logo, ch_id in matches]
                                elif i == 3:  # Padrão 4: name, ch_id (sem logo)
                                    channels_matches = [(name, "", ch_id) for name, ch_id in matches]
                                
                                break  # Parou no primeiro padrão que funcionou
                        
                        if channels_matches:
                            xbmc.log(f"[TrainAgain-MAC] Página {page}: {len(channels_matches)} canais", xbmc.LOGINFO)
                            
                            for match in channels_matches:
                                if len(match) == 3:  # name, logo, ch_id
                                    name, logo, ch_id = match
                                elif len(match) == 2:  # name, ch_id (sem logo)
                                    name, ch_id = match
                                    logo = ""
                                else:
                                    continue
                                
                                # Limpeza MÍNIMA para velocidade
                                clean_name = name.replace('\\', '').strip()
                                clean_logo = logo.replace('\\', '').strip() if logo else ""
                                
                                # Adicionar canal com informação de configuração
                                channel = {
                                    'name': clean_name,
                                    'logo': clean_logo,
                                    'ch_id': ch_id,
                                    'config_id': config_id,  # Identificar origem
                                    'portal': portal
                                }
                                all_channels.append(channel)
                            
                            page += 1
                        else:
                            # Sem mais canais, parar
                            break
                    else:
                        # Erro ou sem conteúdo, parar
                        break
                        
                except Exception as e:
                    xbmc.log(f"[TrainAgain-MAC] Erro na página {page}: {e}", xbmc.LOGWARNING)
                    break
            
            xbmc.log(f"[TrainAgain-MAC] TOTAL: {len(all_channels)} canais carregados para {config_id}", xbmc.LOGINFO)
            return all_channels
            
        except Exception as e:
            xbmc.log(f"[TrainAgain-MAC] Erro ao obter canais: {e}", xbmc.LOGERROR)
            return []
    
    def get_all_channels_from_all_configs(self):
        """
        Obter canais de todas as configurações MAC ativas
        
        Returns:
            dict: Dicionário com canais organizados por configuração
        """
        all_configs = self.get_all_mac_configs()
        all_channels = {}
        
        for config in all_configs:
            try:
                xbmc.log(f"[TrainAgain-MAC] Processando configuração: {config['name']}", xbmc.LOGINFO)
                
                # Realizar handshake
                token = self.mac_handshake(
                    config['portal'], 
                    config['mac'], 
                    self.get_user_agent_string(config['user_agent_setting'])
                )
                
                if not token:
                    xbmc.log(f"[TrainAgain-MAC] Falha no handshake para {config['name']}", xbmc.LOGWARNING)
                    continue
                
                # Obter perfil
                profile = self.mac_get_profile(config['portal'], config['mac'], token)
                if not profile:
                    xbmc.log(f"[TrainAgain-MAC] Falha ao obter perfil para {config['name']}", xbmc.LOGWARNING)
                    continue
                
                # Obter géneros
                genres = self.mac_get_genres(config['portal'], config['mac'], token, profile)
                if not genres:
                    xbmc.log(f"[TrainAgain-MAC] Nenhum género encontrado para {config['name']}", xbmc.LOGWARNING)
                    continue
                
                # Obter canais de todos os géneros
                config_channels = []
                for genre in genres[:5]:  # Limitar a 5 géneros para velocidade
                    channels = self.mac_get_channels(
                        config['portal'], 
                        config['mac'], 
                        token, 
                        genre['id'], 
                        config['id']
                    )
                    config_channels.extend(channels)
                
                all_channels[config['id']] = {
                    'name': config['name'],
                    'channels': config_channels,
                    'total': len(config_channels)
                }
                
                xbmc.log(f"[TrainAgain-MAC] {config['name']}: {len(config_channels)} canais obtidos", xbmc.LOGINFO)
                
            except Exception as e:
                xbmc.log(f"[TrainAgain-MAC] Erro ao processar {config['name']}: {e}", xbmc.LOGERROR)
                continue
        
        return all_channels
    
    def mac_get_stream_url(self, portal, mac, token, ch_id, config_id='main'):
        """
        Obter URL de stream para um canal específico
        
        Args:
            portal: URL do portal MAC
            mac: Endereço MAC
            token: Token de autenticação
            ch_id: ID do canal
            config_id: ID da configuração MAC
            
        Returns:
            str: URL do stream ou None se falhar
        """
        try:
            xbmc.log(f"[TrainAgain-MAC] Obtendo stream para canal {ch_id} (config: {config_id})", xbmc.LOGINFO)
            
            # Obter configurações específicas
            config = self.get_mac_settings(config_id)
            user_agent = config['user_agent']
            
            xbmc.log(f"[TrainAgain-MAC] Portal: {portal}, MAC: {mac}, User-Agent: {user_agent}", xbmc.LOGINFO)
            
            headers = {
                'User-Agent': user_agent,
                'cookie': f'mac={mac}; stb_lang=pt; timezone=Europe/Lisbon',
                'Authorization': f'Bearer {token}',
                'Accept': '*/*',
                'Accept-Language': 'pt-PT,pt;q=0.9,en;q=0.8',
                'Connection': 'keep-alive'
            }
            
            # Múltiplos endpoints para obter stream
            endpoints = [
                f'{portal}portal.php?type=itv&action=create_link&ch_id={ch_id}&JsHttpRequest=1-xml',
                f'{portal}portal.php?action=create_link&type=itv&ch_id={ch_id}&JsHttpRequest=1-xml',
                f'{portal}server/load.php?type=itv&action=create_link&ch_id={ch_id}&JsHttpRequest=1-xml'
            ]
            
            for i, endpoint in enumerate(endpoints):
                try:
                    xbmc.log(f"[TrainAgain-MAC] Tentando endpoint {i+1}/3: {endpoint}", xbmc.LOGINFO)
                    response = self.session.get(endpoint, headers=headers, timeout=10)
                    
                    xbmc.log(f"[TrainAgain-MAC] Resposta HTTP {response.status_code} para endpoint {i+1}", xbmc.LOGINFO)
                    
                    if response.status_code == 200:
                        xbmc.log(f"[TrainAgain-MAC] Resposta do servidor: {response.text[:200]}...", xbmc.LOGINFO)
                        
                        # Múltiplos padrões para extrair URL
                        url_patterns = [
                            r'"cmd":"([^"]+)"',
                            r'cmd":"([^"]+)"',
                            r'"url":"([^"]+)"',
                            r'url":"([^"]+)"'
                        ]
                        
                        for j, pattern in enumerate(url_patterns):
                            url_match = re.findall(pattern, response.text)
                            if url_match:
                                stream_url = url_match[0].replace('\\/', '/')
                                xbmc.log(f"[TrainAgain-MAC] Stream URL encontrado com padrão {j+1}: {stream_url}", xbmc.LOGINFO)
                                return stream_url
                        
                        xbmc.log(f"[TrainAgain-MAC] Nenhum padrão de URL encontrado na resposta", xbmc.LOGWARNING)
                                
                except Exception as e:
                    xbmc.log(f"[TrainAgain-MAC] Erro no endpoint {i+1} ({endpoint}): {e}", xbmc.LOGWARNING)
                    continue
            
            xbmc.log(f"[TrainAgain-MAC] Falha ao obter stream para canal {ch_id} - todos os endpoints falharam", xbmc.LOGWARNING)
            return None
            
        except Exception as e:
            xbmc.log(f"[TrainAgain-MAC] Erro geral ao obter stream: {e}", xbmc.LOGERROR)
            return None


    
    def mac_create_link(self, portal, mac, token, ch_id):
        """
        Criar link de reprodução para canal MAC com Enhanced Connection
        
        Args:
            portal: URL do portal MAC
            mac: Endereço MAC
            token: Token de autenticação
            ch_id: ID do canal
            
        Returns:
            str: URL do stream ou None se falhar
        """
        try:
            xbmc.log(f"[TrainAgain-MAC] Criando link para canal {ch_id}", xbmc.LOGINFO)
            
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:84.0) Gecko/20100101 Firefox/84.0',
                'cookie': f'mac={mac}; stb_lang=pt; timezone=Europe/Lisbon',
                'Authorization': f'Bearer {token}'
            }
            
            # URLs alternativas baseadas no IPTV Extreme
            urls = [
                f'{portal}portal.php?type=itv&action=create_link&cmd=http://localhost/ch/{ch_id}_&series=&forced_storage=undefined&disable_ad=0&download=0&JsHttpRequest=1-xml',
                f'{portal}server/load.php?type=itv&action=create_link&cmd=http://localhost/ch/{ch_id}_&JsHttpRequest=1-xml',
                f'{portal}portal.php?action=create_link&type=itv&cmd=http://localhost/ch/{ch_id}_&JsHttpRequest=1-xml'
            ]
            
            for url in urls:
                try:
                    xbmc.log(f"[TrainAgain-MAC] Tentando URL: {url}", xbmc.LOGINFO)
                    
                    # Usar Enhanced Connection Manager
                    response = self.connection_manager.enhanced_request(
                        url, 
                        headers=headers, 
                        timeout=15, 
                        max_retries=2
                    )
                    
                    if response and response.status_code == 200:
                        xbmc.log(f"[TrainAgain-MAC] Resposta do servidor: {response.text[:300]}...", xbmc.LOGINFO)
                        
                        # Múltiplos padrões para compatibilidade
                        patterns = [
                            r'"cmd":"ffmpeg (.*?)"',
                            r'"cmd":"(http[^"]+)"',
                            r'"url":"(http[^"]+)"',
                            r'"stream_url":"(http[^"]+)"'
                        ]
                        
                        for pattern in patterns:
                            matches = re.findall(pattern, response.text)
                            if matches:
                                stream_url = matches[0].replace("\\", "")
                                xbmc.log(f"[TrainAgain-MAC] Link criado com sucesso: {stream_url}", xbmc.LOGINFO)
                                return stream_url
                                
                except Exception as e:
                    xbmc.log(f"[TrainAgain-MAC] Erro na URL {url}: {e}", xbmc.LOGWARNING)
                    continue
                    
            xbmc.log(f"[TrainAgain-MAC] Falha ao criar link em todas as URLs", xbmc.LOGWARNING)
            return None
            
        except Exception as e:
            xbmc.log(f"[TrainAgain-MAC] Erro ao criar link: {e}", xbmc.LOGERROR)
            return None
    
    def test_mac_connection(self, portal, mac, user_agent=None):
        """
        Testar conexão MAC
        
        Args:
            portal: URL do portal MAC
            mac: Endereço MAC
            user_agent: User-Agent específico (opcional)
            
        Returns:
            bool: True se conexão bem-sucedida
        """
        try:
            xbmc.log(f"[TrainAgain-MAC] Testando conexão para {portal}", xbmc.LOGINFO)
            
            # Realizar handshake
            token = self.mac_handshake(portal, mac, user_agent)
            
            if token:
                # Testar obtenção de perfil
                profile = self.mac_get_profile(portal, mac, token)
                
                if profile:
                    xbmc.log(f"[TrainAgain-MAC] Teste de conexão bem-sucedido", xbmc.LOGINFO)
                    return True
                else:
                    xbmc.log(f"[TrainAgain-MAC] Falha ao obter perfil no teste", xbmc.LOGWARNING)
                    return False
            else:
                xbmc.log(f"[TrainAgain-MAC] Falha no handshake durante teste", xbmc.LOGWARNING)
                return False
                
        except Exception as e:
            xbmc.log(f"[TrainAgain-MAC] Erro no teste de conexão: {e}", xbmc.LOGERROR)
            return False

