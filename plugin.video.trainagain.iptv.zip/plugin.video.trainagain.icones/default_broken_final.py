import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
from urllib.parse import parse_qsl, urlencode
import urllib.parse
import requests
import json
import time
import hashlib
import os
import re
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

# Importar gestor de ícones de países
from country_icon_manager import CountryIconManager

# Importar gestor de Stalker Portal
from mac_manager import MacManager

# Configuração global
addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
addon_url = sys.argv[0]
addon_path = addon.getAddonInfo('path')

def log(message, level=xbmc.LOGINFO):
    """Log de mensagens"""
    xbmc.log(f"[TRAINAGAIN-ICONES] {message}", level)

def notify(title, message, icon=xbmcgui.NOTIFICATION_INFO, time=5000):
    """Mostrar notificação"""
    xbmcgui.Dialog().notification(title, message, icon, time)

class ImprovedHTTPSession:
    """Classe HTTP melhorada para requisições"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def get(self, url, timeout=15, **kwargs):
        """GET request com tratamento de erros"""
        try:
            response = self.session.get(url, timeout=timeout, **kwargs)
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            log(f"Erro HTTP GET: {e}", xbmc.LOGERROR)
            return None
    
    def post(self, url, timeout=15, **kwargs):
        """POST request com tratamento de erros"""
        try:
            response = self.session.post(url, timeout=timeout, **kwargs)
            response.raise_for_status()
            return response
        except requests.exceptions.RequestException as e:
            log(f"Erro HTTP POST: {e}", xbmc.LOGERROR)
            return None

class TrainAgainIcones:
    """Classe principal do addon GRUPO TRAINAGAIN"""
    
    def __init__(self):
        self.addon = addon
        self.handle = addon_handle
        self.url = addon_url
        self.http = ImprovedHTTPSession()
        
        # Inicializar gestores
        self.country_icon_manager = CountryIconManager(addon_path)
        self.mac_manager = MacManager(self.addon)
        
        log("GRUPO TRAINAGAIN Addon iniciado")
    
    def router(self, paramstring):
        """Router principal do addon"""
        params = dict(parse_qsl(paramstring))
        action = params.get('action', None)
        
        log(f"Router chamado com ação: {action}")
        
        if action is None:
            self.show_main_menu()
        elif action == 'xtream_codes':
            self.show_xtream_codes()
        elif action == 'xtream_multiple':
            self.show_xtream_multiple()
        elif action == 'xtream_for_list':
            list_id = params.get('list_id', '1')
            self.show_xtream_for_list(list_id)
        elif action == 'live_tv':
            list_id = params.get('list_id', '1')
            self.show_live_tv(list_id)
        elif action == 'movies':
            list_id = params.get('list_id', '1')
            self.show_movies(list_id)
        elif action == 'series':
            list_id = params.get('list_id', '1')
            self.show_series(list_id)
        elif action == 'play_stream':
            url = params.get('url')
            title = params.get('title', 'Stream')
            self.play_stream(url, title)
        elif action == 'play_movie':
            url = params.get('url')
            title = params.get('title', 'Movie')
            self.play_movie(url, title)
        elif action == 'show_seasons':
            series_id = params.get('series_id')
            list_id = params.get('list_id', '1')
            self.show_seasons(series_id, list_id)
        elif action == 'show_episodes':
            series_id = params.get('series_id')
            season_num = params.get('season_num')
            list_id = params.get('list_id', '1')
            self.show_episodes(series_id, season_num, list_id)
        elif action == 'play_episode':
            url = params.get('url')
            title = params.get('title', 'Episode')
            self.play_episode(url, title)
        elif action == 'test_connection':
            self.test_connection()
        # NOVA FUNCIONALIDADE M3U
        elif action == 'm3u_playlists':
            self.show_m3u_playlists()
        elif action == 'm3u_categories':
            source_id = params.get('source_id')
            self.show_m3u_categories(source_id)
        elif action == 'm3u_channels':
            source_id = params.get('source_id')
            category = params.get('category', '')
            self.show_m3u_channels(source_id, category)
        elif action == 'play_m3u_item':
            url = params.get('url')
            title = params.get('title', 'Stream')
            self.play_m3u_item(url, title)
        elif action == 'settings':
            self.addon.openSettings()
        # FUNCIONALIDADES MAC - Adicionar ações MAC
        elif action == 'mac_portal':
            self.show_mac_portal()
        elif action == 'mac_multiple':
            self.show_mac_multiple()
        elif action == 'mac_portal_for_config':
            config_id = params.get('config_id', 'main')
            self.show_mac_portal_for_config(config_id)
        elif action == 'mac_genres':
            # Manter compatibilidade com versão original (sem argumentos)
            # e nova versão (com config_id)
            config_id = params.get('config_id', 'main')
            if config_id == 'main' and not params.get('config_id'):
                # Chamada original sem argumentos
                self.show_mac_genres()
            else:
                # Nova versão com config_id
                self.show_mac_genres_for_config(config_id)
        elif action == 'mac_channels':
            genre_id = params.get('genre_id')
            config_id = params.get('config_id', 'main')
            if config_id == 'main' and not params.get('config_id'):
                # Versão original
                genre_title = params.get('genre_title', '')
                self.show_mac_channels(genre_id, genre_title)
            else:
                # Nova versão
                self.show_mac_channels_for_config(genre_id, config_id)
        elif action == 'play_mac_channel':
            ch_id = params.get('ch_id')
            config_id = params.get('config_id', 'main')
            if config_id == 'main' and not params.get('config_id'):
                # Versão original
                title = params.get('title', 'Canal')
                self.play_mac_channel(ch_id, title)
            else:
                # Nova versão
                self.play_mac_channel_for_config(ch_id, config_id)
        elif action == 'test_mac_connection':
            config_id = params.get('config_id', 'main')
            if config_id == 'main' and not params.get('config_id'):
                # Versão original
                self.test_mac_connection()
            else:
                # Nova versão
                self.test_mac_connection_for_config(config_id)
        else:
            log(f"Ação desconhecida: {action}", xbmc.LOGWARNING)
            self.show_main_menu()
    
    def show_main_menu(self):
        """Mostrar menu principal"""
        log("Mostrando menu principal")
        
        # Verificar se há pelo menos um servidor Xtream configurado
        xtream_server = self.addon.getSetting('xtream_server')
        
        # Mapeamento de fanart para cada ação - USAR LOGO TRAINAGAIN EM TUDO
        trainagain_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/trainagain_main_fanart.png"
        
        fanart_map = {
            "xtream_codes": trainagain_fanart,
            "xtream_multiple": trainagain_fanart,
            "test_connection": trainagain_fanart,
            "settings": trainagain_fanart,
            # NOVA FUNCIONALIDADE M3U
            "m3u_playlists": trainagain_fanart,
            "local_media": trainagain_fanart,
            # STALKER PORTAL
            "mac_portal": trainagain_fanart
        }
        
        menu_items = []
        
        if xtream_server:
            # Verificar se há múltiplas listas Xtream configuradas
            additional_lists = []
            for i in range(2, 6):  # Listas 2-5
                if (self.addon.getSetting(f'xtream_{i}_enabled') == 'true' and 
                    self.addon.getSetting(f'xtream_{i}_server')):
                    additional_lists.append(i)
            
            if additional_lists:
                menu_items.append(("🌐 Listas Xtream", "xtream_multiple", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/xtream_codes_icon.png"))
            else:
                menu_items.append(("🌐 Xtream Codes", "xtream_codes", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/xtream_codes_icon.png"))
        
        # NOVA FUNCIONALIDADE M3U - Adicionar opções M3U se habilitadas
        try:
            from m3u_extension import M3UExtension
            m3u_ext = M3UExtension(self.addon)
            
            if m3u_ext.is_m3u_enabled() and m3u_ext.get_m3u_sources():
                menu_items.append(("📺 Playlists M3U", "m3u_playlists", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/playlists_icon.png"))
            
            if m3u_ext.get_local_directories():
                menu_items.append(("📁 Mídia Local", "local_media", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/movies_icon.png"))
        except ImportError:
            log("Módulo M3U não encontrado - funcionalidade M3U desabilitada", xbmc.LOGWARNING)
        except Exception as e:
            log(f"Erro ao carregar extensão M3U: {e}", xbmc.LOGWARNING)
        
        # FUNCIONALIDADE MAC - Verificar múltiplas configurações MAC
        all_mac_configs = self.mac_manager.get_all_mac_configs()
        if all_mac_configs:
            if len(all_mac_configs) > 1:
                menu_items.append(("🔌 Portais MAC", "mac_multiple", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/stalker_portal_icon.png"))
            else:
                menu_items.append(("🔌 Stalker Portal", "mac_portal", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/stalker_portal_icon.png"))
        
        menu_items.extend([
            ("🔧 Teste de Conexão", "test_connection", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/test_connection_icon.png"),
            ("⚙️ Configurações", "settings", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/settings_icon.png")
        ])
        
        # Verificar se há pelo menos um serviço configurado
        has_service = False
        
        # Verificar Xtream Codes
        if xtream_server:
            has_service = True
        
        # Verificar Stalker Portal
        all_mac_configs = self.mac_manager.get_all_mac_configs()
        if all_mac_configs:
            has_service = True
        
        # Verificar M3U
        try:
            m3u_ext = M3UExtension(self.addon)
            if m3u_ext.is_m3u_enabled() and m3u_ext.get_m3u_sources():
                has_service = True
        except:
            pass
        
        # Só mostrar mensagem se NÃO houver nenhum serviço configurado
        if not has_service:
            notify("GRUPO TRAINAGAIN", "Configure pelo menos um serviço nas configurações", xbmcgui.NOTIFICATION_WARNING)
        
        for title, action, icon_path in menu_items:
            url = f"{self.url}?action={action}"
            
            list_item = xbmcgui.ListItem(label=title)
            
            # Adicionar ícone e fanart
            art_dict = {
                'icon': icon_path, 
                'thumb': icon_path
            }
            
            # Adicionar fanart se disponível
            if action in fanart_map:
                art_dict['fanart'] = fanart_map[action]
            
            list_item.setArt(art_dict)
            
            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url=url,
                listitem=list_item,
                isFolder=True
            )
        
        xbmcplugin.endOfDirectory(self.handle)
    
    # FUNCIONALIDADES MAC - MÚLTIPLOS PORTAIS
    def show_mac_multiple(self):
        """Mostrar múltiplos portais MAC configurados"""
        log("Mostrando múltiplos portais MAC")
        
        all_configs = self.mac_manager.get_all_mac_configs()
        
        if not all_configs:
            notify("GRUPO TRAINAGAIN", "Nenhum portal MAC configurado", xbmcgui.NOTIFICATION_WARNING)
            return
        
        # Fanart específico para MAC
        mac_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/stalker_portal_fanart.png"
        
        for config in all_configs:
            title = f"🔌 {config['name']}"
            url = f"{self.url}?action=mac_portal_for_config&config_id={config['id']}"
            
            list_item = xbmcgui.ListItem(label=title)
            list_item.setArt({
                'icon': "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/stalker_portal_icon.png",
                'thumb': "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/stalker_portal_icon.png",
                'fanart': mac_fanart
            })
            
            # Adicionar informações do portal
            list_item.setInfo('video', {
                'title': title,
                'plot': f"Portal: {config['portal']}\nMAC: {config['mac']}"
            })
            
            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url=url,
                listitem=list_item,
                isFolder=True
            )
        
        xbmcplugin.endOfDirectory(self.handle)
    
    def show_mac_portal_for_config(self, config_id):
        """Mostrar portal MAC para configuração específica"""
        log(f"Mostrando portal MAC para configuração: {config_id}")
        
        config = self.mac_manager.get_mac_settings(config_id)
        
        if not config['enabled'] or not config['portal'] or not config['mac']:
            notify("GRUPO TRAINAGAIN", f"Configuração MAC {config_id} inválida", xbmcgui.NOTIFICATION_ERROR)
            return
        
        # Fanart específico para MAC
        mac_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/stalker_portal_fanart.png"
        
        menu_items = [
            ("📺 Géneros/Categorias", f"mac_genres&config_id={config_id}", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"),
            ("🔧 Testar Conexão", f"test_mac_connection&config_id={config_id}", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/test_connection_icon.png")
        ]
        
        for title, action_params, icon_path in menu_items:
            url = f"{self.url}?action={action_params}"
            
            list_item = xbmcgui.ListItem(label=title)
            list_item.setArt({
                'icon': icon_path,
                'thumb': icon_path,
                'fanart': mac_fanart
            })
            
            xbmcplugin.addDirectoryItem(
                handle=self.handle,
                url=url,
                listitem=list_item,
                isFolder=True
            )
        
        xbmcplugin.endOfDirectory(self.handle)
    
    def show_mac_genres_for_config(self, config_id='main'):
        """Mostrar géneros MAC para configuração específica (nova versão)"""
        log(f"Mostrando géneros MAC para configuração: {config_id}")
        
        config = self.mac_manager.get_mac_settings(config_id)
        
        if not config['enabled'] or not config['portal'] or not config['mac']:
            notify("GRUPO TRAINAGAIN", f"Configuração MAC {config_id} inválida", xbmcgui.NOTIFICATION_ERROR)
            return
        
        try:
            # Realizar handshake
            token = self.mac_manager.mac_handshake(config['portal'], config['mac'], config['user_agent'])
            
            if not token:
                notify("GRUPO TRAINAGAIN", "Falha na autenticação MAC", xbmcgui.NOTIFICATION_ERROR)
                return
            
            # Obter perfil
            profile = self.mac_manager.mac_get_profile(config['portal'], config['mac'], token)
            if not profile:
                notify("GRUPO TRAINAGAIN", "Falha ao obter perfil MAC", xbmcgui.NOTIFICATION_ERROR)
                return
            
            # Obter géneros
            genres = self.mac_manager.mac_get_genres(config['portal'], config['mac'], token, profile)
            
            if not genres:
                notify("GRUPO TRAINAGAIN", "Nenhum género encontrado", xbmcgui.NOTIFICATION_WARNING)
                return
            
            # Fanart específico para MAC
            mac_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/stalker_portal_fanart.png"
            
            for genre in genres:
                title = f"📂 {genre['title']}"
                url = f"{self.url}?action=mac_channels&genre_id={genre['id']}&config_id={config_id}"
                
                list_item = xbmcgui.ListItem(label=title)
                list_item.setArt({
                    'icon': "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png",
                    'thumb': "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png",
                    'fanart': mac_fanart
                })
                
                list_item.setInfo('video', {
                    'title': title,
                    'plot': f"Categoria: {genre['title']}"
                })
                
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=url,
                    listitem=list_item,
                    isFolder=True
                )
            
            xbmcplugin.endOfDirectory(self.handle)
            
        except Exception as e:
            log(f"Erro ao obter géneros MAC: {e}", xbmc.LOGERROR)
            notify("GRUPO TRAINAGAIN", f"Erro ao carregar géneros: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
    
    def show_mac_channels_for_config(self, genre_id, config_id='main'):
        """Mostrar canais MAC para configuração específica (nova versão)"""
        log(f"Mostrando canais MAC para género {genre_id}, configuração: {config_id}")
        
        config = self.mac_manager.get_mac_settings(config_id)
        
        if not config['enabled'] or not config['portal'] or not config['mac']:
            notify("GRUPO TRAINAGAIN", f"Configuração MAC {config_id} inválida", xbmcgui.NOTIFICATION_ERROR)
            return
        
        try:
            # Realizar handshake
            token = self.mac_manager.mac_handshake(config['portal'], config['mac'], config['user_agent'])
            
            if not token:
                notify("GRUPO TRAINAGAIN", "Falha na autenticação MAC", xbmcgui.NOTIFICATION_ERROR)
                return
            
            # Obter canais
            channels = self.mac_manager.mac_get_channels(config['portal'], config['mac'], token, genre_id)
            
            if not channels:
                notify("GRUPO TRAINAGAIN", "Nenhum canal encontrado", xbmcgui.NOTIFICATION_WARNING)
                return
            
            # Fanart específico para MAC
            mac_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/stalker_portal_fanart.png"
            
            for channel in channels:
                title = f"📺 {channel['name']}"
                url = f"{self.url}?action=play_mac_channel&ch_id={channel['ch_id']}&config_id={config_id}"
                
                list_item = xbmcgui.ListItem(label=title)
                list_item.setProperty('IsPlayable', 'true')
                
                # Logo do canal
                logo_url = channel.get('logo', '').strip()
                if logo_url and logo_url.startswith('http'):
                    icon_path = logo_url
                else:
                    icon_path = "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"
                
                list_item.setArt({
                    'icon': icon_path,
                    'thumb': icon_path,
                    'fanart': mac_fanart
                })
                
                list_item.setInfo('video', {
                    'title': title,
                    'plot': f"Canal: {channel['name']}"
                })
                
                xbmcplugin.addDirectoryItem(
                    handle=self.handle,
                    url=url,
                    listitem=list_item,
                    isFolder=False
                )
            
            xbmcplugin.endOfDirectory(self.handle)
            
        except Exception as e:
            log(f"Erro ao obter canais MAC: {e}", xbmc.LOGERROR)
            notify("GRUPO TRAINAGAIN", f"Erro ao carregar canais: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
    
    def play_mac_channel_for_config(self, ch_id, config_id='main'):
        """Reproduzir canal MAC para configuração específica (nova versão)"""
        log(f"Reproduzindo canal MAC {ch_id} da configuração {config_id}")
        
        config = self.mac_manager.get_mac_settings(config_id)
        
        if not config['enabled'] or not config['portal'] or not config['mac']:
            notify("GRUPO TRAINAGAIN", f"Configuração MAC {config_id} inválida", xbmcgui.NOTIFICATION_ERROR)
            return
        
        try:
            # Realizar handshake
            token = self.mac_manager.mac_handshake(config['portal'], config['mac'], config['user_agent'])
            
            if not token:
                notify("GRUPO TRAINAGAIN", "Falha na autenticação MAC", xbmcgui.NOTIFICATION_ERROR)
                return
            
            # Obter URL do stream
            stream_url = self.mac_manager.mac_create_link(config['portal'], config['mac'], token, ch_id)
            
            if not stream_url:
                notify("GRUPO TRAINAGAIN", "Falha ao obter URL do stream", xbmcgui.NOTIFICATION_ERROR)
                return
            
            # Criar item de reprodução
            list_item = xbmcgui.ListItem(path=stream_url)
            list_item.setProperty('IsPlayable', 'true')
            
            # Configurar para usar inputstream.adaptive se necessário
            if '.m3u8' in stream_url or 'mpd' in stream_url:
                list_item.setProperty('inputstream', 'inputstream.adaptive')
                if '.m3u8' in stream_url:
                    list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                elif 'mpd' in stream_url:
                    list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            
            # Reproduzir
            xbmc.Player().play(stream_url, list_item)
            log(f"Reproduzindo stream MAC: {stream_url}")
            
        except Exception as e:
            log(f"Erro ao reproduzir canal MAC: {e}", xbmc.LOGERROR)
            notify("GRUPO TRAINAGAIN", f"Erro na reprodução: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
    
    def test_mac_connection_for_config(self, config_id='main'):
        """Testar conexão MAC para configuração específica"""
        log(f"Testando conexão MAC para configuração: {config_id}")
        
        config = self.mac_manager.get_mac_settings(config_id)
        
        if not config['enabled'] or not config['portal'] or not config['mac']:
            notify("GRUPO TRAINAGAIN", f"Configuração MAC {config_id} não está configurada", xbmcgui.NOTIFICATION_ERROR)
            return
        
        # Mostrar progresso
        progress = xbmcgui.DialogProgress()
        progress.create("GRUPO TRAINAGAIN", f"Testando conexão MAC {config_id}...")
        progress.update(10, "Iniciando teste...")
        
        try:
            progress.update(30, "Realizando handshake...")
            
            # Testar handshake
            token = self.mac_manager.mac_handshake(config['portal'], config['mac'], config['user_agent'])
            
            if token:
                progress.update(60, "Obtendo perfil...")
                
                # Testar perfil
                profile = self.mac_manager.mac_get_profile(config['portal'], config['mac'], token)
                
                if profile:
                    progress.update(100, "Teste concluído!")
                    progress.close()
                    notify("GRUPO TRAINAGAIN", f"Conexão MAC {config_id} bem-sucedida!", xbmcgui.NOTIFICATION_INFO)
                    log(f"Teste MAC {config_id} bem-sucedido - Token e perfil obtidos")
                else:
                    progress.close()
                    notify("GRUPO TRAINAGAIN", f"Falha ao obter perfil MAC {config_id}", xbmcgui.NOTIFICATION_WARNING)
            else:
                progress.close()
                notify("GRUPO TRAINAGAIN", f"Falha na autenticação MAC {config_id}", xbmcgui.NOTIFICATION_ERROR)
                
        except Exception as e:
            progress.close()
            log(f"Erro no teste de conexão MAC: {e}", xbmc.LOGERROR)
            notify("GRUPO TRAINAGAIN", f"Erro no teste: {str(e)}", xbmcgui.NOTIFICATION_ERROR)

# Ponto de entrada
if __name__ == '__main__':
    try:
        app = TrainAgainIcones()
        app.router(sys.argv[2][1:])
    except Exception as e:
        log(f"Erro fatal: {e}", xbmc.LOGERROR)
        notify("GRUPO TRAINAGAIN", f"Erro: {e}", xbmcgui.NOTIFICATION_ERROR)


    
    # FUNCIONALIDADES MAC ORIGINAIS - COMPATIBILIDADE
    def show_mac_portal(self):
        """Mostrar menu principal do Stalker Portal"""
        log("Mostrando menu Stalker Portal")
        
        trainagain_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/trainagain_main_fanart.png"
        
        # Obter configurações MAC
        mac_settings = self.mac_manager.get_mac_settings()
        
        if not mac_settings['enabled'] or not mac_settings['portal'] or not mac_settings['mac']:
            notify("Stalker Portal", "Configure Portal e MAC nas definições", xbmcgui.NOTIFICATION_WARNING)
            return
        
        # Adicionar opções do menu MAC
        menu_items = [
            ("📺 TV ao Vivo", "mac_genres", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"),
            ("🔧 Testar Conexão MAC", "test_mac_connection", "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/test_connection_icon.png")
        ]
        
        for title, action, icon_path in menu_items:
            url = f"{self.url}?action={action}"
            
            list_item = xbmcgui.ListItem(label=title)
            
            # Adicionar ícone e fanart
            art_dict = {
                'icon': icon_path, 
                'thumb': icon_path,
                'fanart': trainagain_fanart
            }
            list_item.setArt(art_dict)
            
            xbmcplugin.addDirectoryItem(self.handle, url, list_item, True)
        
        xbmcplugin.endOfDirectory(self.handle)
    
    def show_mac_genres(self):
        """Mostrar géneros/categorias MAC (versão original)"""
        log("Mostrando géneros MAC")
        
        trainagain_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/trainagain_main_fanart.png"
        
        # Obter configurações MAC
        mac_settings = self.mac_manager.get_mac_settings()
        portal = mac_settings['portal']
        mac = mac_settings['mac']
        user_agent = mac_settings.get('user_agent', 'MAG250')
        
        try:
            # Processo de autenticação MAC
            token = self.mac_manager.mac_handshake(portal, mac, user_agent)
            if not token:
                notify("Stalker Portal", "Falha na autenticação - Verifique Portal e MAC", xbmcgui.NOTIFICATION_ERROR)
                return
            
            profile = self.mac_manager.mac_get_profile(portal, mac, token)
            if not profile:
                notify("Stalker Portal", "Falha ao obter perfil", xbmcgui.NOTIFICATION_ERROR)
                return
            
            genres = self.mac_manager.mac_get_genres(portal, mac, token, profile)
            if not genres:
                notify("Stalker Portal", "Nenhum género encontrado", xbmcgui.NOTIFICATION_WARNING)
                return
            
            # Mostrar géneros com ícones de países
            for genre in genres:
                # Obter ícone do país para o género
                flag_path, emoji = self.country_icon_manager.get_category_icon(genre['title'])
                
                # Se não encontrar bandeira, usar ícone padrão
                if not flag_path:
                    icon_path = "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"
                    title = f"📂 {genre['title']}"
                else:
                    icon_path = flag_path
                    title = f"{emoji} {genre['title']}"
                
                url = f"{self.url}?action=mac_channels&genre_id={genre['id']}&genre_title={genre['title']}"
                
                list_item = xbmcgui.ListItem(label=title)
                
                # Adicionar ícone e fanart
                art_dict = {
                    'icon': icon_path,
                    'thumb': icon_path,
                    'fanart': trainagain_fanart
                }
                list_item.setArt(art_dict)
                
                xbmcplugin.addDirectoryItem(self.handle, url, list_item, True)
            
            xbmcplugin.endOfDirectory(self.handle)
            
        except Exception as e:
            log(f"Erro ao obter géneros MAC: {e}", xbmc.LOGERROR)
            notify("Stalker Portal", f"Erro: {e}", xbmcgui.NOTIFICATION_ERROR)
    
    def show_mac_channels(self, genre_id, genre_title):
        """Mostrar canais por género MAC (versão original)"""
        log(f"Mostrando canais MAC para género {genre_id}")
        
        trainagain_fanart = "special://home/addons/plugin.video.trainagain.icones/resources/media/fanart/trainagain_main_fanart.png"
        
        # Obter configurações MAC
        mac_settings = self.mac_manager.get_mac_settings()
        portal = mac_settings['portal']
        mac = mac_settings['mac']
        user_agent = mac_settings.get('user_agent', 'MAG250')
        
        try:
            # Mostrar progresso de carregamento
            progress = xbmcgui.DialogProgress()
            progress.create("Stalker Portal", f"Carregando canais de {genre_title}...")
            progress.update(10, "Autenticando...")
            
            # Processo de autenticação MAC
            token = self.mac_manager.mac_handshake(portal, mac, user_agent)
            if not token:
                progress.close()
                notify("Stalker Portal", "Falha na autenticação", xbmcgui.NOTIFICATION_ERROR)
                return
            
            progress.update(30, "Carregando lista de canais...")
            
            # Obter canais com paginação completa
            channels = self.mac_manager.mac_get_channels(portal, mac, token, genre_id)
            
            progress.update(90, f"Processando {len(channels)} canais...")
            
            if not channels:
                progress.close()
                notify("Stalker Portal", f"Nenhum canal encontrado em {genre_title}", xbmcgui.NOTIFICATION_WARNING)
                return
            
            progress.update(100, "Concluído!")
            progress.close()
            
            # Mostrar canais com logos otimizados
            for channel in channels:
                title = f"📺 {channel['name']}"
                url = f"{self.url}?action=play_mac_channel&ch_id={channel['ch_id']}&title={channel['name']}"
                
                list_item = xbmcgui.ListItem(label=title)
                list_item.setProperty('IsPlayable', 'true')
                
                # Usar logo do canal com validação MELHORADA
                logo_url = channel.get('logo', '').strip()
                
                # DEBUG: Log do logo recebido
                log(f"Canal: {channel['name']}, Logo recebido: '{logo_url}'")
                
                if logo_url:
                    # Validar e construir URL do logo
                    if logo_url.startswith('http'):
                        # URL absoluta - usar diretamente
                        icon_path = logo_url
                        thumb_path = logo_url
                        log(f"Logo absoluto: {logo_url}")
                    elif logo_url.startswith('/'):
                        # URL relativa - construir URL completa
                        portal_base = self.mac_manager.get_mac_settings()['portal'].rstrip('/')
                        full_logo_url = f"{portal_base}{logo_url}"
                        icon_path = full_logo_url
                        thumb_path = full_logo_url
                        log(f"Logo relativo construído: {full_logo_url}")
                    elif '.' in logo_url and ('/' in logo_url or logo_url.endswith(('.png', '.jpg', '.jpeg', '.gif', '.svg'))):
                        # Caminho de imagem - construir URL
                        portal_base = self.mac_manager.get_mac_settings()['portal'].rstrip('/')
                        full_logo_url = f"{portal_base}/{logo_url}"
                        icon_path = full_logo_url
                        thumb_path = full_logo_url
                        log(f"Logo caminho construído: {full_logo_url}")
                    else:
                        # Logo inválido - usar ícone padrão
                        icon_path = "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"
                        thumb_path = "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"
                        log(f"Logo inválido '{logo_url}', usando ícone padrão")
                else:
                    # Sem logo - usar ícone padrão
                    icon_path = "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"
                    thumb_path = "special://home/addons/plugin.video.trainagain.icones/resources/media/icons/tv_live_icon.png"
                    log(f"Sem logo para {channel['name']}, usando ícone padrão")
                
                # Adicionar ícone e fanart
                art_dict = {
                    'icon': icon_path,
                    'thumb': thumb_path,
                    'fanart': trainagain_fanart
                }
                list_item.setArt(art_dict)
                
                xbmcplugin.addDirectoryItem(self.handle, url, list_item, False)
            
            xbmcplugin.endOfDirectory(self.handle)
            
        except Exception as e:
            log(f"Erro ao obter canais MAC: {e}", xbmc.LOGERROR)
            notify("Stalker Portal", f"Erro: {e}", xbmcgui.NOTIFICATION_ERROR)
    
    def play_mac_channel(self, ch_id, title):
        """Reproduzir canal MAC (versão original)"""
        log(f"Reproduzindo canal MAC: {title} (ID: {ch_id})")
        
        # Obter configurações MAC
        mac_settings = self.mac_manager.get_mac_settings()
        portal = mac_settings['portal']
        mac = mac_settings['mac']
        user_agent = mac_settings.get('user_agent', 'MAG250')
        
        try:
            # Mostrar progresso
            progress = xbmcgui.DialogProgress()
            progress.create("Stalker Portal", f"Preparando reprodução de {title}...")
            progress.update(10, "Autenticando...")
            
            # Processo de autenticação MAC
            token = self.mac_manager.mac_handshake(portal, mac, user_agent)
            if not token:
                progress.close()
                notify("Stalker Portal", "Falha na autenticação", xbmcgui.NOTIFICATION_ERROR)
                return
            
            progress.update(50, "Obtendo URL do stream...")
            
            # Obter URL do stream
            stream_url = self.mac_manager.mac_create_link(portal, mac, token, ch_id)
            
            if not stream_url:
                progress.close()
                notify("Stalker Portal", "Falha ao obter URL do stream", xbmcgui.NOTIFICATION_ERROR)
                return
            
            progress.update(90, "Iniciando reprodução...")
            progress.close()
            
            # Criar item de reprodução
            list_item = xbmcgui.ListItem(path=stream_url)
            list_item.setProperty('IsPlayable', 'true')
            
            # Configurar para usar inputstream.adaptive se necessário
            if '.m3u8' in stream_url or 'mpd' in stream_url:
                list_item.setProperty('inputstream', 'inputstream.adaptive')
                if '.m3u8' in stream_url:
                    list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                elif 'mpd' in stream_url:
                    list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            
            # Reproduzir
            xbmc.Player().play(stream_url, list_item)
            log(f"Reproduzindo stream MAC: {stream_url}")
            
        except Exception as e:
            log(f"Erro ao reproduzir canal MAC: {e}", xbmc.LOGERROR)
            notify("Stalker Portal", f"Erro na reprodução: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
    
    def test_mac_connection(self):
        """Testar conexão MAC (versão original)"""
        log("Testando conexão MAC")
        
        # Obter configurações MAC
        mac_settings = self.mac_manager.get_mac_settings()
        
        if not mac_settings['enabled'] or not mac_settings['portal'] or not mac_settings['mac']:
            notify("Stalker Portal", "Configure Portal e MAC nas definições", xbmcgui.NOTIFICATION_ERROR)
            return
        
        # Mostrar progresso
        progress = xbmcgui.DialogProgress()
        progress.create("Stalker Portal", "Testando conexão MAC...")
        progress.update(10, "Iniciando teste...")
        
        try:
            progress.update(30, "Realizando handshake...")
            
            # Testar handshake
            token = self.mac_manager.mac_handshake(mac_settings['portal'], mac_settings['mac'], mac_settings.get('user_agent', 'MAG250'))
            
            if token:
                progress.update(60, "Obtendo perfil...")
                
                # Testar perfil
                profile = self.mac_manager.mac_get_profile(mac_settings['portal'], mac_settings['mac'], token)
                
                if profile:
                    progress.update(100, "Teste concluído!")
                    progress.close()
                    notify("Stalker Portal", "Conexão MAC bem-sucedida!", xbmcgui.NOTIFICATION_INFO)
                    log("Teste MAC bem-sucedido - Token e perfil obtidos")
                else:
                    progress.close()
                    notify("Stalker Portal", "Falha ao obter perfil MAC", xbmcgui.NOTIFICATION_WARNING)
            else:
                progress.close()
                notify("Stalker Portal", "Falha na autenticação MAC", xbmcgui.NOTIFICATION_ERROR)
                
        except Exception as e:
            progress.close()
            log(f"Erro no teste de conexão MAC: {e}", xbmc.LOGERROR)
            notify("Stalker Portal", f"Erro no teste: {str(e)}", xbmcgui.NOTIFICATION_ERROR)



# Ponto de entrada
if __name__ == '__main__':
    try:
        app = TrainAgainIcones()
        app.router(sys.argv[2][1:])
    except Exception as e:
        log(f"Erro fatal: {e}", xbmc.LOGERROR)
        notify("GRUPO TRAINAGAIN", f"Erro: {e}", xbmcgui.NOTIFICATION_ERROR)

