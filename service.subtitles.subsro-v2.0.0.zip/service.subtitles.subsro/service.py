# -*- coding: utf-8 -*-

import json
from operator import itemgetter
import os
import re
import sys
import time
import unicodedata
import urllib
try: 
    import urllib2
    import urllib
    py3 = False
except ImportError: 
    import urllib.request as urllib2
    import urllib.parse as urllib
    py3 = True
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import ssl
ssl._create_default_https_context = ssl._create_unverified_context

__addon__ = xbmcaddon.Addon()
__scriptid__   = __addon__.getAddonInfo('id')
__scriptname__ = __addon__.getAddonInfo('name')

if py3:
    xpath = xbmcvfs.translatePath
else:
    xpath = xbmc.translatePath

__cwd__        = xpath(__addon__.getAddonInfo('path')) if py3 else xpath(__addon__.getAddonInfo('path')).decode("utf-8")
__profile__    = xpath(__addon__.getAddonInfo('profile')) if py3 else xpath(__addon__.getAddonInfo('profile')).decode("utf-8")
__resource__   = xpath(os.path.join(__cwd__, 'resources', 'lib')) if py3 else xpath(os.path.join(__cwd__, 'resources', 'lib')).decode("utf-8")
__temp__       = xpath(os.path.join(__profile__, 'temp', ''))

BASE_URL = "https://subs.ro/"

sys.path.append (__resource__)
import requests
from bs4 import BeautifulSoup

from requests.packages.urllib3.exceptions import InsecureRequestWarning
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

def log(msg):
    log_level = xbmc.LOGINFO if py3 else xbmc.LOGNOTICE
    try:
        xbmc.log("### [%s] - %s" % (__scriptid__, str(msg)), level=log_level)
    except Exception: pass

def get_episode_pattern(episode):
    parts = episode.split(':')
    if len(parts) < 2: return "%%%%%"
    try:
        season, epnr = int(parts[0]), int(parts[1])
        patterns = [ "s%#02de%#02d" % (season, epnr), "%#02dx%#02d" % (season, epnr), "%#01de%#02d" % (season, epnr) ]
        if season < 10: patterns.append("(?:\A|\D)%dx%#02d" % (season, epnr))
        return '(?:%s)' % '|'.join(patterns)
    except:
        return "%%%%%"

def unpack_archive(archive_physical_path, dest_physical_path, archive_type):
    all_files = []
    subtitle_exts = [".srt", ".sub", ".txt", ".smi", ".ssa", ".ass"]
    
    try:
        vfs_archive_path = '%s://%s' % (archive_type, urllib.quote_plus(archive_physical_path))
        log("Initializez extragerea...")
        log("Copiez continutul arhivei...")
        
        def recursive_unpack(current_vfs_path, current_dest_path):
            extracted_list = []
            try:
                dirs, files = xbmcvfs.listdir(current_vfs_path)
                
                if not xbmcvfs.exists(current_dest_path):
                    xbmcvfs.mkdirs(current_dest_path)

                for file_name in files:
                    if not py3 and isinstance(file_name, bytes):
                        file_name = file_name.decode('utf-8')

                    if os.path.splitext(file_name)[1].lower() in subtitle_exts:
                        source_vfs_file = os.path.join(current_vfs_path, file_name)
                        dest_physical_file = os.path.join(current_dest_path, file_name)
                        
                        try:
                            source_obj = xbmcvfs.File(source_vfs_file, 'r')
                            dest_obj = xbmcvfs.File(dest_physical_file, 'wb')
                            content = source_obj.readBytes()
                            dest_obj.write(content)
                            source_obj.close()
                            dest_obj.close()
                            extracted_list.append(dest_physical_file)
                        except Exception as e:
                            log("EROARE la copierea fisierului %s: %s" % (file_name, e))

                for dir_name in dirs:
                    if not py3 and isinstance(dir_name, bytes):
                        dir_name = dir_name.decode('utf-8')
                        
                    next_vfs_path = os.path.join(current_vfs_path, dir_name)
                    next_dest_path = os.path.join(current_dest_path, dir_name)
                    extracted_list.extend(recursive_unpack(next_vfs_path, next_dest_path))
            
            except Exception as e:
                log("EROARE in timpul recursivitatii VFS pentru calea %s: %s" % (current_vfs_path, e))

            return extracted_list

        all_files = recursive_unpack(vfs_archive_path, dest_physical_path)
        return all_files

    except Exception as e:
        log("EROARE fatala la initializarea extragerii arhivei: %s" % e)
        return []

def Search(item):
    temp_dir = __temp__
    try:
        if xbmcvfs.exists(temp_dir):
            log("Directorul temporar vechi a fost gasit. Se incearca stergerea: %s" % temp_dir)
            deleted = xbmcvfs.rmdir(temp_dir, True)
            if not deleted:
                log("EROARE CRITICA: Nu s-a putut sterge directorul temporar vechi. Pot aparea subtitrari vechi.")
        
        log("Se creeaza un director temporar nou si gol: %s" % temp_dir)
        xbmcvfs.mkdirs(temp_dir)
    except Exception as e:
        log("EROARE la initializarea directorului temporar: %s" % str(e))
        return

    filtered_subs, raw_count = searchsubtitles(item)
    
    if not filtered_subs:
        if raw_count > 0:
            log("S-au gasit %d rezultate, dar niciunul nu se potriveste cu limbile preferate." % raw_count)
            xbmcgui.Dialog().ok(__scriptname__, "Nicio subtitrare gasita dupa preferintele de limba selectate")
        else:
            log("Nicio subtitrare returnata de searchsubtitles.")
            xbmcgui.Dialog().ok(__scriptname__, "Nicio subtitrare gasita pe site pentru acest Film/Serial")
        return

    sel = 0
    if len(filtered_subs) > 0:
        dialog = xbmcgui.Dialog()
        titles = [sub["SubFileName"] for sub in filtered_subs]
        sel = dialog.select("Selectati subtitrarea", titles)
    
    if sel >= 0:
        selected_sub_info = filtered_subs[sel]
        link = selected_sub_info["ZipDownloadLink"]
        
        s = requests.Session()
        s.headers.update({'Referer': BASE_URL})
        response = s.get(link, verify=False)
        
        content_disp = response.headers.get('Content-Disposition', '')
        Type = 'zip'
        if 'filename=' in content_disp:
            try:
                fname_header = re.findall('filename="?([^"]+)"?', content_disp)[0]
                if fname_header.lower().endswith('.rar'): Type = 'rar'
            except: pass

        if Type == 'rar' and not xbmc.getCondVisibility('System.HasAddon(vfs.rar)'):
            log("EROARE: Add-on-ul 'vfs.rar' (RAR archive support) nu este instalat.")
            xbmcgui.Dialog().ok("Componentă lipsă", "Pentru a extrage arhive RAR, instalati 'RAR archive support' din repository-ul oficial Kodi.")
            return

        timestamp = str(int(time.time()))
        fname = os.path.join(temp_dir, "subtitle_%s.%s" % (timestamp, Type))
        
        try:
            f = xbmcvfs.File(fname, 'wb')
            f.write(response.content)
            f.close()
            log("Fisier arhiva salvat la: %s" % fname)
        except Exception as e:
            log("EROARE la scrierea fisierului arhiva: %s" % e)
            xbmcgui.Dialog().ok("Eroare la Salvare", "Nu s-a putut salva arhiva de subtitrări în directorul temporar.[CR]Verificați permisiunile sau spațiul de stocare.")
            return

        extractPath = os.path.join(temp_dir, "Extracted")
        if not xbmcvfs.exists(extractPath):
            xbmcvfs.mkdirs(extractPath)
        
        all_files = unpack_archive(fname, extractPath, Type)
        
        if not all_files:
            log("Extragerea a esuat sau nu s-au gasit fisiere de subtitrare.")
            xbmcgui.Dialog().ok("Eroare la extragere", "Arhiva descărcată este goală, coruptă sau într-un format necunoscut.[CR]Nu s-a găsit nicio subtitrare validă.")
            return
        
        valid_files = []
        for f in all_files:
            try:
                if xbmcvfs.Stat(f).st_size() > 0:
                    valid_files.append(f)
                else:
                    log("Fisier de 0 KB gasit si ignorat: %s" % f)
            except Exception as e:
                log("EROARE la verificarea marimii fisierului %s: %s" % (f, e))

        if not valid_files:
            log("EROARE: Toate fisierele extrase au 0 KB. Arhiva este probabil corupta.")
            if Type == 'rar':
                xbmcgui.Dialog().ok(__scriptname__, "Dezarhivare esuata. Arhiva este de tip RAR.")
            elif Type == 'zip':
                xbmcgui.Dialog().ok(__scriptname__, "Dezarhivare esuata. Incearca din nou.")
            return

        all_files = valid_files
        
        log("S-au gasit %d fisiere de subtitrare valide dupa extragere." % len(all_files))
        all_files = sorted(all_files, key=lambda f: natural_key(os.path.basename(f)))

        subs_list = []
        season, episode = item.get("season"), item.get("episode")
        if episode and season and season != "0" and episode != "0":
            epstr = '%s:%s' % (season, episode)
            log("Filtrez pentru Sezonul %s Episodul %s" % (season, episode))
            episode_regex = re.compile(get_episode_pattern(epstr), re.IGNORECASE)
            
            for sub_file in all_files:
                if episode_regex.search(os.path.basename(sub_file)):
                    subs_list.append(sub_file)
            if subs_list:
                log("Am gasit %d subtitrari potrivite pentru episod." % len(subs_list))
                all_files = sorted(subs_list, key=lambda f: natural_key(os.path.basename(f)))
        
        for sub_file in all_files:
            basename = normalizeString(os.path.basename(sub_file))
            listitem = xbmcgui.ListItem(label=selected_sub_info['SubFileName'], label2=basename)
            listitem.setArt({'icon': selected_sub_info["SubRating"], 'thumb': selected_sub_info["ISO639"]})
            url = "plugin://%s/?action=setsub&link=%s" % (__scriptid__, urllib.quote_plus(sub_file))
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=False)

def searchsubtitles(item):
    import PTN
    s = requests.Session()
    s.headers.update({
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
        'Accept': '*/*', 'Accept-Language': 'en-US,en;q=0.9,ro;q=0.8', 'Origin': BASE_URL.rstrip('/'), 'Referer': BASE_URL + 'cautare'
    })
    
    languages_to_keep = item.get('languages', [])
    log("Vom pastra doar subtitrarile pentru limbile: %s" % languages_to_keep)
    
    tmdb_id = xbmc.getInfoLabel("VideoPlayer.TVShow.TMDbId") or xbmc.getInfoLabel("VideoPlayer.TMDbId")
    if tmdb_id and tmdb_id.isdigit():
        log("Prioritate 1: Am gasit TMDB ID: %s. Incercam cautarea..." % tmdb_id)
        post_data = {'type': 'subtitrari', 'external_id': tmdb_id}
        html_content = fetch_subtitles_page(s, post_data)
        if html_content:
            return parse_results(html_content, languages_to_keep)

    imdb_id = xbmc.getInfoLabel("VideoPlayer.IMDBNumber")
    if imdb_id and imdb_id.startswith('tt'):
        imdb_id_numeric = imdb_id.replace("tt", "")
        log("Prioritate 2: Am gasit IMDB ID: %s. Incercam cautarea cu ID numeric: %s." % (imdb_id, imdb_id_numeric))
        post_data = {'type': 'subtitrari', 'external_id': imdb_id_numeric}
        html_content = fetch_subtitles_page(s, post_data)
        if html_content:
            return parse_results(html_content, languages_to_keep)

    log("Fallback: Cautare dupa text.")
    original_path = item.get('file_original_path', '')
    if item.get('mansearch'):
        search_string_raw = urllib.unquote(item.get('mansearchstr', ''))
    else:
        search_string_raw = os.path.basename(original_path) if not original_path.startswith('http') else item.get('title', '')
    parsed = PTN.parse(search_string_raw)
    search_string = parsed.get('title', search_string_raw)
    
    post_data = {'type': 'subtitrari', 'titlu-film': search_string}
    html_content = fetch_subtitles_page(s, post_data)
    if html_content:
        return parse_results(html_content, languages_to_keep)

    return ([], 0)

def fetch_subtitles_page(session, post_data):
    try:
        main_page_resp = session.get(BASE_URL + 'cautare', verify=False, timeout=15)
        main_page_soup = BeautifulSoup(main_page_resp.text, 'html.parser')
        form = main_page_soup.find('form', {'id': 'search-subtitrari'})
        antispam_tag = form.find('input', {'name': 'antispam'}) if form else None
        if not antispam_tag or 'value' not in antispam_tag.attrs: return None
        antispam_token = antispam_tag['value']
        post_data['antispam'] = antispam_token
        ajax_url = BASE_URL + 'ajax/search'
        log("Efectuez cautarea...")
        response = session.post(ajax_url, data=post_data, verify=False, timeout=15)
        response.raise_for_status()
        return response.text
    except: return None

def parse_results(html_content, languages_to_keep):
    soup = BeautifulSoup(html_content, 'html.parser')
    results_html = soup.find_all('div', class_=re.compile(r'w-full bg-\[#F5F3E8\]'))
    raw_count = len(results_html)
    log("Am gasit %d rezultate inainte de filtrare" % raw_count)
    result = []

    LANG_MAP = {
        'rom': ('Romanian', 'ro', 'Română'), 'rum': ('Romanian', 'ro', 'Română'),
        'eng': ('English', 'en', 'Engleză'),
        'fra': ('French', 'fr', 'Franceză'),
        'spa': ('Spanish', 'es', 'Spaniolă'),
        'ger': ('German', 'de', 'Germană'),
        'ita': ('Italian', 'it', 'Italiană'),
        'hun': ('Hungarian', 'hu', 'Maghiară'),
        'ara': ('Arabic', 'ar', 'Arabă'), 'bul': ('Bulgarian', 'bg', 'Bulgară'),
        'cat': ('Catalan', 'ca', 'Catalană'), 'chi': ('Chinese', 'zh', 'Chineză'),
        'hrv': ('Croatian', 'hr', 'Croată'), 'cze': ('Czech', 'cs', 'Cehă'),
        'dan': ('Danish', 'da', 'Daneză'), 'dut': ('Dutch', 'nl', 'Olandeză'),
        'est': ('Estonian', 'et', 'Estonă'), 'fin': ('Finnish', 'fi', 'Finlandeză'),
        'gre': ('Greek', 'el', 'Greacă'), 'heb': ('Hebrew', 'he', 'Ebraică'),
        'hin': ('Hindi', 'hi', 'Hindi'), 'ice': ('Icelandic', 'is', 'Islandeză'),
        'ind': ('Indonesian', 'id', 'Indoneziană'), 'jpn': ('Japanese', 'ja', 'Japoneză'),
        'kor': ('Korean', 'ko', 'Coreeană'), 'lav': ('Latvian', 'lv', 'Letonă'),
        'lit': ('Lithuanian', 'lt', 'Lituaniană'), 'mac': ('Macedonian', 'mk', 'Macedoneană'),
        'may': ('Malay', 'ms', 'Malaeză'), 'nor': ('Norwegian', 'no', 'Norvegiană'),
        'pol': ('Polish', 'pl', 'Poloneză'), 'por': ('Portuguese', 'pt', 'Portugheză'),
        'rus': ('Russian', 'ru', 'Rusă'), 'scc': ('Serbian', 'sr', 'Sârbă'),
        'slo': ('Slovak', 'sk', 'Slovacă'), 'slv': ('Slovenian', 'sl', 'Slovenă'),
        'swe': ('Swedish', 'sv', 'Suedeză'), 'tha': ('Thai', 'th', 'Thailandeză'),
        'tur': ('Turkish', 'tr', 'Turcă'), 'ukr': ('Ukrainian', 'uk', 'Ucraineană'),
        'vie': ('Vietnamese', 'vi', 'Vietnameză'),
    }

    for res_div in results_html:
        try:
            nume, an, limba_text = 'N/A', 'N/A', 'N/A'
            traducator, uploader = 'N/A', 'N/A'
            lang_name, iso_lang = 'Romanian', 'ro'

            title_tag = res_div.find('h2')
            if not title_tag: continue
            
            title_year_container = title_tag.find('span', class_='flex-1')
            if title_year_container:
                year_span = title_year_container.find('span')
                if year_span:
                    an = year_span.get_text(strip=True).strip('()')
                    year_span.extract()
                nume = title_year_container.get_text(strip=True)

            flag_img = title_tag.find('img')
            if flag_img and 'src' in flag_img.attrs:
                src_parts = flag_img['src'].split('-')
                if len(src_parts) > 1:
                    lang_code = src_parts[1]
                    lang_data = LANG_MAP.get(lang_code)
                    if lang_data:
                        lang_name, iso_lang, limba_text = lang_data
                    else:
                        limba_text, iso_lang, lang_name = (lang_code.upper(), lang_code, lang_code.upper())
            
            if languages_to_keep and iso_lang not in languages_to_keep:
                continue

            details = res_div.find_all('span', class_='font-medium text-gray-700')
            for span in details:
                parent_text = span.parent.get_text(strip=True)
                if 'Traducător:' in parent_text:
                    traducator = parent_text.replace('Traducător:', '').strip() or 'N/A'
                elif 'Uploader:' in parent_text:
                    uploader_link = span.parent.find('a')
                    uploader_text = uploader_link.get_text(strip=True) if uploader_link else parent_text.replace('Uploader:', '').strip()
                    uploader = uploader_text or 'N/A'

            download_link = res_div.find('a', href=re.compile(r'/subtitrare/descarca/'))
            if not download_link: continue
            legatura = download_link['href']
            if not legatura.startswith('http'): legatura = BASE_URL.rstrip('/') + legatura

            main_part = u'[B]%s (%s)[/B]' % (nume, an)
            lang_part = u'Limba: [COLOR FFC53822]%s[/COLOR]' % (limba_text)
            trad_part = u'Traducător: [COLOR FFC53822]%s[/COLOR]' % (traducator)
            up_part = u'Uploader: [COLOR FFC53822]%s[/COLOR]' % (uploader)
            display_name = u'%s | %s | %s | %s' % (main_part, lang_part, trad_part, up_part)
            
            result.append({
                'SubFileName': display_name, 
                'ZipDownloadLink': legatura, 
                'LanguageName': lang_name, 
                'ISO639': iso_lang, 
                'SubRating': '5', 
                'Traducator': traducator
            })
        except Exception as e:
            log("EROARE la parsarea unui rezultat: %s" % e)
            continue
            
    log("Am extras in total %d subtitrari DUPA aplicarea filtrului de limba." % len(result))
    
    sorted_result = sorted(result, key=lambda sub: 0 if sub['ISO639'] == 'ro' else 1)
    
    return (sorted_result, raw_count)

def natural_key(string_): return [int(s) if s.isdigit() else s for s in re.split(r'(\d+)', string_)]
def normalizeString(obj):
    if py3: return obj
    try: return unicodedata.normalize('NFKD', unicode(obj, 'utf-8')).encode('ascii', 'ignore')
    except: return unicode(str(obj).encode('string_escape'))

def get_params():
    param = {}
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        for pair in paramstring.replace('?', '').split('&'):
            split = pair.split('=')
            if len(split) == 2: param[split[0]] = split[1]
    return param

params = get_params()
action = params.get('action')

if action in ('search', 'manualsearch'):
    item = {
        'mansearch': action == 'manualsearch',
        'file_original_path': xbmc.Player().getPlayingFile() if py3 else xbmc.Player().getPlayingFile().decode('utf-8'),
        'title': normalizeString(xbmc.getInfoLabel("VideoPlayer.OriginalTitle") or xbmc.getInfoLabel("VideoPlayer.Title")),
        'season': str(xbmc.getInfoLabel("VideoPlayer.Season")), 'episode': str(xbmc.getInfoLabel("VideoPlayer.Episode"))
    }
    if item.get('mansearch'): item['mansearchstr'] = params.get('searchstring', '')
    lang_param = urllib.unquote(params.get('languages', ''))
    item['languages'] = [xbmc.convertLanguage(lang, xbmc.ISO_639_1) for lang in lang_param.split(',') if lang]
    Search(item)

elif action == 'setsub':
    link = urllib.unquote_plus(params.get('link', ''))
    if link:
        log("Setam subtitrarea la: %s" % link)
        xbmc.Player().setSubtitles(link)
        listitem = xbmcgui.ListItem(label=link)
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=link, listitem=listitem, isFolder=False)

xbmcplugin.endOfDirectory(int(sys.argv[1]))