# -*- coding: utf-8 -*-
import os
import sys

try:
    from urllib.parse import urlparse, urlencode
    from urllib.request import urlopen, Request
    from urllib.error import HTTPError
except ImportError:
    from urlparse import urlparse
    from urllib import urlencode
    from urllib2 import urlopen, Request, HTTPError


import re
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import xbmcplugin
import plugintools
import unicodedata
import base64
import requests
import shutil
import base64
import time
import six
import random
from datetime import date
from datetime import datetime
try:
    from resolveurl.lib import jsunpack 
except ImportError:
    from resolveurl.plugins.lib import jsunpack 
from resources.modules import control

    
#PY3=False
addon = xbmcaddon.Addon()
addonname = 'Optimus TV RO'
icon = addon.getAddonInfo('icon')
myaddon = xbmcaddon.Addon("plugin.video.optimustv")
#px={"http": "http://14.139.189.213:3128"}
px=''
f4mproxy = 'true'

## Fotos
thmb_nada='https://archive.org/download/bee-1/pngegg%20%281%29.png'
thmb_ver_canales='https://archive.org/download/bee-1/channels%20live.png'
thmb_ver_vod='https://archive.org/download/bee-1/vod%20mac.png'
thmb_cambio_servidor='https://archive.org/download/bee-1/server.png'
thmb_cambio_mac='https://archive.org/download/bee-1/MAC.png'
thmb_carga_servidores='https://archive.org/download/bee-1/arrow.png'
thmb_guarda_servidores='https://archive.org/download/bee-1/rack-server_icon-icons.com_52830.png'
thmb_nuevo_servidor='https://icons.iconarchive.com/icons/custom-icon-design/pretty-office-9/256/new-file-icon.png'
thmb_guia='https://static.vecteezy.com/system/resources/previews/000/567/906/non_2x/vector-tv-icon.jpg'
fanny="https://i.ytimg.com/vi/_7bFXWNfXTY/maxresdefault.jpg"
fanart_guia="http://www.panoramaaudiovisual.com/wp-content/uploads/2012/01/EPG-Toshiba-Smart-Tv-web.png"
backgr="https://freeiptvstb.com/wp-content/uploads/2021/06/UZ4VHKEdhTkviRzJSEfFZC.jpg"
thmb_ver_set='https://archive.org/download/bee-1/settings.png'
thmb_ver_xc='https://archive.org/download/bee-1/xtream%20codes.png'
thmb_ver_stb='https://archive.org/download/bee-1/mac-iptv.png'
thmb_ver_m3u='https://archive.org/download/bee-1/live-iptv.png'
thmb_about='https://archive.org/download/bee-1/about.png'
thmb_radio='https://archive.org/download/bee-1/radio.png'
fnrt_radio='http://www.elzulianorajao.com/images/site/radio-g.jpg'
thmb_help='https://archive.org/download/bee-1/help.png'
thmb_ace='https://archive.org/download/bee-1/Ace%20Stream.png'
thmb_tube='https://archive.org/download/bee-1/Tube.png'






   
def run():
    
    plugintools.log("---> macvod.run <---")
    #plugintools.set_view(plugintools.LIST)
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
       action = params.get("action")
       url = params.get("url")
       exec(action+"(params)")
    plugintools.close_item_list()

    
def main_list(params):

    import shutil,xbmc  
    try:
        addon_path3 = xbmcvfs.translatePath('special://home/cache').decode('utf-8')
        shutil.rmtree(addon_path3, ignore_errors=True) 
    except:
        pass
    
        
    plugintools.log("macvod.main_list ")    
    
    url2_enc = 'https://pastebin.com/raw/jCF4q8nn'   


    cap = requests.get(url2_enc)
    captur = cap.content
    captura = captur.decode('utf-8')
    look = re.findall(r'group-title="([^"]+)', captura)
    almacen_grupos = sorted(list(set(look)))   # Utilizarea set-ului pentru unicitate, apoi convertirea în listă

    for title in almacen_grupos:
        title_lower = title.lower()
        plugintools.add_item(
            action="resolve_lista",
            title=f"[B][CAPITALIZE][COLOR white]{title_lower.strip()}[/COLOR][/CAPITALIZE][/B]",
            url=url2_enc.strip(),
            plot=title_lower,
            fanart='https://canale-romanesti.com/wp-content/uploads/2023/06/topbanner19.webp',
            thumbnail='https://www.anume.tv/images/iptvextreme.png',
            extra=title,
            folder=True,
            isPlayable=False
        )
    
def resolve_lista(params):

    url3 = params.get("url")
    seleccion = (params.get("extra")).strip()
    url_menu = params.get("plot")

    cap = requests.get(url3)
    captur = cap.content
    captura = captur.decode('utf-8')
    acc= ''
    name='plugin.video.f4mTester'
    pathTOaddon = os.path.join(xbmcvfs.translatePath('special://home/addons'), name)
    
    rezolva ='inpstr'
    
    if not os.path.exists(pathTOaddon)==True:
        acc ='resolve_without_resolveurl'

    else:
        acc ='Player_f4mtester'
        
    mac1 = urlopen(Request("https://pastebin.com/raw/Gr77yUCt")).read().decode('utf-8')
    mac_list = re.findall(r'(00:.*?79:.*?........)', mac1)    
                
    matches = re.findall(r'#EXTINF.*?tvg-logo="(.*?)" group-title="(.*?)",(.*?)\n([\S ]+)', captura, re.DOTALL)
    for thumb, grup, title, url in matches:
        if grup.strip() == seleccion:
            if not thumb:
                thumb = 'https://www.anume.tv/images/iptvextreme.png'
            titulo = title.lower()
            
            # Alege un MAC aleatoriu
            maclista = random.choice(mac_list)
            url3 = url.replace('00:1A:79:A7:AE:D5', maclista)

            plugintools.add_item(
                action=rezolva,
                title=f"[B][CAPITALIZE][COLOR white]{titulo.strip()}[/COLOR][/CAPITALIZE][/B]",
                url=url3.strip(),
                thumbnail=thumb,
                fanart="https://i.imgur.com/r3lavFX.jpg",
                folder=False,
                isPlayable=True
            )

def inpstr(params):
    plugin = xbmcvfs.translatePath('special://home/addons/inputstream.ffmpegdirect')
    if os.path.exists(plugin)==False:
        try:
            xbmc.executebuiltin('InstallAddon(inputstream.ffmpegdirect)', wait=True)
        except:
            pass
    url = params.get("url")
    request_headers=[]
    request_headers.append(["User-Agent","Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"])
    name = params.get("title")
    iconimage = params.get("thumbnail") 
    liz = xbmcgui.ListItem(name)
    liz.setArt({'thumb': iconimage, 'icon': iconimage})
    liz.setInfo(type='Video', infoLabels={'Title': name, 'mediatype': 'video'})
    liz.setProperty("IsPlayable", "true")
    liz.setProperty('inputstream', 'inputstream.adaptive')
    liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
    liz.setMimeType('application/vnd.apple.mpegstream_url')
    liz.setContentLookup(False)
    liz.setPath(url)
    xbmc.Player().play(url)  

def Player_f4mtester(params):
    
    name=params.get("title")
    url=params.get("url")
    iconimage = params.get("thumbnail")
    addon_id  = 'plugin.video.f4mTester'
    icon =xbmcvfs.translatePath(os.path.join('special://home/addons/' + addon_id, 'icon.png'))
    F4M  = xbmcvfs.translatePath(os.path.join('special://home/addons/plugin.video.f4mTester'))
    dialog = xbmcgui.Dialog()
    
    if not 'f4m'in url:
        if '.m3u8'in url:#plugin://plugin.video.f4mTester/?streamtype=TSDOWNLOADER;name=RobinHoodTv;url=http://mag.cobra-group.media:80/trJPKTaxaE/oFHKoOjf7t/92601
            url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name='+name+'&amp;url='+url     
        elif '.ts'in url:
            url = url.replace('.ts','.m3u8')
            url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name='+name+'&amp;url='+url     
        elif '.mpegts'in url:
            url = url.replace('.mpegts','.m3u8')
            url = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&amp;name='+name+'&amp;url='+url 

    if "plugin://" in url:
        if not os.path.exists(F4M):
            dialog.ok('[COLOR red]F4M TESTER NOT INSTALLED![/COLOR]', "This link requires F4M Tester be installed. Please install F4M from the Shani Repo at http://fusion.tvaddons.ag")
            instalador_f4mTester(params)
        url = "PlayMedia("+url+")"
        xbmc.executebuiltin(url)
        quit()

    if 'http' in url:
        url = url + '|User-Agent=Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30'
    liz = xbmcgui.ListItem("Optimus Tv", name, url)
    xbmc.Player ().play(url, liz, windowed = False)

def resolve_without_resolveurl(params):
   import resolveurl
   finalurl = (params.get ( "url" ))
   plugintools.play_resolved_url ( finalurl )

run()