# -*- coding: utf-8 -*-
from resources.functions import *
import tempfile
import ssl
import hashlib
import pickle
import abc
import os
import re
import sys
import json
import ast

# Ensure requests is available from the bundled path
try:
    from resources.lib import requests as requests
except Exception:
    import requests  # fallback if available

# URL encoding helpers
try:
    from urllib.parse import quote, quote_plus, unquote
except ImportError:
    # Py2 fallback (Kodi 18 and older)
    from urllib import quote, quote_plus, unquote

__settings__ = xbmcaddon.Addon()
zeroseed = __settings__.getSetting("zeroseed") == 'true'

torrentsites = ['filelist', 'uindex', 'speedapp', 'yts']

torrnames = {
    'filelist': {'nume': 'FileList', 'thumb': os.path.join(media, 'filelist.png')},
    'uindex': {'nume': 'UIndex', 'thumb': os.path.join(media, 'uindex.png')},
    'speedapp': {'nume': 'SpeedApp', 'thumb': os.path.join(media, 'speedapp.png')},
    'yts': {'nume': 'YTS', 'thumb': os.path.join(media, 'yts.png')},
}

def getKey(item):
    return item[1]

def save_cookie(name, session):
    cookie = os.path.join(dataPath, name + '.txt')
    with open(cookie, 'wb') as f:
        pickle.dump(session.cookies, f)

def load_cookie(name, session):
    cookie = os.path.join(dataPath, name + '.txt')
    if os.path.exists(cookie):
        try:
            with open(cookie, 'rb') as f:
                session.cookies.update(pickle.load(f))
        except:
            pass
    return session

def clear_cookie(name):
    cookie = os.path.join(dataPath, name + '.txt')
    if os.path.exists(cookie):
        os.remove(cookie)
        origin = torrnames.get(name, {}).get('nume', name)
        log('%s [clear_cookie]: cookie cleared' % origin)

def makeRequest(url, data=None, headers=None, name='', timeout=None, referer=None, rtype=None, savecookie=None, raw=None):
    """
    Wrapper over requests with addon timeout, UA, referer and cookie jar per tracker name.
    """
    from resources.lib.requests.packages.urllib3.exceptions import InsecureRequestWarning
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

    s = requests.Session()
    if name:
        s = load_cookie(name, s)

    timeout = timeout if timeout is not None else int(__settings__.getSetting('timeout') or 15)
    headers = (headers or {}).copy()
    if 'User-Agent' not in headers:
        headers['User-Agent'] = USERAGENT
    if referer is not None:
        headers['Referer'] = referer

    try:
        if data:
            resp = s.post(url, headers=headers, data=data, verify=False, timeout=timeout)
        else:
            resp = s.get(url, headers=headers, verify=False, timeout=timeout)

        if rtype == 'json':
            result = resp.json()
        else:
            if raw:
                result = resp.content
            else:
                try:
                    result = resp.content.decode('utf-8')
                except Exception:
                    result = resp.content.decode('latin-1')

        if savecookie:
            return (result if raw else (result if isinstance(result, str) else str(result)), s)
        else:
            return result if raw else (result if isinstance(result, str) else str(result))

    except BaseException as e:
        log('%s makeRequest(%s) exception: %s' % (name, url, str(e)))
        return

def tempdir():
    if py3:
        dirname = xbmcvfs.translatePath('special://temp')
    else:
        dirname = xbmc.translatePath('special://temp')
    for subdir in ('xbmcup', 'plugin.video.torrenter'):
        dirname = os.path.join(dirname, subdir)
        if not os.path.exists(dirname):
            os.mkdir(dirname)
    return dirname

def md5(string):
    hasher = hashlib.md5()
    hasher.update(string.encode('utf-8'))
    return hasher.hexdigest()

def saveTorrentFile(url, content):
    try:
        temp_dir = tempfile.gettempdir()
    except Exception:
        temp_dir = tempdir()
    localFileName = os.path.join(temp_dir, md5(url) + ".torrent")
    with open(localFileName, 'wb+') as localFile:
        localFile.write(content)
    return localFileName

def clear_title(s):
    return striphtml(unescape(s)).replace('   ', ' ').replace('  ', ' ').strip()


def with_metaclass(meta, base=object):
    """Create a base class with a metaclass.

    Keeps this module compatible with both Python 2 (Kodi 18) and Python 3 (Kodi 19+).
    """
    return meta("TemporaryClass", (base,), {})

class Torrent(with_metaclass(abc.ABCMeta, object)):
    nextimage = next_icon
    searchimage = search_icon

    base_url = ''
    thumb = ''
    name = ''
    username = ''
    password = ''
    search_url = ''
    login_url = ''
    login_data = {}
    login_referer = login_url
    url_referer = ''
    url_host = ''

    def headers(self):
        self.url_referer = self.url_referer or 'https://%s/' % self.base_url
        self.url_host = self.url_host or self.base_url
        headers = {
            'Host': self.url_host,
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
            'Referer': self.url_referer,
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
        }
        return headers

    def cauta(self, keyword, replace=False, limit=None):
        url = self.search_url % (keyword.replace(" ", "-") if replace else quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent', limit=limit)

    def login(self):
        log('Log-in  attempt')
        self.login_headers = {
            'Host': self.base_url,
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
            'Referer': self.login_url,
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3'
        }
        x, session = makeRequest(self.login_url,
                                 name=self.__class__.__name__,
                                 data=self.login_data,
                                 headers=self.login_headers,
                                 savecookie=True)
        if re.search('logout.php|account-details.php', x or ''):
            log('LOGGED %s' % self.name)
        if re.search('incorrect.+?try again|Username or password incorrect', x or '', re.IGNORECASE):
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('%s Login Error' % self.name, 'Parola/Username incorecte')))
            clear_cookie(self.__class__.__name__)
        save_cookie(self.__class__.__name__, session)
        try:
            cookiesitems = session.cookies.items()
        except Exception:
            cookiesitems = []
        for cookie, value in cookiesitems:
            if cookie in ('pass', 'uid', 'username'):
                return cookie + '=' + value
        return False

    def check_login(self, response=None):
        if response:
            response = str(response)
            if re.compile('<input.+?type="password"|<title> FileList :: Login </title>|Not logged in|/register">Sign up now|account-login.php').search(response):
                log('%s Not logged!' % self.name)
                clear_cookie(self.__class__.__name__)
                self.login()
                return False
            if re.search('incorrect.+?try again|Username or password incorrect|Access Denied', response, re.IGNORECASE):
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('%s Login Error' % self.name, 'Parola/Username incorecte')))
                clear_cookie(self.__class__.__name__)
            return True
        return False

    def getTorrentFile(self, url):
        content = makeRequest(url, name=self.__class__.__name__, headers=self.headers(), raw='1')
        if not self.check_login(content):
            content = makeRequest(url, name=self.__class__.__name__, headers=self.headers(), raw='1')
        if re.search("<html", str(content)):
            msg = re.search('Username or password incorrect|User sau parola gresite|Numele de utilizator nu a fost|Date de autentificare invalide', str(content))
            if msg:
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('%s Login Error' % self.name, 'Parola/Username incorecte')))
            xbmc.sleep(4000)
            sys.exit(1)
        return saveTorrentFile(url, content)

class filelist(Torrent):
    def __init__(self):
        self.base_url = 'filelist.io'
        self.thumb = os.path.join(media, 'filelist.png')
        self.name = 'FileList'

        self.sortare = [('Hibrid', '&sort=0'),
                        ('Relevanță', '&sort=1'),
                        ('După dată', '&sort=2'),
                        ('După mărime', '&sort=3'),
                        ('După downloads', '&sort=4'),
                        ('După peers', '&sort=5')]

        self.token = '&usetoken=1'

        self.categorii = [('Anime', 'cat=24'),
                          ('Desene', 'cat=15'),
                          ('Filme 3D', 'cat=25'),
                          ('Filme 4k', 'cat=6'),
                          ('Filme 4k Blu-Ray', 'cat=26'),
                          ('Filme Blu-Ray', 'cat=20'),
                          ('Filme DVD', 'cat=2'),
                          ('Filme DVD-RO', 'cat=3'),
                          ('Filme HD', 'cat=4'),
                          ('Filme HD-RO', 'cat=19'),
                          ('Filme SD', 'cat=1'),
                          ('Seriale 4k', 'cat=27'),
                          ('Seriale HD', 'cat=21'),
                          ('Seriale SD', 'cat=23'),
                          ('Sport', 'cat=13'),
                          ('Videoclip', 'cat=12'),
                          ('XXX', 'cat=7')]
        self.menu = [('Recente', "https://%s/browse.php?cats[]=24&cats[]=15&cats[]=25&cats[]=6&cats[]=26&cats[]=20&cats[]=2&cats[]=3&cats[]=4&cats[]=19&cats[]=1&cats[]=27&cats[]=21&cats[]=23&cats[]=13&cats[]=12&incldead=0" % self.base_url, 'recente', self.thumb)]
        l = []
        for x in self.categorii:
            l.append((x[0], 'https://%s/browse.php?%s' % (self.base_url, x[1]), 'get_torrent', self.thumb))
        self.menu.extend(l)
        self.menu.extend([('Căutare', self.base_url, 'cauta', self.searchimage)])
        self.search_url = "https://%s/browse.php?search=%s" % (self.base_url, '%s&cat=0&searchin=1&sort=5')

    def login(self):
        username = __settings__.getSetting("FLusername")
        password = __settings__.getSetting("FLpassword")
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
                   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                   'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3',
                   'Host': self.base_url}
        w, session = makeRequest('https://%s/login.php' % (self.base_url), name=self.__class__.__name__, headers=headers, savecookie=True)
        save_cookie(self.__class__.__name__, session)
        validator_match = re.findall("validator.*value='(.+?)'", w or '')
        validator = validator_match[0] if validator_match else ''
        if not (password and username):
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('FileList.ro', 'lipsa username si parola din setari')))
            return False
        data = {
            'validator': validator,
            'password': password,
            'username': username,
            'unlock': '1',
            'returnto': '/'
        }
        headers = {'Origin': 'https://' + self.base_url,
                   'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
                   'Referer': 'https://' + self.base_url + '/',
                   'X-Requested-With': 'XMLHttpRequest',
                   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                   'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3',
                   'Host': self.base_url}
        xbmc.sleep(1000)
        x, session = makeRequest('https://%s/takelogin.php' % (self.base_url), name=self.__class__.__name__, data=data, headers=headers, savecookie=True)
        if re.search('logout.php', x or ''):
            log('LOGGED FileListRO')
        elif re.search('Numarul maxim permis de actiuni a fost depasit', x or ''):
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('FileList.ro', u'Site in protectie, reincearca peste o ora')))
            clear_cookie(self.__class__.__name__)
        elif re.search('User sau parola gresite\.', x or ''):
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('FileList.ro', u'Parola/User gresite, verifica-le')))
            clear_cookie(self.__class__.__name__)
        else:
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('FileList.ro', u'Probleme la logare')))
            clear_cookie(self.__class__.__name__)
        xbmc.sleep(1000)
        save_cookie(self.__class__.__name__, session)
        try:
            cookiesitems = session.cookies.items()
        except Exception:
            cookiesitems = []
        for cookie, value in cookiesitems:
            if cookie == 'pass':
                return cookie + '=' + value
        return False

    
    def _api_list_movies(self, api_url, info=None, limit=50):
        """List movies using YTS API (stable, supports pagination)."""
        import json
        items = []
        # Always request a sensible page size from API
        try:
            lim = int(limit) if limit else 50
        except Exception:
            lim = 50
        if lim < 30:
            lim = 30
        # ensure limit param in url
        if 'limit=' not in api_url:
            api_url = api_url + ('&' if '?' in api_url else '?') + 'limit=%d' % lim
        data = fetchData(api_url)
        if not data:
            return items
        try:
            js = json.loads(data)
        except Exception:
            return items
        movies = js.get('data', {}).get('movies') or []
        for mv in movies:
            title = mv.get('title') or mv.get('title_english') or ''
            year = mv.get('year') or ''
            nume = '%s (%s)' % (title, year) if year else title
            legatura = mv.get('url') or ''
            imagine = mv.get('medium_cover_image') or mv.get('large_cover_image') or self.thumb
            infoa = info.copy() if isinstance(info, dict) else {}
            infoa.update({
                'title': title,
                'year': year,
                'rating': mv.get('rating'),
                'plot': mv.get('summary') or mv.get('description_full') or '',
                'genre': ', '.join(mv.get('genres') or []),
                'duration': mv.get('runtime'),
            })
            items.append({'nume': nume, 'legatura': legatura, 'imagine': imagine, 'switch': 'get_torrent_links', 'info': infoa})

        # Pagination: add Next if API says there is next page
        page = js.get('data', {}).get('page_number') or 1
        movie_count = js.get('data', {}).get('movie_count') or 0
        try:
            page = int(page)
        except Exception:
            page = 1
        # if there are more pages, offer Next
        if movie_count and lim:
            if page * lim < int(movie_count):
                next_page = page + 1
                # replace/add page param
                if 'page=' in api_url:
                    next_url = re.sub(r'page=\d+', 'page=%d' % next_page, api_url)
                else:
                    next_url = api_url + '&page=%d' % next_page
                items.append({'nume': 'Next', 'legatura': next_url, 'imagine': self.thumb, 'switch': 'recente', 'info': info or {}})
        return items

def parse_menu(self, url, meniu, info={}, torraction=None, limit=None):
        yescat = ['24', '15', '25', '6', '26', '20', '2', '3', '4', '19', '1', '27', '21', '23', '13', '12']
        lists = []
        imagine = ''
        if meniu in ('get_torrent', 'cauta', 'recente'):
            import unicodedata
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                count = 1
                response = makeRequest(url, name=self.__class__.__name__, headers=self.headers())
                if not self.check_login(response):
                    response = makeRequest(url, name=self.__class__.__name__, headers=self.headers())
                regex = r"<div class='torrentrow'>(.+?)</div></div>"
                regex_tr = r"php\?cat\=(\d+)'.*?alt\='(.*?)'.*?(?:.*?img src\='(.*?)')?.*?details.*?title\='(.*?)'.*?(?:.small'\>(.*?)\<.*?)?:.*?(?:href\=\"(snatch.*?usetoken.*?)\".*?)?\<a href\=\"(download\.php\?id\=.*?)\".*?small'\>(\d+\.\d+.*?)\</.*?(?:.*?(?:#[\d\w]+|table-cell;')\>([\d\.,]+)\<)?.*?(?:\<b\>|;'\>)([\d,\.]+)\<"
                if response:
                    for block in re.compile(regex, re.DOTALL).findall(response):
                        result = re.compile(regex_tr, re.DOTALL).findall(block)
                        if result:
                            for cat, catnume, imagine, nume, genre, legaturatoken, legatura, size, seeds, leechers in result:
                                nume = replaceHTMLCodes(nume)
                                nume = ('[COLOR blue]2XUPLOAD[/COLOR] ' if re.findall('doubleup.png', block) else '') + nume
                                nume = ('[COLOR royalblue]INTERNAL[/COLOR] ' if re.findall('internal.png', block) else '') + nume
                                nume = ('[COLOR lime]FREELEECH[/COLOR] ' if re.findall('freeleech.png', block) else '') + nume
                                nume = ('[COLOR lime]ROMANIAN[/COLOR] ' if re.findall('romanian.png', block) else '') + nume
                                legatura = 'https://%s/%s' % (self.base_url, legatura)
                                size = striphtml(size)
                                seeds = ''.join(str(seeds).split()) if seeds else '-1'
                                nume = '%s  [COLOR green]%s[/COLOR] (%s) [S/L: %s/%s] ' % (nume, catnume, size, seeds, leechers)
                                imagine = imagine or self.thumb
                                try:
                                    genre = ensure_str(genre)
                                except Exception:
                                    pass
                                size_fmt = formatsize(size)
                                info = {'Title': nume,
                                        'Plot': nume,
                                        'Genre': genre,
                                        'Size': size_fmt,
                                        'Label2': self.name,
                                        'Poster': imagine}
                                if not (seeds == '0' and not zeroseed):
                                    appender = {'nume': nume,
                                                'legatura': legatura,
                                                'imagine': imagine,
                                                'switch': 'torrent_links',
                                                'info': info}
                                    if '?search=' in url:
                                        if str(cat) in yescat:
                                            lists.append(appender)
                                    else:
                                        lists.append(appender)
                                    if limit:
                                        count += 1
                                        if count == int(limit):
                                            break
                        if limit and count == int(limit):
                            break
                    match = re.compile("'pager'.+?\&page=", re.IGNORECASE | re.DOTALL).findall(response)
                    if len(match) > 0:
                        if '&page=' in url:
                            new = re.compile(r'\&page\=(\d+)').findall(url)
                            nexturl = re.sub(r'\&page\=(\d+)', '&page=' + str(int(new[0]) + 1), url)
                        else:
                            nexturl = '%s%s' % (url, '&page=1')
                        lists.append({'nume': 'Next',
                                      'legatura': nexturl,
                                      'imagine': self.nextimage,
                                      'switch': 'get_torrent',
                                      'info': {}})
        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s%s' % (url, sortare)
                lists.append({'nume': nume,
                              'legatura': legatura,
                              'imagine': self.thumb,
                              'switch': 'get_torrent',
                              'info': info})
        elif meniu == 'torrent_links':
            turl = self.getTorrentFile(url)
            action = torraction if torraction else ''
            openTorrent({'Tmode': action, 'Turl': turl, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})

        return lists


class uindex(Torrent):
    def __init__(self):
        self.base_url = 'uindex.org'
        self.thumb = os.path.join(media, 'uindex.png')
        self.name = '[B]UIndex[/B]'
        self.search_url = "https://%s/search.php" % self.base_url
        self.menu = [('Recente', 'https://%s/browse.php' % self.base_url, 'recente', self.thumb), ('Căutare', self.base_url, 'cauta', self.searchimage)]

    def cauta(self, keyword, limit=None):
        clean_keyword = unquote(keyword)
        match_s_e = re.search(r'(.*?)\s+S(\d+)(?:E(\d+))?', clean_keyword, re.IGNORECASE)
        
        filter_data = {'mode': 'normal'}
        urls_to_scan = []
        
        if match_s_e:
            title = match_s_e.group(1).strip()
            season = match_s_e.group(2)
            episode = match_s_e.group(3)
            
            # Construim termeni de cautare specifici
            term_season = "%s S%s" % (title, season)
            
            if episode:
                # MODE D1: Sezon si Episod
                # STRATEGIA DUALA: Cautam si SxxExx, si Sxx (pentru pack-uri)
                term_episode = "%s S%sE%s" % (title, season, episode)
                
                url1 = "%s?search=%s&c=0&sort=seeders&order=DESC" % (self.search_url, quote_plus(term_episode))
                url2 = "%s?search=%s&c=0&sort=seeders&order=DESC" % (self.search_url, quote_plus(term_season))
                
                urls_to_scan = [url1, url2] # Ordinea conteaza, prioritate episodul
                
                filter_data = {
                    'mode': 'D1',
                    'season': int(season),
                    'target_ep': int(episode)
                }
            else:
                # MODE D2: Doar Sezon
                url = "%s?search=%s&c=0&sort=seeders&order=DESC" % (self.search_url, quote_plus(term_season))
                urls_to_scan = [url]
                
                filter_data = {
                    'mode': 'D2',
                    'season': int(season)
                }
        else:
            # Caz Normal (Film sau Cautare text simpla)
            url = "%s?search=%s&c=0&sort=seeders&order=DESC" % (self.search_url, quote_plus(clean_keyword))
            urls_to_scan = [url]
            filter_data = {'mode': 'normal'}

        # Injectam lista de URL-uri in info pentru a fi procesata de parse_menu
        info_with_data = {'_filter_data': filter_data, '_scan_urls': urls_to_scan}
        
        # URL-ul principal e doar de forma, munca se face pe lista _scan_urls
        return self.__class__.__name__, self.name, self.parse_menu(urls_to_scan[0], 'get_torrent', info=info_with_data, limit=None)

    def parse_menu(self, url, meniu, info={}, torraction=None, limit=None):
        lists = []
        # Ensure info is a dict (Core may pass a string)
        if isinstance(info, str):
            try:
                info = json.loads(info)
            except Exception:
                try:
                    info = ast.literal_eval(info)
                except Exception:
                    info = {}
        elif info is None:
            info = {}
        # Stable YTS API for Recente
        if meniu == 'recente' and isinstance(url, str) and 'yts.mx/api/v2/list_movies.json' in url:
            return self._api_list_movies(url, info=info, limit=50)
        imagine = self.thumb
        
        # Extragem datele injectate
        filter_data = info.get('_filter_data', {'mode': 'normal'}) if info else {'mode': 'normal'}
        scan_urls = info.get('_scan_urls', [url]) if info else [url]
        
        # Curatam info pentru a nu pasa date interne mai departe
        if info:
            info = info.copy()
            if '_filter_data' in info: del info['_filter_data']
            if '_scan_urls' in info: del info['_scan_urls']
        
        if meniu == 'cauta':
            from resources.Core import Core
            Core().searchSites({'landsearch': self.__class__.__name__})
            
        elif meniu == 'get_torrent' or meniu == 'recente':
            
            seen_magnets = set() # Pentru deduplicare
            count = 0
            
            # Iteram prin toate URL-urile de cautare (ex: S03E08 si apoi S03)
            for current_url in scan_urls:
                log('[UIndex] Fetching: %s' % current_url)
                link = fetchData(current_url, headers=self.headers())
                
                if not link: continue
                
                # Regex validat anterior
                regex = r"href='(magnet:\?xt=urn:btih:[^']+)'[^>]*>.*?href='/details\.php\?id=\d+'>([^<]+)</a>.*?<td[^>]*>([\d\.,]+\s*[KMGT]B)</td>.*?class='g'>(\d+)</span>.*?class='b'>(\d+)</span>"
                matches = re.findall(regex, link, re.DOTALL | re.IGNORECASE)
                
                if not matches:
                     regex_backup = r"href='/details\.php\?id=\d+'>([^<]+)</a>.*?href='(magnet:\?xt=urn:btih:[^']+)'[^>]*>.*?<td[^>]*>([\d\.,]+\s*[KMGT]B)</td>.*?class='g'>(\d+)</span>.*?class='b'>(\d+)</span>"
                     matches_inv = re.findall(regex_backup, link, re.DOTALL | re.IGNORECASE)
                     matches = [(m[1], m[0], m[2], m[3], m[4]) for m in matches_inv]

                log('[UIndex] Matches for current URL: %d' % len(matches))

                for magnet, nume_raw, size_raw, seeds, leechers in matches:
                    try:
                        # Deduplicare rapida pe baza magnet link
                        if magnet in seen_magnets:
                            continue
                            
                        nume_curat = striphtml(nume_raw).strip()
                        legatura = magnet.strip()
                        size = size_raw.strip()
                        
                        # --- FILTRARE ---
                        mode = filter_data.get('mode')
                        
                        # Detectie
                        s_match = re.search(r'(?i)S(\d+)', nume_curat)
                        e_match = re.search(r'(?i)E(\d+)', nume_curat)
                        
                        item_season = int(s_match.group(1)) if s_match else -1
                        item_episode = int(e_match.group(1)) if e_match else -1
                        
                        is_pack = (item_season != -1 and item_episode == -1)
                        is_episode = (item_season != -1 and item_episode != -1)

                        keep_item = True

                        if mode == 'D1':
                            target_s = filter_data.get('season')
                            target_e = filter_data.get('target_ep')
                            
                            # Sezon gresit?
                            if item_season != -1 and item_season != target_s:
                                keep_item = False
                            
                            # Daca e episod individual, trebuie sa fie cel cautat
                            elif is_episode and item_episode != target_e:
                                keep_item = False
                                
                            # Pack-urile (is_pack) trec, Episodul corect trece

                        elif mode == 'D2':
                            target_s = filter_data.get('season')
                            # Sezon gresit?
                            if item_season != -1 and item_season != target_s:
                                keep_item = False
                            # Daca e episod individual, il aruncam
                            elif is_episode:
                                keep_item = False

                        if keep_item and not (seeds == '0' and not zeroseed):
                            nume_pentru_lista = '%s [B][COLOR lime](%s)[/COLOR][/B] [B][COLOR ffc75453][S/L: %s/%s][/COLOR][/B]' % (nume_curat, size, seeds, leechers)
                            info_secundara = '[B][COLOR lime]Size: %s[/COLOR][/B]  [B][COLOR ffc75453]S/L: %s/%s[/COLOR][/B]' % (size, seeds, leechers)
                            
                            info_dict = {
                                'Title': nume_curat,
                                'Plot': nume_curat + '\n' + info_secundara,
                                'Size': formatsize(size),
                                'Label2': info_secundara,
                                'Poster': imagine
                            }
                            
                            # === MODIFICARE ANGELITTO: Propagare ID-uri catre Player ===
                            if info.get('tmdb_id'): info_dict['tmdb_id'] = info['tmdb_id']
                            if info.get('imdb_id'): info_dict['imdb_id'] = info['imdb_id']
                            # ===========================================================
                            
                            lists.append({
                                'nume': nume_pentru_lista,
                                'legatura': legatura,
                                'imagine': imagine,
                                'switch': 'torrent_links',
                                'info': info_dict
                            })
                            
                            seen_magnets.add(magnet) # Marcam ca vazut
                            count += 1
                            
                            # Verificare limita globala (pe toate cautarile)
                            if limit and int(limit) > 0 and count >= int(limit):
                                break
                                
                    except Exception as e:
                        continue
                
                # Daca am atins limita, nu mai facem urmatoarele cautari
                if limit and int(limit) > 0 and count >= int(limit):
                    break

            log('[UIndex] Total items added: %d' % len(lists))
        
        elif meniu == 'torrent_links':
            action = torraction if torraction else ''
            openTorrent({'Tmode':action, 'Turl': url, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists
        
        
class speedapp(Torrent):
    def __init__(self):
        self.base_url = 'speedapp.io'
        self.thumb = os.path.join(media, 'speedapp.png')
        self.name = '[B]SpeedApp[/B]'
        self.username = __settings__.getSetting("SPAusername")
        if not self.username:
            self.username = __settings__.getSetting("SFZusername")
        if not self.username:
            self.username = __settings__.getSetting("XZusername")
        self.password = __settings__.getSetting("SPApassword")
        if not self.password:
            self.password = __settings__.getSetting("SFZpassword")
        if not self.password:
            self.password = __settings__.getSetting("XZpassword")
        self.login_url = 'https://%s/login' % (self.base_url)
        self.search_url_base = 'https://%s/browse' % self.base_url

        self.sortare = [('După dată', ''),
                ('După mărime', 'sort=torrent.size&direction=desc'),
                ('După downloads', 'sort=torrent.timesCompleted&direction=desc'),
                ('După seederi', 'sort=torrent.seeders&direction=desc'),
                ('După leecheri', 'sort=torrent.leechers&direction=desc')]
        
        self.categorii = [('Anime/Hentai', '3'),
                ('Seriale HDTV', '43'),
                ('Seriale HDTV-Ro', '44'),
                ('Filme 3D', '61'),
                ('Filme 3d Ro', '62'),
                ('Filme BluRay', '17'),
                ('Filme BluRay-Ro', '24'),
                ('Filme DVD', '7'),
                ('Filme DVD-Ro', '2'),
                ('Filme HD', '8'),
                ('Filme HD-Ro', '29'),
                ('Filme Românești', '59'),
                ('Filme 4K(2160p)', '61'),
                ('Filme 4K-RO(2160p)', '57'),
                ('Movies Packs', '38'),
                ('Videoclipuri', '64'),
                ('Filme SD', '10'),
                ('Filme SD-Ro', '35'),
                ('Sport', '22'),
                ('Sport-Ro', '58'),
                ('Seriale TV', '45'),
                ('Seriale TV-Ro', '46'),
                ('TV Packs', '41'),
                ('TV Packs-Ro', '66'),
                ('Seriale Românești', '60'),
                ('Desene Animate', '62'),
                ('Documentare', '9'),
                ('Documentare-Ro', '63')]
        self.adult = [('XXX-Packs', '50'),
                ('XXX', '15'),
                ('XXX DVD', '47'),
                ('XXX HD', '48'),
                ('XXX-SD', '51')]
        self.menu = [('Recente', "https://%s/browse?page=1" % self.base_url, 'recente', self.thumb)]
        l = []
        for x in self.categorii:
            l.append((x[0], 'https://%s/browse?categories[0]=%s' % (self.base_url, x[1]), 'sortare', self.thumb))
        self.menu.extend(l)
        m = []
        for x in self.adult:
            m.append((x[0], 'https://%s/adult?categories[0]=%s' % (self.base_url, x[1]), 'sortare', self.thumb))
        self.menu.extend(m)
        self.menu.extend([('Toate(fără XXX)', 'https://%s/browse?categories[0]=38&categories[1]=10&categories[2]=35&categories[3]=8&categories[4]=29&categories[5]=7&categories[6]=2&categories[7]=17&categories[8]=24&categories[9]=59&categories[10]=57&categories[11]=61&categories[12]=41&categories[13]=66&categories[14]=45&categories[15]=46&categories[16]=43&categories[17]=44&categories[18]=60&categories[19]=62&categories[20]=3&categories[21]=64&categories[22]=22&categories[23]=58&categories[24]=9&categories[25]=63' % self.base_url, 'sortare', self.thumb)])
        self.menu.extend([('Căutare', self.base_url, 'cauta', self.searchimage)])

    def login(self):
        headers = {'Host': self.base_url,
                   'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
                   'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3'}
        y, session = makeRequest('https://%s/login' % (self.base_url), name=self.__class__.__name__, headers=headers, savecookie=True)
        save_cookie(self.__class__.__name__, session)
        token_match = re.search('_csrf_token.+?value="(.+?)"', y)
        if not token_match:
            return False
        token = token_match.group(1)
        
        data = {
            'password': self.password,
            'username': self.username,
            '_remember_me': 'on',
            '_csrf_token': token
        }
        log('Log-in  attempt')
        e = []
        try: cookiesitems = session.cookies.iteritems()
        except: cookiesitems = session.cookies.items()
        for i, j in cookiesitems:
            e.append('%s=%s' % (i, j))
        headers['Cookie'] = "; ".join(e)
        headers['Origin'] = 'https://' + self.base_url
        headers['Referer'] = 'https://' + self.base_url + '/login'
        xbmc.sleep(1000)
        x, session1 = makeRequest('https://%s/login' % (self.base_url), name=self.__class__.__name__, data=data, headers=headers, savecookie=True)
        if re.search('logout', x):
            log('LOGGED SpeedApp')
        if re.search('Invalid credentials', x):
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('SpeedApp Login Error', 'Parola/Username incorecte')))
            clear_cookie(self.__class__.__name__)
        save_cookie(self.__class__.__name__, session1)
        try: cookiesitems = session1.cookies.iteritems()
        except: cookiesitems = session1.cookies.items()
        for cookie, value in cookiesitems:
            return cookie + '=' + value
        return False

    def cauta(self, keyword, limit=None):
        clean_keyword = unquote(keyword)
        match_s_e = re.search(r'(.*?)\s+S(\d+)(?:E(\d+))?', clean_keyword, re.IGNORECASE)
        
        filter_data = {'mode': 'normal'}
        urls_to_scan = []
        
        base_query_params = "&submit=&sort=torrent.seeders&direction=desc&page=1"
        
        if match_s_e:
            title = match_s_e.group(1).strip()
            season = match_s_e.group(2)
            episode = match_s_e.group(3)
            
            term_season = "%s S%s" % (title, season)
            
            if episode:
                # MODE D1
                term_episode = "%s S%sE%s" % (title, season, episode)
                url1 = "%s?search=%s%s" % (self.search_url_base, quote_plus(term_episode), base_query_params)
                url2 = "%s?search=%s%s" % (self.search_url_base, quote_plus(term_season), base_query_params)
                urls_to_scan = [url1, url2]
                filter_data = {'mode': 'D1', 'season': int(season), 'target_ep': int(episode)}
            else:
                # MODE D2
                url = "%s?search=%s%s" % (self.search_url_base, quote_plus(term_season), base_query_params)
                urls_to_scan = [url]
                filter_data = {'mode': 'D2', 'season': int(season)}
        else:
            # Caz Normal
            url = "%s?search=%s%s" % (self.search_url_base, quote_plus(clean_keyword), base_query_params)
            urls_to_scan = [url]
            filter_data = {'mode': 'normal'}

        info_with_data = {'_filter_data': filter_data, '_scan_urls': urls_to_scan}
        
        # Fortam limit=None
        return self.__class__.__name__, self.name, self.parse_menu(urls_to_scan[0], 'get_torrent', info=info_with_data, limit=None)

    def parse_menu(self, url, meniu, info={}, torraction=None, limit=None):
        lists = []
        yescat = ['38', '10', '35', '8', '29', '7', '2', '17', '24', '59', '57', '61', '41', '66', '45', '46', '43', '44', '60', '62', '3', '64', '22', '58', '9', '63', '50', '51', '15', '47', '48']
        imagine = self.thumb
        
        filter_data = info.get('_filter_data', {'mode': 'normal'}) if info else {'mode': 'normal'}
        scan_urls = info.get('_scan_urls', [url]) if info else [url]
        
        if info:
            info = info.copy()
            if '_filter_data' in info: del info['_filter_data']
            if '_scan_urls' in info: del info['_scan_urls']
        
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                seen_magnets = set()
                count = 0
                
                for current_url in scan_urls:
                    log('[SpeedApp] Fetching: %s' % current_url)
                    response = makeRequest(current_url, name=self.__class__.__name__, headers=self.headers())
                    
                    if not self.check_login(response):
                        response = makeRequest(current_url, name=self.__class__.__name__, headers=self.headers())

                    if response:
                        blocks = response.split('<div class="row mr-0 ml-0 py-3">')
                        if len(blocks) > 1:
                            blocks = blocks[1:]
                        
                        for block_content in blocks:
                            try:
                                if 'href="/torrents/' not in block_content: continue

                                cat_match = re.search(r'href="/browse\?categories%5B0%5D=(\d+)"', block_content)
                                cat = cat_match.group(1) if cat_match else ''
                                
                                if cat not in yescat and meniu != 'cauta': continue

                                detalii_match = re.search(r'<a class="font-weight-bold" href="([^"]+)">(.+?)</a>', block_content, re.DOTALL)
                                if not detalii_match: continue
                                nume_brut = detalii_match.group(2)
                                nume = ensure_str(re.sub(r'</?mark>', '', nume_brut)).strip()
                                
                                download_match = re.search(r'href="(/torrents/[^"]+\.torrent)"', block_content)
                                if not download_match: continue
                                legatura = 'https://%s%s' % (self.base_url, download_match.group(1))
                                
                                if legatura in seen_magnets: continue
                                
                                # --- FILTRARE D1/D2 ---
                                mode = filter_data.get('mode')
                                s_match = re.search(r'(?i)S(\d+)', nume)
                                e_match = re.search(r'(?i)E(\d+)', nume)
                                item_season = int(s_match.group(1)) if s_match else -1
                                item_episode = int(e_match.group(1)) if e_match else -1
                                is_pack = (item_season != -1 and item_episode == -1)
                                is_episode = (item_season != -1 and item_episode != -1)
                                
                                keep_item = True

                                if mode == 'D1':
                                    target_s = filter_data.get('season')
                                    target_e = filter_data.get('target_ep')
                                    if item_season != -1 and item_season != target_s:
                                        keep_item = False
                                    elif is_episode and item_episode != target_e:
                                        keep_item = False
                                elif mode == 'D2':
                                    target_s = filter_data.get('season')
                                    if item_season != -1 and item_season != target_s:
                                        keep_item = False
                                    elif is_episode:
                                        keep_item = False

                                if not keep_item: continue

                                added_match = re.search(r'data-toggle="tooltip" title="([^"]+)"', block_content)
                                added = added_match.group(1).strip() if added_match else ''

                                size_match = re.search(r'(\d+[\.,]?\d*\s*[KMGT]B)', block_content)
                                size = size_match.group(1).strip() if size_match else 'N/A'

                                seeds_match = re.search(r'text-success.*?>(\d+)<', block_content)
                                seeds = seeds_match.group(1) if seeds_match else '0'
                                leech_match = re.search(r'text-danger.*?>(\d+)<', block_content)
                                leechers = leech_match.group(1) if leech_match else '0'
                                
                                if not (seeds == '0' and not zeroseed):
                                    seen_magnets.add(legatura)
                                    
                                    free = '[B][COLOR lime]FREE[/COLOR][/B] ' if 'title="Descarcarea acestui torrent este gratuita' in block_content else ''
                                    double = '[B][COLOR yellow]DoubleUP[/COLOR][/B] ' if 'title="Uploadul pe acest torrent se va contoriza dublu."' in block_content else ''
                                    promovat = '[B][COLOR lime]PROMOVAT[/COLOR][/B] ' if 'Acest torrent este promovat' in block_content else ''

                                    nume_afisat = '%s%s%s%s (%s) [S/L: %s/%s]' % (promovat, free, double, nume, size, seeds, leechers)
                                    plot = '%s\n\n[COLOR yellow]Adaugat: %s[/COLOR]\n[B][COLOR FF00FA9A](%s)[/COLOR][/B] [B][COLOR FFFF69B4][S/L: %s/%s][/COLOR][/B]' % (nume_afisat, added, size, seeds, leechers)
                                    
                                    info_dict = {
                                        'Title': nume_afisat,
                                        'Plot': plot,
                                        'Size': formatsize(size),
                                        'Poster': imagine
                                    }

                                    lists.append({
                                        'nume': nume_afisat,
                                        'legatura': legatura,
                                        'imagine': imagine,
                                        'switch': 'torrent_links',
                                        'info': info_dict
                                    })
                                    count += 1
                                    # AM ELIMINAT VERIFICAREA LIMIT DE AICI PENTRU A AFISA TOT
                            except Exception:
                                continue
                                
                    # Logica paginare doar pt browsare normala
                    if len(scan_urls) == 1 and 'search=' not in scan_urls[0]:
                        if 'page=' in current_url:
                            new_page_match = re.search('page=(\d+)', current_url)
                            if new_page_match:
                                current_page = int(new_page_match.group(1))
                                next_url = current_url.replace('page=%d' % current_page, 'page=%d' % (current_page + 1))
                                lists.append({
                                    'nume': 'Next',
                                    'legatura': next_url,
                                    'imagine': self.nextimage,
                                    'switch': 'get_torrent',
                                    'info': {}
                                })

        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s%s&page=1' % (url, (('&%s' % sortare) if sortare else ''))
                lists.append({'nume': nume,
                                'legatura': legatura,
                                'imagine': self.thumb,
                                'switch': 'get_torrent',
                                'info': info})
        elif meniu == 'torrent_links':
            turl = self.getTorrentFile(url)
            action = torraction if torraction else ''
            openTorrent({'Tmode': action, 'Turl': turl, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists
        
class yts(Torrent):
    def __init__(self):
        self.base_url = 'yts.bz'
        self.thumb = os.path.join(media, 'yts.png')
        self.name = '[B]YTS[/B]'
        self.search_url = "https://%s/browse-movies/%s/all/all/0/downloads/0/all" % (self.base_url, '%s')
        self.menu = [('Recente', 'https://yts.mx/api/v2/list_movies.json?sort_by=date_added&order_by=desc&limit=50&page=1', 'recente', self.thumb),
                ('Filme', "https://%s/browse-movies/0/all/all/0/" % self.base_url, 'sortare', self.thumb),
                ('Limba', "https://%s/browse-movies/0/all/all/0/latest/0/" % self.base_url, 'limba', self.thumb),
                ('Genuri', "https://%s/browse-movies/0/all/%s/0/", 'genre', self.thumb),
                ('Calitate', "https://%s/browse-movies/0/%s/all/0/", 'calitate', self.thumb),
                ('Căutare', self.base_url, 'cauta', self.searchimage)]

        self.sortare = [('Ultimele', 'latest'),
                ('Cele mai vechi', 'oldest'),
                ('Populare', 'featured'),
                ('După seederi', 'seeds'),
                ('După peers', 'peers'),
                ('După ani', 'year'),
                ('După aprecieri', 'likes'),
                ('După rating', 'rating'),
                ('Alfabetic', 'alphabetical'),
                ('După descărcări', 'downloads')]
        
        self.calitate = [('Toate', 'all'),
                ('720p', '720p'),
                ('1080p', '1080p'),
                ('4K', '2160p'),
                ('3D', '3D')]
        
        self.limba = [('English', 'en'),
                        ('Foreign', 'foreign'),
                        ('All', 'all'),
                        ('Japanese', 'ja'),
                        ('French', 'fr'),
                        ('Italian', 'it'),
                        ('German', 'de'),
                        ('Spanish', 'es'),
                        ('Chinese', 'zh'),
                        ('Hindi', 'hi'),
                        ('Cantonese', 'cn'),
                        ('Korean', 'ko'),
                        ('Russian', 'ru'),
                        ('Swedish', 'sv'),
                        ('Portuguese', 'pt'),
                        ('Polish', 'pl'),
                        ('Danish', 'da'),
                        ('Norwegian', 'no'),
                        ('Telugu', 'te'),
                        ('Thai', 'th'),
                        ('Dutch', 'nl'),
                        ('Czech', 'cs'),
                        ('Finnish', 'fi'),
                        ('Tamil', 'ta'),
                        ('Vietnamese', 'vi'),
                        ('Turkish', 'tr'),
                        ('Indonesian', 'id'),
                        ('Persian', 'fa'),
                        ('Greek', 'el'),
                        ('Arabic', 'ar'),
                        ('Hebrew', 'he'),
                        ('Hungarian', 'hu'),
                        ('Urdu', 'ur'),
                        ('Tagalog', 'tl'),
                        ('Malay', 'ms'),
                        ('Bangla', 'bn'),
                        ('Romanian', 'ro'),
                        ('Icelandic', 'is'),
                        ('Estonian', 'et'),
                        ('Catalan', 'ca'),
                        ('Malayalam', 'ml'),
                        ('Ukrainian', 'uk'),
                        ('Punjabi', 'pa'),
                        ('xx', 'xx'),
                        ('Serbian', 'sr'),
                        ('Afrikaans', 'af'),
                        ('Kannada', 'kn'),
                        ('Basque', 'eu'),
                        ('Slovak', 'sk'),
                        ('Tibetan', 'bo'),
                        ('Amharic', 'am'),
                        ('Galician', 'gl'),
                        ('Bosnian', 'bs'),
                        ('Latin', 'la'),
                        ('Mongolian', 'mn'),
                        ('Marathi', 'mr'),
                        ('Norwegian', 'nb'),
                        ('Latvian', 'lv'),
                        ('Pashto', 'ps'),
                        ('Southern', 'st'),
                        ('Inuktitut', 'iu'),
                        ('Somali', 'so'),
                        ('Wolof', 'wo'),
                        ('Azerbaijani', 'az'),
                        ('Swahili', 'sw'),
                        ('Abkhazian', 'ab'),
                        ('Haitian', 'ht'),
                        ('Serbo-Croatian', 'sh'),
                        ('Kyrgyz', 'ky'),
                        ('Akan', 'ak'),
                        ('Ossetic', 'os'),
                        ('Luxembourgish', 'lb'),
                        ('Georgian', 'ka'),
                        ('Maori', 'mi'),
                        ('Afar', 'aa'),
                        ('Irish', 'ga'),
                        ('Yiddish', 'yi'),
                        ('Khmer', 'km'),
                        ('Macedonian', 'mk')]
        
        self.genre = ['Action',
                'Adventure',
                'Animation',
                'Biography',
                'Comedy',
                'Crime',
                'Documentary',
                'Drama',
                'Family',
                'Fantasy',
                'Film-Noir',
                'Game-Show',
                'History',
                'Horror',
                'Music',
                'Musical',
                'Mystery',
                'News',
                'Reality-TV',
                'Romance',
                'Sci-Fi',
                'Sport',
                'Talk-Show',
                'Thriller',
                'War',
                'Western']

    def parse_menu(self, url, meniu, info={}, torraction=None, limit=None):
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'get_torrent' or meniu == 'cauta' or meniu == 'recente' or meniu == 'cautare':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            # BLOCUL "elif meniu == 'cautare':" A FOST ELIMINAT
            else:
                count = 1
                link = fetchData(url)
                if link:
                    infos = {}
                    regex = '''class="browse-movie-wrap(.+?)</div'''
                    regex_tr = '''href="(.+?)".+?src="(.+?)".+?rating">(.+?)</.+?h4>(.+?)<.+?title">(.+?)</a.+?year">(.+?)$'''
                    blocks = re.compile(regex, re.DOTALL).findall(link)
                    if blocks:
                        for block in blocks:
                            match=re.compile(regex_tr, re.DOTALL).findall(block)
                            if match:
                                for legatura, imagine, rating, genre, nume, an in match:
                                    nume = ensure_str(unescape(striphtml(nume))).strip()
                                    nume = '%s (%s)' % (nume, an)
                                    info = {'Title': nume,
                                            'Plot': '%s (%s) - [B][COLOR lime]%s[/COLOR][/B]  [B][COLOR ffc75453]Rating: %s[/COLOR][/B]' % (nume, an, genre, rating),
                                            'Poster': imagine,
                                            'Genre': genre,
                                            'Rating': rating,
                                            'Label2': genre,
                                            'Year': an}
                                    lists.append({'nume': nume,
                                                'legatura': legatura,
                                                'imagine': imagine,
                                                'switch': 'get_torrent_links', 
                                                'info': info})
                                    if limit:
                                        count += 1
                                        if count == int(limit):
                                            break
                            if limit:
                                if count == int(limit):
                                    break
                    match = re.compile('"tsc_pagination.+?\?page=', re.IGNORECASE | re.DOTALL).findall(link)
                    if len(match) > 0:
                        if '?page=' in url:
                            new = re.compile('\?page\=(\d+)').findall(url)
                            nexturl = re.sub('\?page\=(\d+)', '?page=' + str(int(new[0]) + 1), url)
                        else:
                            if '/?s=' in url:
                                nextpage = re.compile('\?s=(.+?)$').findall(url)
                                nexturl = '%s/page/2/?s=%s' % (self.base_url, nextpage[0])
                            else: 
                                nexturl = '%s%s' % (url, '?page=2')
                        lists.append({'nume': 'Next',
                                        'legatura': nexturl,
                                        'imagine': self.nextimage,
                                        'switch': 'get_torrent', 
                                        'info': {}})
        elif meniu == 'get_torrent_links':
            link = fetchData(url)
            lists = []
            # Regex-ul tÄƒu original, pe care È™tim cÄƒ funcÈ›ioneazÄƒ
            regex_baza = r'modal-torrent".+?quality.+?<span>(.+?)</span>.+?-size">(.+?)<.+?-size">(.+?)<.+?"(magnet.+?)"'
            
            try:
                info_baza = eval(str(info))
                nume_film = info_baza.get('Title')
                poster = info_baza.get('Poster', '')
            except: 
                info_baza = {}
                nume_film = ''
                poster = self.thumb
                
            # --- REGEX CORECTAT PENTRU SEEDERI/LEECHERI ---
            # CautÄƒ textul "Seeds" È™i apoi captureazÄƒ numÄƒrul de DUPÄ‚ tag
            all_seeds = re.findall(r'<span title="Seeds"[^>]*>Seeds</span>\s*([\d,]+)', link)
            all_leechers = re.findall(r'<span title="Leechers"[^>]*>Leechers</span>\s*([\d,]+)', link)
            
            matches = re.compile(regex_baza, re.DOTALL).findall(link)
            
            for i, (calitate, calitate2, size, legatura) in enumerate(matches):
                try:
                    # LuÄƒm seederii È™i leecherii din listele corecte
                    seeds = all_seeds[i].strip().replace(',', '') if i < len(all_seeds) else '0'
                    leechers = all_leechers[i].strip().replace(',', '') if i < len(all_leechers) else '0'
                    
                    size_curat = size.strip()
                    size_formatat = formatsize(size_curat)

                    # 1. Construim numele final È™i complet pentru listÄƒ
                    nume_torrent = '[B]%s %s[/B] (%s) [S/L: %s/%s] - %s' % (calitate.strip(), calitate2.strip(), size_curat, seeds, leechers, nume_film)
                    
                    # 2. CreÄƒm un dicÈ›ionar NOU cu informaÈ›iile TORRENTULUI (nu filmului)
                    info_torrent = {
                        'Title': nume_torrent,
                        'Plot': '%s\n\n[B]Quality:[/B] [B][COLOR lime]%s %s[/COLOR][/B]\n[B]Size:[/B] [B][COLOR fffdb515]%s[/COLOR][/B]\n[B]Seeds/Leechers:[/B] [B][COLOR ffc75453]%s/%s[/COLOR][/B]' % (nume_film, calitate.strip(), calitate2.strip(), size_curat, seeds, leechers),
                        'Size': size_formatat,
                        'Poster': poster
                    }
                    
                    lists.append({'nume': nume_torrent,
                                  'legatura': legatura,
                                  'imagine': poster,
                                  'switch': 'torrent_links', 
                                  'info': info_torrent})
                except:
                    continue
        elif meniu == 'calitate':
            for nume, calitate in self.calitate:
                legatura = url % (self.base_url, calitate)
                lists.append({'nume': nume,
                                'legatura': legatura,
                                'imagine': self.thumb,
                                'switch': 'sortare', 
                                'info': info})
        elif meniu == 'genre':
            for gen in self.genre:
                legatura = url % (self.base_url, gen.lower())
                lists.append({'nume': gen,
                                'legatura': legatura,
                                'imagine': self.thumb,
                                'switch': 'sortare', 
                                'info': info})
        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s%s/0/all' % (url, sortare)
                lists.append({'nume': nume,
                                'legatura': legatura,
                                'imagine': self.thumb,
                                'switch': 'get_torrent', 
                                'info': info})
        elif meniu == 'limba':
            for nume, limba in self.limba:
                legatura = '%s%s' % (url, limba)
                lists.append({'nume': nume,
                                'legatura': legatura,
                                'imagine': self.thumb,
                                'switch': 'get_torrent', 
                                'info': info})
        elif meniu == 'torrent_links':
            action = torraction if torraction else ''
            openTorrent({'Tmode':action, 'Turl': url, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})
            
        return lists        