# resource.images.moviegenreicons.arctic.zephyr
Video genre icons for Arctic Zephyr skin

Icons courtesy of iconfinder.com and iconmonstr.com.