# -*- coding: utf-8 -*-
from resources.functions import *

streamsites = ['asiafaninfo',
           'fsonlineto',
           'portalultautv',
           'voxfilmeonline']

streamnames = {'asiafaninfo': {'nume' : 'AsiaFanInfo', 'thumb': os.path.join(media,'asiafaninfo.jpg')},             
              'fsonlineto': {'nume': 'FSOnline2', 'thumb': os.path.join(media, 'fsonlineorg.jpg')},
              'portalultautv': {'nume': 'PortalulTauTv', 'thumb': os.path.join(media, 'portalultautv.jpg')},
              'voxfilmeonline': {'nume': 'VoxFilmeOnline', 'thumb': os.path.join(media, 'voxfilmeonline.jpg')}}


class asiafaninfo:
    base_url = 'http://www.asiafaninfo.net'
    thumb = os.path.join(media,'asiafaninfo.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'AsiaFanInfo.net'
    menu = [('Recente', base_url, 'recente', thumb), 
            ('Categorii', base_url, 'genuri', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
                

    def cauta(self, keyword, limit=None):
        return self.__class__.__name__, self.name, self.parse_menu(self.get_search_url(keyword), 'by_genre', limit=limit)
        
    def get_search_url(self, keyword):
        url = self.base_url + '/?s=' + quote(keyword)
        return url

    def parse_menu(self, url, meniu, info={}, limit=None):
        lists = []
        if meniu == 'recente':
            count =1
            link = fetchData(url)
            regex = '''<li>(?:<strong>)?<a href=['"](.+?)['"].+?>(.+?)</li'''
            match = re.findall(regex, link, re.IGNORECASE | re.DOTALL)
            if len(match) > 0:
                for legatura, nume in match:
                    nume = replaceHTMLCodes(striphtml(nume))
                    info = {'Title': nume,'Plot': nume,'Poster': self.thumb}
                    lists.append({'nume': nume,
                                    'legatura': legatura,
                                    'imagine': '',
                                    'switch': 'get_links', 
                                    'info': info})
                    if limit:
                        count += 1
                        if count == int(limit):
                            break
        elif meniu == 'get_links':
            link = fetchData(url)
            nume = ''
            regex_lnk = '''(?:((?:episodul|partea|sursa)[\s]\d+).+?)?<iframe.+?src=['"]((?:[htt]|[//]).+?)["']'''
            regex_seriale = '''(?:<h3>.+?strong>(.+?)<.+?href=['"](.+?)['"].+?)'''
            regex_infos = '''detay-a.+?description">(.+?)</div'''
            match_lnk = []
            #match_srl = re.compile(regex_seriale, re.IGNORECASE | re.DOTALL).findall(link)
            match_nfo = re.compile(regex_infos, re.IGNORECASE | re.DOTALL).findall(link)
            try:
                info = eval(str(info))
                info['Plot'] = (striphtml(match_nfo[0]).strip())
            except: pass
            content = ''
            for episod, content in re.findall('"collapseomatic ".+?(?:.+?>(episodul.+?)</)?(.+?)</li>', link, re.DOTALL | re.IGNORECASE):
                if episod:
                    lists.append({'nume': '[COLOR lime]%s[/COLOR]' % episod,
                                    'legatura': 'nolink',
                                    'imagine': '',
                                    'switch': 'nimic', 
                                    'info': {}})
                match_lnk = []
                if content:
                    for numes, host1 in re.findall('''(?:>(sursa.+?)</.+?)?(?:src|href)?=['"]((?:[htt]|[//]).+?)["']''', content, re.DOTALL | re.IGNORECASE):
                        match_lnk.append((numes, host1))
                    for host, link1 in get_links(match_lnk):
                        lists.append({'nume': host,
                                    'legatura': link1,
                                    'imagine': '',
                                    'switch': 'play', 
                                    'info': info,
                                    'landing': url})
            if not content:
                match2_lnk = re.findall(regex_lnk, link, re.IGNORECASE | re.DOTALL)
                for host, link1 in get_links(match2_lnk):
                    lists.append({'nume': host,
                                    'legatura': link1,
                                    'imagine': '',
                                    'switch': 'play', 
                                    'info': info,
                                    'landing': url})
        elif meniu == 'by_genre' or meniu == 'cauta':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else: 
                count = 1
                link = fetchData(url)
                regex_all = '''id="post-(.+?)</div>\s+</div>\s+</div>'''
                r_link = '''href=['"](.+?)['"].+?title.+?categ'''
                r_name = '''title.+?per.+?>(.+?)<.+?categ'''
                r_genre = '''category tag">(.+?)<'''
                r_autor = '''author">(.+?)<'''
                r_image = '''author".+?src="(.+?)"'''
                if link:
                    match = re.findall(regex_all, link, re.IGNORECASE | re.DOTALL)
                    for movie in match:
                        legatura = re.findall(r_link, movie, re.IGNORECASE | re.DOTALL)
                        if legatura:
                            legatura = legatura[0]
                            nume = re.findall(r_name, movie, re.IGNORECASE | re.DOTALL)[0]
                            try: gen = [', '.join(re.findall(r_genre, movie, re.IGNORECASE | re.DOTALL))]
                            except: gen = ''
                            try: autor = re.findall(r_autor, movie, re.IGNORECASE | re.DOTALL)[0]
                            except: autor = ''
                            try: imagine = re.findall(r_image, movie, re.IGNORECASE | re.DOTALL)[0]
                            except: imagine = self.thumb
                            nume = replaceHTMLCodes(striphtml(nume))
                            info = {'Title': nume,'Plot': '%s \nTraducator: %s' % (nume, autor),'Poster': imagine, 'Genre': gen}
                            lists.append({'nume': nume,
                                    'legatura': legatura,
                                    'imagine': imagine,
                                    'switch': 'get_links', 
                                    'info': info})
                            if limit:
                                count += 1
                                if count == int(limit):
                                    break
                    match = re.compile('"post-nav', re.IGNORECASE).findall(link)
                    if len(match) > 0:
                        if '/page/' in url:
                            new = re.compile('/page/(\d+)').findall(url)
                            nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                        else:
                            if '/?s=' in url:
                                nextpage = re.compile('\?s=(.+?)$').findall(url)
                                nexturl = '%s/page/2/?s=%s' % (self.base_url, nextpage[0])
                            else: 
                                nexturl = '%s%s' % (url, 'page/2/' if str(url).endswith('/') else '/page/2/')
                        lists.append({'nume': 'Next',
                                    'legatura': nexturl,
                                    'imagine': self.nextimage,
                                    'switch': meniu, 
                                    'info': {}})
        elif meniu == 'genuri':
            link = fetchData(url)
            regex_cat = '''class="cat-item.+?href=['"](.+?)['"][\s]?>(.+?)<'''
            if link:
                match = re.findall(regex_cat, link, re.IGNORECASE | re.DOTALL)
                if len(match) > 0:
                    for legatura, nume in match:
                        nume = replaceHTMLCodes(nume).capitalize()
                        lists.append({'nume': nume,
                                    'legatura': legatura.replace('"', ''),
                                    'imagine': '',
                                    'switch': 'by_genre', 
                                    'info': info})
        return lists

class portalultautv:
    base_url = 'https://portalultautv.biz/'
    thumb = os.path.join(media, 'portalultautv.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'PortalulTauTv.com'
    menu = [('Recente', base_url, 'recente', thumb), 
            ('Seriale', '%s/seriale-online-subtitrate-1/' % base_url, 'recente', thumb),
            ('Genuri', base_url, 'genuri', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
                

    def cauta(self, keyword, limit=None):
        return self.__class__.__name__, self.name, self.parse_menu(self.get_search_url(keyword), 'recente', limit=limit)
        
    def get_search_url(self, keyword):
        url = self.base_url + '/?s=' + quote(keyword)
        return url

    def parse_menu(self, url, meniu, info={}, limit=None):
        lists = []
        link = fetchData(url)
        if meniu == 'recente' or meniu == 'cauta':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else: 
                count = 1
                link = fetchData(url, self.base_url + '/')
                regex_menu = '''<article(.+?)</art'''
                regex_submenu = '''href=['"](.*?)['"](?:.*?title=['"](.*?)['"])?.*?src=['"](.*?)['"](?:.*?title=['"](.*?)['"])?'''
                if link:
                    for movie in re.compile(regex_menu,  re.DOTALL).findall(link):
                        match = re.compile(regex_submenu, re.DOTALL).findall(movie)
                        for legatura, nume, imagine, nume2 in match:
                            nume = nume or nume2
                            nume = replaceHTMLCodes(striphtml(nume))
                            info = {'Title': nume,'Plot': nume,'Poster': imagine}
                            lists.append({'nume': nume,
                                    'legatura': legatura,
                                    'imagine': imagine,
                                    'switch': 'get_links', 
                                    'info': info})
                            if limit:
                                count += 1
                                if count == int(limit):
                                    break
                        if limit:
                            if count == int(limit):
                                break
                    match = re.compile('navigation"', re.IGNORECASE).findall(link)
                    match2 = re.compile('"next page-numbers"', re.IGNORECASE).findall(link)
                    if len(match) > 0 or len(match2) > 0:
                        if '/page/' in url:
                            new = re.compile('/page/(\d+)').findall(url)
                            nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                        else:
                            if '/?s=' in url:
                                nextpage = re.compile('\?s=(.+?)$').findall(url)
                                nexturl = '%s%s?s=%s' % (self.base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                            else: nexturl = '%s/page/2' % url if not url.endswith('/') else '%spage/2' % url
                        #log(nexturl)
                        lists.append({'nume': 'Next',
                                    'legatura': nexturl,
                                    'imagine': self.nextimage,
                                    'switch': meniu, 
                                    'info': {}})
        elif meniu == 'get_links':
            link = fetchData(url)
            nume = ''
            regex_lnk = '''(?:type=[\'"]text/javascript["\']>(?:\s+)?str=['"](.+?)["']|(?:(S\d+E\d+).+?)?<iframe.+?src=['"]((?:[htt]|[//]).+?)["'])'''
            regex_seriale = '''(?:<h3>.+?strong>(.+?)<(.+?)hr />)'''
            regex_infos = '''sinopsis(.+?)<div'''
            regex_content = '''<article(.+?)</articl'''
            match_content = re.findall(regex_content, link, re.IGNORECASE | re.DOTALL)
            match_lnk = []
            #match_nfo = []
            #match_srl = []
            if len(match_content) > 0:
                match_lnk = re.compile(regex_lnk, re.IGNORECASE | re.DOTALL).findall(link)
                #match_nfo = re.compile(regex_infos, re.IGNORECASE | re.DOTALL).findall(link)
                #match_srl = re.compile(regex_seriale, re.IGNORECASE | re.DOTALL).findall(link)
            infos = eval(str(info))
            #try:
                #infos['Title'] = infos.get('Title').decode('unicode-escape')
                #infos['Plot'] = infos.get('Plot').decode('unicode-escape')
                #infos['Poster'] = infos.get('Poster').decode('unicode-escape')
            #except: pass
            #try:
                #if len(match_nfo) > 0:
                    #infos['Plot'] = htmlparser.HTMLParser().unescape(striphtml(match_nfo[0]).strip().decode('utf-8'))
            #except: pass
            titleorig = infos['Title']
            for numerotare, linknumerotare, linknumerotareunu in match_lnk:
                if not numerotare:
                    szep = re.findall('S(\d+)E(\d+)', linknumerotare, re.IGNORECASE | re.DOTALL)
                    if szep:
                        episod = linknumerotare
                        linknumerotare = linknumerotareunu
                        try:
                            if re.search('–|-|~', titleorig):
                                all_name = re.split(r'–|-|:|~', titleorig,1)
                                title = all_name[1]
                                title2 = all_name[0]
                            else: 
                                title = titleorig
                                title2 = ''
                            title, year = xbmc.getCleanMovieTitle(title)
                            title2, year2 = xbmc.getCleanMovieTitle(title2)
                            title = title if title else title2
                            year = year if year else year2
                            if year: infos['Year'] = year
                            if szep[0][1] and not szep[0][0]: infos['Season'] = '01'
                            else: infos['Season'] = str(szep[0][0])
                            infos['Episode'] = str(szep[0][1])
                            infos['TvShowTitle'] = title
                        except: pass
                else:
                    #log(unquote(numerotare.replace('@','%')))
                    numerotare = re.findall('<(?:iframe|script).+?src=[\'"]((?:[htt]|[//]).+?)["\']', unquote(numerotare.replace('@','%')), re.IGNORECASE | re.DOTALL)[0]
                    try:
                        if re.search('–|-|~', titleorig):
                            all_name = re.split(r'–|-|:|~', titleorig,1)
                            title = all_name[1]
                            title2 = all_name[0]
                        else: 
                            title = titleorig
                            title2 = ''
                        title, year = xbmc.getCleanMovieTitle(title)
                        title2, year2 = xbmc.getCleanMovieTitle(title2)
                        title = title if title else title2
                        year = year if year else year2
                        if year: infos['Year'] = year
                        infos['Title'] = title
                    except: pass
                    linknumerotare = numerotare
                #log(numerotare)
                try:
                    if not numerotare: host = episod
                    else: host = ''
                    #log(host)
                    for hosts, link1 in get_links([linknumerotare]):
                        lists.append({'nume': '%s %s' % (host, hosts),
                                    'legatura': link1,
                                    'imagine': '',
                                    'switch': 'play', 
                                    'info': str(infos),
                                    'landing': url})
                except:
                    for host, link1 in get_links([linknumerotareunu]):
                        lists.append({'nume': host,
                                    'legatura': link1,
                                    'imagine': '',
                                    'switch': 'play', 
                                    'info': str(infos),
                                    'landing': url})
        elif meniu == 'genuri':
            link = fetchData(url)
            regex_cats = '''Categorie-Gen(.+?)</div'''
            regex_cat = '''\s+href=["'](.*?)['"\s]>(.+?)<'''
            if link:
                for cat in re.compile(regex_cats, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link):
                    match = re.compile(regex_cat, re.DOTALL).findall(cat)
                    for legatura, nume in match:
                        lists.append({'nume': nume,
                                    'legatura': legatura.replace('"', ''),
                                    'imagine': '',
                                    'switch': 'recente', 
                                    'info': info})
        return lists

class voxfilmeonline:
    base_url = 'https://voxfilmeonline.biz'
    thumb = os.path.join(media, 'voxfilmeonline.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'VoxFilmeOnline'
    menu = [('Recente', base_url, 'recente', thumb), 
            ('Genuri', base_url, 'genuri', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
        
    def get_search_url(self, keyword):
        url = self.base_url + '/?s=' + quote(keyword)
        return url

    def getKey(self, item):
        return item[1]

    def cauta(self, keyword, limit=None):
        return self.__class__.__name__, self.name, self.parse_menu(self.get_search_url(keyword), 'recente', limit=limit)

    def parse_menu(self, url, meniu, info={}, limit=None):
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'recente' or meniu == 'cauta':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else: 
                count = 1
                link = fetchData(url)
                regex_menu = '''<article(.+?)</art'''
                regex_submenu = '''href="(.+?)".+?title">(.+?)<(?:.+?rating">(.+?)</div)?.+?src="(ht.+?)"'''
                if link:
                    for movie in re.compile(regex_menu, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link):
                        match = re.compile(regex_submenu, re.DOTALL).findall(movie)
                        for legatura, nume, descriere, imagine in match:
                            try:
                                nume = replaceHTMLCodes(striphtml(ensure_str(nume)))
                                descriere = replaceHTMLCodes(striphtml(ensure_str(descriere)))
                            except:
                                nume = striphtml(ensure_str(nume)).strip()
                                descriere = striphtml(ensure_str(descriere)).strip()
                            descriere = "-".join(descriere.split("\n"))
                            info = {'Title': nume,'Plot': descriere,'Poster': imagine}
                            lists.append({'nume': nume,
                                    'legatura': legatura,
                                    'imagine': imagine,
                                    'switch': 'get_links', 
                                    'info': info})
                            if limit:
                                count += 1
                                if count == int(limit):
                                    break
                        if limit:
                            if count == int(limit):
                                break
                    match = re.compile('pagination"', re.IGNORECASE).findall(link)
                    if len(match) > 0:
                        if '/page/' in url:
                            new = re.compile('/page/(\d+)').findall(url)
                            nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                        else:
                            if '/?s=' in url:
                                nextpage = re.compile('\?s=(.+?)$').findall(url)
                                nexturl = '%s%s?s=%s' % (self.base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                            else: nexturl = url + "/page/2"
                        lists.append({'nume': 'Next',
                                    'legatura': nexturl,
                                    'imagine': self.nextimage,
                                    'switch': meniu, 
                                    'info': {}})
        elif meniu == 'get_links':
            link = fetchData(url)
            links = []
            regex_lnk = '''<iframe.+?src="((?:[htt]|[//]).+?)"'''
            match_lnk = re.compile(regex_lnk, re.IGNORECASE | re.DOTALL).findall(link)
            try:
                match_lnk = list(set(match_lnk))
            except: pass
            for host, link1 in get_links(match_lnk):
                lists.append({'nume': host,
                                    'legatura': link1,
                                    'imagine': '',
                                    'switch': 'play', 
                                    'info': info,
                                    'landing': url})
        elif meniu == 'genuri':
            link = fetchData(url)
            regex_cats = '''cat\-item\-.+?href=['"](.+?)['"](?:\s+.+?">|>)?(.+?)</a'''
            if link:
                match = re.compile(regex_cats).findall(link)
                if len(match) >= 0:
                    for legatura, nume in sorted(match, key=self.getKey):
                        lists.append({'nume': nume,
                                    'legatura': legatura.replace('"',''),
                                    'imagine': '',
                                    'switch': 'recente', 
                                    'info': info})
        return lists

class fsonlineto:
    base_url = 'https://www3.fsonline.app/'
    thumb = os.path.join(media, 'fsonlineorg.jpg')
    nextimage = next_icon
    searchimage = search_icon
    name = 'FSOnline2'
    menu = [('Recente', base_url, 'recente', thumb),
            ('Filme', '%s/film/' % base_url, 'recente', thumb),
            ('Seriale', '%s/seriale/' % base_url, 'recente', thumb),
            ('Genuri', base_url, 'genuri', thumb),
            ('Căutare', base_url, 'cauta', searchimage)]
        
    def get_search_url(self, keyword):
        url = self.base_url + '/?s=' + quote(keyword)
        return url

    def getKey(self, item):
        return item[1]

    def cauta(self, keyword, limit=None):
        return self.__class__.__name__, self.name, self.parse_menu(self.get_search_url(keyword), 'recente', limit=limit)

    def parse_menu(self, url, meniu, info={}, limit=None):
        lists = []
        #log('link: ' + link)
        imagine = ''
        if meniu == 'recente' or meniu == 'cauta':
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else: 
                count = 1
                link = fetchData(url)
                regex_menu = '''<article(.+?)</art'''
                regex_submenu = '''(?:src="(ht.+?)".*?alt="(.*?)".*?(?:"quali.*?"|"tobeornot")>(.*?)<.*?href="(.*?)"|href="(.*?)".*?src="(.*?)".*?alt="(.*?)".*?"tobeornot">(.*?)<)'''
                if link:
                    for movie in re.compile(regex_menu, re.IGNORECASE | re.MULTILINE | re.DOTALL).findall(link):
                        match = re.compile(regex_submenu, re.DOTALL).findall(movie)
                        for movie in match:
                            imagine, nume, descriere, legatura, legatura1, imagine1, nume1, descriere1 = movie
                            imagine = imagine or imagine1
                            nume = nume or nume1
                            legatura = legatura or legatura1
                            descriere = descriere or descriere1
                            try:
                                nume = replaceHTMLCodes(striphtml(ensure_str(nume)))
                                descriere = replaceHTMLCodes(striphtml(ensure_str(descriere)))
                            except:
                                nume = striphtml(ensure_str(nume)).strip()
                                descriere = striphtml(ensure_str(descriere)).strip()
                            descriere = "-".join(descriere.split("\n"))
                            info = {'Title': nume,'Plot': descriere,'Poster': imagine}
                            if '/seriale/' in legatura:
                                switch = 'get_seasons'
                            else:
                                switch = 'get_links'
                            lists.append({'nume': nume,
                                    'legatura': legatura,
                                    'imagine': imagine,
                                    'switch': switch,
                                    'info': info})
                            if limit:
                                count += 1
                                if count == int(limit):
                                    break
                        if limit:
                            if count == int(limit):
                                break
                    match = re.compile('pagination"', re.IGNORECASE).findall(link)
                    if len(match) > 0:
                        if '/page/' in url:
                            new = re.compile('/page/(\d+)').findall(url)
                            nexturl = re.sub('/page/(\d+)', '/page/' + str(int(new[0]) + 1), url)
                        else:
                            if '/?s=' in url:
                                nextpage = re.compile('\?s=(.+?)$').findall(url)
                                nexturl = '%s%s?s=%s' % (self.base_url, ('page/2/' if str(url).endswith('/') else '/page/2/'), nextpage[0])
                            else: nexturl = url + "/page/2"
                        lists.append({'nume': 'Next',
                                    'legatura': nexturl,
                                    'imagine': self.nextimage,
                                    'switch': meniu, 
                                    'info': {}})
        elif meniu == 'get_links':
            link = fetchData(url)
            #log(link)
            links = []
            servers_lnk = []
            ids = '''movie\-id="(.*?)"'''
            regex_lnk = '''data-vs="((?:[htt]|[//]).+?)"'''
            match_ids = re.search(ids, link)
            if match_ids:
                ids_nr = match_ids.group(1)
            else:
                ids_nr = '0'
            data = {'action': 'lazy_player',
                        'movieID': ids_nr}
            post_link = '%s/wp-admin/admin-ajax.php' % self.base_url
            link = fetchData(post_link, data=data)
            headers = {'Referer': self.base_url}
            match_lnk = re.compile(regex_lnk, re.DOTALL).findall(link)
            if match_lnk:
                match_lnk = list(set(match_lnk))
                for server_link in match_lnk:
                    servers = requests.head(server_link, headers=headers)
                    server = servers.headers.get('Location')
                    servers_lnk.append(server)
            for host, link1 in get_links(servers_lnk):
                lists.append({'nume': host,
                                    'legatura': link1,
                                    'imagine': '',
                                    'switch': 'play', 
                                    'info': info,
                                    'landing': url})
        elif meniu == 'get_seasons':
            link = fetchData(url)
            regex_menu = '''<article class="item (?:season|episodes)"(.*?)</art'''
            regex_submenu = '''href="(.*?)".*?src="(.*?)".*?"data">(.*?)</div'''
            for sezon in re.compile(regex_menu, re.DOTALL).findall(link):
                match = re.findall(regex_submenu, sezon, re.DOTALL)
                if match:
                    for legatura, imagine, nume in match:
                        nume = striphtml(nume)
                        info = {'Title': nume,'Plot': nume,'Poster': imagine}
                        if '/sezonul/' in legatura:
                            switch = 'get_seasons'
                        else:
                            switch = 'get_links'
                        lists.append({'nume': nume,
                                        'legatura': legatura,
                                        'imagine': imagine,
                                        'switch': switch, 
                                        'info': info})
        elif meniu == 'genuri':
            link = fetchData(url)
            regex_container = '''Genuri.*?<ul(.*?)</ul'''
            regex_cats = '''href="(.*?)">(.*?)<'''
            if link:
                match_container = re.search(regex_container, link)
                if match_container:
                    match = re.findall(regex_cats, match_container.group(1))
                    for legatura, nume in sorted(match, key=self.getKey):
                        if '/seriale/' in legatura:
                            switch = 'get_seasons'
                        else:
                            switch = 'recente'
                        lists.append({'nume': nume,
                                    'legatura': legatura.replace('"',''),
                                    'imagine': '',
                                    'switch': switch, 
                                    'info': info})
        return lists