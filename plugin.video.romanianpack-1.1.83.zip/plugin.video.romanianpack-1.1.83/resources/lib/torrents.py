# -*- coding: utf-8 -*-
from resources.functions import *
import tempfile
import ssl
import hashlib
import pickle
import abc
import os
import re
import sys

# Ensure requests is available from the bundled path
try:
    from resources.lib import requests as requests
except Exception:
    import requests  # fallback if available

# quote for URL encoding (explicit import for Py3)
try:
    from urllib.parse import quote
except ImportError:
    from urllib import quote  # Py2 fallback (should not be used on modern Kodi)

__settings__ = xbmcaddon.Addon()
zeroseed = __settings__.getSetting("zeroseed") == 'true'

torrentsites = ['filelist']

torrnames = {
    'filelist': {'nume': 'FileList', 'thumb': os.path.join(media, 'filelist.png')}
}

def getKey(item):
    return item[1]

def save_cookie(name, session):
    cookie = os.path.join(dataPath, name + '.txt')
    with open(cookie, 'wb') as f:
        pickle.dump(session.cookies, f)

def load_cookie(name, session):
    cookie = os.path.join(dataPath, name + '.txt')
    if os.path.exists(cookie):
        try:
            with open(cookie, 'rb') as f:
                session.cookies.update(pickle.load(f))
        except:
            pass
    return session

def clear_cookie(name):
    cookie = os.path.join(dataPath, name + '.txt')
    if os.path.exists(cookie):
        os.remove(cookie)
        origin = torrnames.get(name, {}).get('nume', name)
        log('%s [clear_cookie]: cookie cleared' % origin)

def makeRequest(url, data=None, headers=None, name='', timeout=None, referer=None, rtype=None, savecookie=None, raw=None):
    """
    Wrapper over requests with addon timeout, UA, referer and cookie jar per tracker name.
    """
    from resources.lib.requests.packages.urllib3.exceptions import InsecureRequestWarning
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

    s = requests.Session()
    if name:
        s = load_cookie(name, s)

    timeout = timeout if timeout is not None else int(__settings__.getSetting('timeout') or 15)
    headers = (headers or {}).copy()
    if 'User-Agent' not in headers:
        headers['User-Agent'] = USERAGENT
    if referer is not None:
        headers['Referer'] = referer

    try:
        if data:
            resp = s.post(url, headers=headers, data=data, verify=False, timeout=timeout)
        else:
            resp = s.get(url, headers=headers, verify=False, timeout=timeout)

        if rtype == 'json':
            result = resp.json()
        else:
            if raw:
                result = resp.content
            else:
                try:
                    result = resp.content.decode('utf-8')
                except Exception:
                    result = resp.content.decode('latin-1')

        if savecookie:
            return (result if raw else (result if isinstance(result, str) else str(result)), s)
        else:
            return result if raw else (result if isinstance(result, str) else str(result))

    except BaseException as e:
        log('%s makeRequest(%s) exception: %s' % (name, url, str(e)))
        return

def tempdir():
    if py3:
        dirname = xbmcvfs.translatePath('special://temp')
    else:
        dirname = xbmc.translatePath('special://temp')
    for subdir in ('xbmcup', 'plugin.video.torrenter'):
        dirname = os.path.join(dirname, subdir)
        if not os.path.exists(dirname):
            os.mkdir(dirname)
    return dirname

def md5(string):
    hasher = hashlib.md5()
    hasher.update(string.encode('utf-8'))
    return hasher.hexdigest()

def saveTorrentFile(url, content):
    try:
        temp_dir = tempfile.gettempdir()
    except Exception:
        temp_dir = tempdir()
    localFileName = os.path.join(temp_dir, md5(url) + ".torrent")
    with open(localFileName, 'wb+') as localFile:
        localFile.write(content)
    return localFileName

def clear_title(s):
    return striphtml(unescape(s)).replace('   ', ' ').replace('  ', ' ').strip()

class Torrent(object, metaclass=abc.ABCMeta):
    nextimage = next_icon
    searchimage = search_icon

    base_url = ''
    thumb = ''
    name = ''
    username = ''
    password = ''
    search_url = ''
    login_url = ''
    login_data = {}
    login_referer = login_url
    url_referer = ''
    url_host = ''

    def headers(self):
        self.url_referer = self.url_referer or 'https://%s/' % self.base_url
        self.url_host = self.url_host or self.base_url
        headers = {
            'Host': self.url_host,
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
            'Referer': self.url_referer,
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
        }
        return headers

    def cauta(self, keyword, replace=False, limit=None):
        url = self.search_url % (keyword.replace(" ", "-") if replace else quote(keyword))
        return self.__class__.__name__, self.name, self.parse_menu(url, 'get_torrent', limit=limit)

    def login(self):
        log('Log-in  attempt')
        self.login_headers = {
            'Host': self.base_url,
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
            'Referer': self.login_url,
            'X-Requested-With': 'XMLHttpRequest',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3'
        }
        x, session = makeRequest(self.login_url,
                                 name=self.__class__.__name__,
                                 data=self.login_data,
                                 headers=self.login_headers,
                                 savecookie=True)
        if re.search('logout.php|account-details.php', x or ''):
            log('LOGGED %s' % self.name)
        if re.search('incorrect.+?try again|Username or password incorrect', x or '', re.IGNORECASE):
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('%s Login Error' % self.name, 'Parola/Username incorecte')))
            clear_cookie(self.__class__.__name__)
        save_cookie(self.__class__.__name__, session)
        try:
            cookiesitems = session.cookies.items()
        except Exception:
            cookiesitems = []
        for cookie, value in cookiesitems:
            if cookie in ('pass', 'uid', 'username'):
                return cookie + '=' + value
        return False

    def check_login(self, response=None):
        if response:
            response = str(response)
            if re.compile('<input.+?type="password"|<title> FileList :: Login </title>|Not logged in|/register">Sign up now|account-login.php').search(response):
                log('%s Not logged!' % self.name)
                clear_cookie(self.__class__.__name__)
                self.login()
                return False
            if re.search('incorrect.+?try again|Username or password incorrect|Access Denied', response, re.IGNORECASE):
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('%s Login Error' % self.name, 'Parola/Username incorecte')))
                clear_cookie(self.__class__.__name__)
            return True
        return False

    def getTorrentFile(self, url):
        content = makeRequest(url, name=self.__class__.__name__, headers=self.headers(), raw='1')
        if not self.check_login(content):
            content = makeRequest(url, name=self.__class__.__name__, headers=self.headers(), raw='1')
        if re.search("<html", str(content)):
            msg = re.search('Username or password incorrect|User sau parola gresite|Numele de utilizator nu a fost|Date de autentificare invalide', str(content))
            if msg:
                xbmc.executebuiltin((u'Notification(%s,%s)' % ('%s Login Error' % self.name, 'Parola/Username incorecte')))
            xbmc.sleep(4000)
            sys.exit(1)
        return saveTorrentFile(url, content)

class filelist(Torrent):
    def __init__(self):
        self.base_url = 'filelist.io'
        self.thumb = os.path.join(media, 'filelist.png')
        self.name = 'FileList'

        self.sortare = [('Hibrid', '&sort=0'),
                        ('Relevanță', '&sort=1'),
                        ('După dată', '&sort=2'),
                        ('După mărime', '&sort=3'),
                        ('După downloads', '&sort=4'),
                        ('După peers', '&sort=5')]

        self.token = '&usetoken=1'

        self.categorii = [('Anime', 'cat=24'),
                          ('Desene', 'cat=15'),
                          ('Filme 3D', 'cat=25'),
                          ('Filme 4k', 'cat=6'),
                          ('Filme 4k Blu-Ray', 'cat=26'),
                          ('Filme Blu-Ray', 'cat=20'),
                          ('Filme DVD', 'cat=2'),
                          ('Filme DVD-RO', 'cat=3'),
                          ('Filme HD', 'cat=4'),
                          ('Filme HD-RO', 'cat=19'),
                          ('Filme SD', 'cat=1'),
                          ('Seriale 4k', 'cat=27'),
                          ('Seriale HD', 'cat=21'),
                          ('Seriale SD', 'cat=23'),
                          ('Sport', 'cat=13'),
                          ('Videoclip', 'cat=12'),
                          ('XXX', 'cat=7')]
        self.menu = [('Recente', "https://%s/browse.php?cats[]=24&cats[]=15&cats[]=25&cats[]=6&cats[]=26&cats[]=20&cats[]=2&cats[]=3&cats[]=4&cats[]=19&cats[]=1&cats[]=27&cats[]=21&cats[]=23&cats[]=13&cats[]=12&incldead=0" % self.base_url, 'recente', self.thumb)]
        l = []
        for x in self.categorii:
            l.append((x[0], 'https://%s/browse.php?%s' % (self.base_url, x[1]), 'get_torrent', self.thumb))
        self.menu.extend(l)
        self.menu.extend([('Căutare', self.base_url, 'cauta', self.searchimage)])
        self.search_url = "https://%s/browse.php?search=%s" % (self.base_url, '%s&cat=0&searchin=1&sort=5')

    def login(self):
        username = __settings__.getSetting("FLusername")
        password = __settings__.getSetting("FLpassword")
        headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
                   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                   'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3',
                   'Host': self.base_url}
        w, session = makeRequest('https://%s/login.php' % (self.base_url), name=self.__class__.__name__, headers=headers, savecookie=True)
        save_cookie(self.__class__.__name__, session)
        validator_match = re.findall("validator.*value='(.+?)'", w or '')
        validator = validator_match[0] if validator_match else ''
        if not (password and username):
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('FileList.ro', 'lipsa username si parola din setari')))
            return False
        data = {
            'validator': validator,
            'password': password,
            'username': username,
            'unlock': '1',
            'returnto': '/'
        }
        headers = {'Origin': 'https://' + self.base_url,
                   'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; rv:70.1) Gecko/20100101 Firefox/70.1',
                   'Referer': 'https://' + self.base_url + '/',
                   'X-Requested-With': 'XMLHttpRequest',
                   'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                   'Accept-Language': 'ro,en-US;q=0.7,en;q=0.3',
                   'Host': self.base_url}
        xbmc.sleep(1000)
        x, session = makeRequest('https://%s/takelogin.php' % (self.base_url), name=self.__class__.__name__, data=data, headers=headers, savecookie=True)
        if re.search('logout.php', x or ''):
            log('LOGGED FileListRO')
        elif re.search('Numarul maxim permis de actiuni a fost depasit', x or ''):
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('FileList.ro', u'Site in protectie, reincearca peste o ora')))
            clear_cookie(self.__class__.__name__)
        elif re.search('User sau parola gresite\.', x or ''):
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('FileList.ro', u'Parola/User gresite, verifica-le')))
            clear_cookie(self.__class__.__name__)
        else:
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('FileList.ro', u'Probleme la logare')))
            clear_cookie(self.__class__.__name__)
        xbmc.sleep(1000)
        save_cookie(self.__class__.__name__, session)
        try:
            cookiesitems = session.cookies.items()
        except Exception:
            cookiesitems = []
        for cookie, value in cookiesitems:
            if cookie == 'pass':
                return cookie + '=' + value
        return False

    def parse_menu(self, url, meniu, info={}, torraction=None, limit=None):
        yescat = ['24', '15', '25', '6', '26', '20', '2', '3', '4', '19', '1', '27', '21', '23', '13', '12']
        lists = []
        imagine = ''
        if meniu in ('get_torrent', 'cauta', 'recente'):
            import unicodedata
            if meniu == 'cauta':
                from resources.Core import Core
                Core().searchSites({'landsearch': self.__class__.__name__})
            else:
                count = 1
                response = makeRequest(url, name=self.__class__.__name__, headers=self.headers())
                if not self.check_login(response):
                    response = makeRequest(url, name=self.__class__.__name__, headers=self.headers())
                regex = r"<div class='torrentrow'>(.+?)</div></div>"
                regex_tr = r"php\?cat\=(\d+)'.*?alt\='(.*?)'.*?(?:.*?img src\='(.*?)')?.*?details.*?title\='(.*?)'.*?(?:.small'\>(.*?)\<.*?)?:.*?(?:href\=\"(snatch.*?usetoken.*?)\".*?)?\<a href\=\"(download\.php\?id\=.*?)\".*?small'\>(\d+\.\d+.*?)\</.*?(?:.*?(?:#[\d\w]+|table-cell;')\>([\d\.,]+)\<)?.*?(?:\<b\>|;'\>)([\d,\.]+)\<"
                if response:
                    for block in re.compile(regex, re.DOTALL).findall(response):
                        result = re.compile(regex_tr, re.DOTALL).findall(block)
                        if result:
                            for cat, catnume, imagine, nume, genre, legaturatoken, legatura, size, seeds, leechers in result:
                                nume = replaceHTMLCodes(nume)
                                nume = ('[COLOR blue]2XUPLOAD[/COLOR] ' if re.findall('doubleup.png', block) else '') + nume
                                nume = ('[COLOR royalblue]INTERNAL[/COLOR] ' if re.findall('internal.png', block) else '') + nume
                                nume = ('[COLOR lime]FREELEECH[/COLOR] ' if re.findall('freeleech.png', block) else '') + nume
                                nume = ('[COLOR lime]ROMANIAN[/COLOR] ' if re.findall('romanian.png', block) else '') + nume
                                legatura = 'https://%s/%s' % (self.base_url, legatura)
                                size = striphtml(size)
                                seeds = ''.join(str(seeds).split()) if seeds else '-1'
                                nume = '%s  [COLOR green]%s[/COLOR] (%s) [S/L: %s/%s] ' % (nume, catnume, size, seeds, leechers)
                                imagine = imagine or self.thumb
                                try:
                                    genre = ensure_str(genre)
                                except Exception:
                                    pass
                                size_fmt = formatsize(size)
                                info = {'Title': nume,
                                        'Plot': nume,
                                        'Genre': genre,
                                        'Size': size_fmt,
                                        'Label2': self.name,
                                        'Poster': imagine}
                                if not (seeds == '0' and not zeroseed):
                                    appender = {'nume': nume,
                                                'legatura': legatura,
                                                'imagine': imagine,
                                                'switch': 'torrent_links',
                                                'info': info}
                                    if '?search=' in url:
                                        if str(cat) in yescat:
                                            lists.append(appender)
                                    else:
                                        lists.append(appender)
                                    if limit:
                                        count += 1
                                        if count == int(limit):
                                            break
                        if limit and count == int(limit):
                            break
                    match = re.compile("'pager'.+?\&page=", re.IGNORECASE | re.DOTALL).findall(response)
                    if len(match) > 0:
                        if '&page=' in url:
                            new = re.compile(r'\&page\=(\d+)').findall(url)
                            nexturl = re.sub(r'\&page\=(\d+)', '&page=' + str(int(new[0]) + 1), url)
                        else:
                            nexturl = '%s%s' % (url, '&page=1')
                        lists.append({'nume': 'Next',
                                      'legatura': nexturl,
                                      'imagine': self.nextimage,
                                      'switch': 'get_torrent',
                                      'info': {}})
        elif meniu == 'sortare':
            for nume, sortare in self.sortare:
                legatura = '%s%s' % (url, sortare)
                lists.append({'nume': nume,
                              'legatura': legatura,
                              'imagine': self.thumb,
                              'switch': 'get_torrent',
                              'info': info})
        elif meniu == 'torrent_links':
            turl = self.getTorrentFile(url)
            action = torraction if torraction else ''
            openTorrent({'Tmode': action, 'Turl': turl, 'Tsite': self.__class__.__name__, 'info': info, 'orig_url': url})

        return lists
