# modules/utils.py — shared helper functions

import os
import xbmcgui
import xbmcvfs

CHUNK_SIZE = 1024 * 128  # 128 KB

def _join_path(folder, name):
    if folder.endswith('/'):
        return folder + name
    return folder + '/' + name

def get_download_folder():
    """
    Returns the correct download folder depending on settings.
    For now: always let user pick device filesystem folder.
    """
    return xbmcgui.Dialog().browse(
        0, "Select folder to save ZIP (device filesystem)",
        "files", "", False, True, ""
    )

def copy_vfs(src_path, dst_path):
    """Copy using xbmcvfs, fallback to stream copy for safety."""
    try:
        if xbmcvfs.copy(src_path, dst_path):
            return True
    except Exception:
        pass
    try:
        src_f = xbmcvfs.File(src_path, 'rb')
        dst_f = xbmcvfs.File(dst_path, 'wb')
        while True:
            chunk = src_f.read(CHUNK_SIZE)
            if not chunk:
                break
            dst_f.write(chunk)
        src_f.close()
        dst_f.close()
        return True
    except Exception:
        return False
