# modules/diamond_slick.py
# Automates moving Kodi's data folder to an unrestricted location on Android
# Implements the Diamond/Slick Solution (with Android 11+ SAF fallback)

import os
import xbmc
import xbmcgui
import xbmcvfs
from modules import path_helper, saf_picker

NEW_ROOT = "/storage/emulated/0/Kodi/"
NEW_ROOT2 = "/storage/emulated/0/Kodi/.kodi"
PROPS_FILE = "/storage/emulated/0/xbmc_env.properties"


def move_to_unrestricted():
    dialog = xbmcgui.Dialog()

    # Confirm
    confirm = dialog.yesno(
        "Diamond/Slick Solution",
        "This will reconfigure Kodi to use:\n\n[COLOR yellow]%s[/COLOR]\n\n"
        "Your existing userdata can optionally be copied here.\n\n"
        "Kodi must be restarted afterwards.\n\n"
        "Do you want to continue?" % NEW_ROOT
    )
    if not confirm:
        return

    # Step 1: Ensure new root exists
    new_root = NEW_ROOT
    if not xbmcvfs.exists(new_root):
        try:
            xbmcvfs.mkdirs(new_root)
        except Exception:
            # SAF fallback
            dialog.ok(
                "Diamond/Slick Solution",
                "Direct access to internal storage failed.\n\n"
                "Please choose a folder using Android’s storage picker."
            )
            new_root = saf_picker.pick_folder("Choose folder for Kodi data")
            if not new_root:
                return

    # Step 1b: Ensure new root2 (.kodi) exists
    new_root2 = NEW_ROOT2
    if not xbmcvfs.exists(new_root2):
        try:
            xbmcvfs.mkdirs(new_root2)
        except Exception:
            # SAF fallback
            dialog.ok(
                "Diamond/Slick Solution",
                "Direct access to internal storage failed.\n\n"
                "Please choose a folder using Android’s storage picker."
            )
            new_root2 = saf_picker.pick_folder("Choose folder for Kodi data")
            if not new_root2:
                return

    # Step 2: Write xbmc_env.properties (point at .kodi)
    try:
        props_path = (
            xbmcvfs.translatePath(PROPS_FILE)
            if not PROPS_FILE.startswith("saf://")
            else PROPS_FILE
        )
        with open(props_path, "w", encoding="utf-8") as f:
            f.write(f"xbmc.data={new_root}\n")
    except Exception as e:
        dialog.ok("Diamond/Slick Solution", f"Failed to write xbmc_env.properties:\n{e}")
        return

    # Step 3a: Offer to copy userdata
    copy_now = dialog.yesno(
        "Diamond/Slick Solution",
        "Do you want to copy your current Kodi userdata to the new location?\n\n"
        "This will overlay files without deleting anything."
    )
    if copy_now:
        old_userdata = path_helper.userdata_path()
        new_userdata = os.path.join(new_root2, "userdata")

        try:
            _copy_directory(old_userdata, new_userdata)
            dialog.notification("Diamond/Slick Solution", "Userdata copied successfully", "")
        except Exception as e:
            dialog.ok("Diamond/Slick Solution", f"Failed to copy userdata:\n{e}")

    # Step 3b: Offer to copy addons
    copy_now2 = dialog.yesno(
        "Diamond/Slick Solution",
        "Do you want to copy your current Kodi add-ons to the new location?\n\n"
        "This will overlay files without deleting anything."
    )
    if copy_now2:
        old_addons = path_helper.addons_path()
        new_addons = os.path.join(new_root2, "addons")

        try:
            _copy_directory(old_addons, new_addons)
            dialog.notification("Diamond/Slick Solution", "Add-ons copied successfully", "")
        except Exception as e:
            dialog.ok("Diamond/Slick Solution", f"Failed to copy add-ons:\n{e}")

    # Step 4: Final message
    dialog.ok(
        "Diamond/Slick Solution",
        "Setup complete!\n\nKodi is now configured to use:\n[COLOR green]%s[/COLOR]\n\n"
        "Please [B]restart Kodi[/B] for changes to take effect." % new_root2
    )


def _copy_directory(src_folder, dst_folder):
    """Recursively copy directory using Kodi’s VFS system."""
    if not xbmcvfs.exists(dst_folder):
        xbmcvfs.mkdirs(dst_folder)

    dirs, files = xbmcvfs.listdir(src_folder)

    for f in files:
        src = os.path.join(src_folder, f)
        dst = os.path.join(dst_folder, f)
        try:
            xbmcvfs.copy(src, dst)
        except Exception:
            xbmc.log(f"[DiamondSlick] Failed to copy {src}", xbmc.LOGWARNING)

    for d in dirs:
        _copy_directory(os.path.join(src_folder, d), os.path.join(dst_folder, d))
