# modules/repo_builder.py
# Build a Kodi repository from a chosen folder:
# - Zips each add-on subfolder (with addon.xml) into zips/<id>/<id>-<version>.zip
# - Generates zips/addons.xml and zips/addons.xml.md5
# - Optionally pull in installed add-ons via Kodi JSON-RPC (multi-select)
# - (Optional) create a minimal "repository.<id>/" add-on if missing

import os
import re
import hashlib
import shutil
import zipfile
import json
import xbmc
import xbmcgui
import xbmcvfs

# ---- simple helpers ---------------------------------------------------------

def _translate(p):
    try:
        return xbmcvfs.translatePath(p)
    except Exception:
        return p

def _is_saf(p: str) -> bool:
    return isinstance(p, str) and p.startswith("saf://")

def _mkdirs(real_path):
    os.makedirs(real_path, exist_ok=True)

def _read_text(real_path):
    with open(real_path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()

def _write_text(real_path, text):
    _mkdirs(os.path.dirname(real_path))
    with open(real_path, "w", encoding="utf-8", errors="ignore") as f:
        f.write(text)

def _md5_bytes(b: bytes) -> str:
    m = hashlib.md5()
    m.update(b)
    return m.hexdigest()

def _notify(msg):
    xbmcgui.Dialog().notification("Repo Builder", msg, xbmcgui.NOTIFICATION_INFO, 3500)

# ---- JSON-RPC: list installed add-ons --------------------------------------

def _get_installed_addons():
    try:
        resp = xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0",
            "method": "Addons.GetAddons",
            "params": {"properties": ["name", "version", "enabled"]},
            "id": 1
        }))
        data = json.loads(resp)
        return data.get("result", {}).get("addons", [])
    except Exception:
        return []

def _pick_installed_addons():
    addons = _get_installed_addons()
    if not addons:
        xbmcgui.Dialog().ok("Repo Builder", "Couldn’t fetch installed add-ons.")
        return []

    skip_prefixes = {"metadata.", "service.xbmc.versioncheck"}
    filtered = [a for a in addons if not any(a["addonid"].startswith(p) for p in skip_prefixes)]

    labels = [f"{a['name']}  [{a['addonid']}]  v{a.get('version','?')}" for a in filtered]
    ids = [a["addonid"] for a in filtered]

    sel = xbmcgui.Dialog().multiselect("Select installed add-ons to include", labels)
    if sel is None:
        return []
    return [ids[i] for i in sel]

# ---- addon.xml parsing ------------------------------------------------------

def _parse_addon_id_and_version(addon_xml_text: str):
    m = re.search(r'<addon[^>]*\bid\s*=\s*"([^"]+)"', addon_xml_text, re.I)
    n = re.search(r'<addon[^>]*\bversion\s*=\s*"([^"]+)"', addon_xml_text, re.I)
    return (m.group(1).strip() if m else None, n.group(1).strip() if n else None)

# ---- SAF fallback -----------------------------------------------------------

def _ensure_real_repo_root(repo_vfs_root: str) -> str:
    real = _translate(repo_vfs_root)
    if _is_saf(repo_vfs_root) or real.startswith("saf://"):
        xbmcgui.Dialog().ok(
            "Repo Builder",
            "The selected folder uses Android SAF.\n\n"
            "Please choose a normal device path (e.g. /storage/emulated/0/YourFolder)."
        )
        return ""
    return real

# ---- zip one add-on folder --------------------------------------------------

def _zip_addon_folder(addon_folder_real: str, zips_root_real: str, excludes_ext=None):
    if excludes_ext is None:
        excludes_ext = {".pyo", ".pyc", ".log", ".md", ".txt", ".zip"}

    addon_xml_path = os.path.join(addon_folder_real, "addon.xml")
    if not os.path.isfile(addon_xml_path):
        return None, None, None

    addon_xml = _read_text(addon_xml_path)
    addon_id, version = _parse_addon_id_and_version(addon_xml)
    if not addon_id or not version:
        return None, None, None

    out_dir = os.path.join(zips_root_real, addon_id)
    _mkdirs(out_dir)
    out_zip = os.path.join(out_dir, f"{addon_id}-{version}.zip")

    # ✅ FIX: force archive root to addon_id only (not addon_id-version)
    with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(addon_folder_real):
            for f in files:
                ext = os.path.splitext(f)[1].lower()
                if ext in excludes_ext:
                    continue
                abs_path = os.path.join(root, f)
                rel_path = os.path.relpath(abs_path, addon_folder_real)
                arcname = os.path.join(addon_id, rel_path)  # force folder = addon_id
                zf.write(abs_path, arcname)

    shutil.copy2(addon_xml_path, os.path.join(out_dir, "addon.xml"))
    for img in ("icon.png", "icon.jpg", "fanart.jpg", "fanart.png"):
        p = os.path.join(addon_folder_real, img)
        if os.path.isfile(p):
            shutil.copy2(p, os.path.join(out_dir, os.path.basename(p)))
            break

    return addon_id, version, addon_xml

# ---- build addons.xml + md5 -------------------------------------------------

def _build_addons_xml(collected_addon_xml_texts):
    parts = ['<?xml version="1.0" encoding="UTF-8"?>', "<addons>"]
    for txt in collected_addon_xml_texts:
        cleaned = re.sub(r'^\s*<\?xml[^>]*\?>', "", txt.strip())
        parts.append(cleaned)
    parts.append("</addons>\n")
    return "\n".join(parts)

def _write_addons_xml_and_md5(zips_root_real: str, addons_xml_text: str):
    addons_xml_path = os.path.join(zips_root_real, "addons.xml")
    addons_md5_path = os.path.join(zips_root_real, "addons.xml.md5")

    # Always remove old files before writing new ones
    for f in (addons_xml_path, addons_md5_path):
        if os.path.exists(f):
            try:
                os.remove(f)
            except Exception as e:
                xbmc.log(f"[RepoBuilder] Failed to remove old {f}: {e}", xbmc.LOGWARNING)

    _write_text(addons_xml_path, addons_xml_text)
    md5_hex = _md5_bytes(addons_xml_text.encode("utf-8"))
    _write_text(addons_md5_path, md5_hex)

# ---- copy installed add-ons -------------------------------------------------

def _copy_installed_addons_to_repo(selected_ids, repo_root_real):
    if not selected_ids:
        return
    home_addons = _translate("special://home/addons/")
    for addon_id in selected_ids:
        src = os.path.join(home_addons, addon_id)
        dst = os.path.join(repo_root_real, addon_id)
        if not os.path.isdir(src):
            continue
        if os.path.isdir(dst):
            shutil.rmtree(dst, ignore_errors=True)
        try:
            shutil.copytree(src, dst)
        except Exception as e:
            xbmc.log(f"[RepoBuilder] Failed to copy {addon_id}: {e}", xbmc.LOGWARNING)

# ---- optional repo add-on ---------------------------------------------------

_REPO_TEMPLATE = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<addon id="repository.{repo_id}" name="{repo_name}" version="{repo_version}" provider-name="{repo_author}">
    <extension point="xbmc.addon.repository" name="{repo_name}">
        <dir>
            <info>{repo_base_url}/addons.xml</info>
            <checksum>{repo_base_url}/addons.xml.md5</checksum>
            <datadir zip="true">{repo_base_url}</datadir>
        </dir>
    </extension>
    <extension point="xbmc.addon.metadata">
        <summary>{repo_summary}</summary>
        <description>{repo_description}</description>
        <platform>all</platform>
        <assets>
            <icon>icon.png</icon>
        </assets>
    </extension>
</addon>
"""

def _maybe_create_repository_addon(repo_root_real, zips_root_real):
    if not xbmcgui.Dialog().yesno("Repo Builder", "Create / update a repository add-on in this folder?"):
        return
    repo_id = xbmcgui.Dialog().input("Repository short ID (e.g. diamondrepoaddon)")
    if not repo_id:
        return
    repo_name = xbmcgui.Dialog().input("Repository name", defaultt="Diamond Repo")
    repo_version = xbmcgui.Dialog().input("Repository version", defaultt="1.0.0")
    repo_author = xbmcgui.Dialog().input("Author", defaultt="Diamond Build")
    repo_base_url = xbmcgui.Dialog().input("Base URL to /zips (no trailing slash)")
    if not repo_base_url:
        return
    repo_summary = "Kodi add-ons repository"
    repo_description = "Auto-generated by Kodi’s Little Helper"

    repo_addon_folder = os.path.join(repo_root_real, f"repository.{repo_id}")
    _mkdirs(repo_addon_folder)
    addon_xml_text = _REPO_TEMPLATE.format(
        repo_id=repo_id,
        repo_name=repo_name,
        repo_version=repo_version,
        repo_author=repo_author,
        repo_summary=repo_summary,
        repo_description=repo_description,
        repo_base_url=repo_base_url.rstrip("/")
    )
    _write_text(os.path.join(repo_addon_folder, "addon.xml"), addon_xml_text)

# ---- main entry -------------------------------------------------------------

def repo_builder_menu():
    repo_root_vfs = xbmcgui.Dialog().browse(
        0, "Select/Create repo root folder (will contain add-on folders)", "files", "", False, True, ""
    )
    if not repo_root_vfs:
        return

    repo_root_real = _ensure_real_repo_root(repo_root_vfs)
    if not repo_root_real:
        return

    zips_root_real = os.path.join(repo_root_real, "zips")
    _mkdirs(zips_root_real)

    if xbmcgui.Dialog().yesno("Repo Builder", "Also add add-ons directly from Kodi (multi-select)?"):
        chosen_ids = _pick_installed_addons()
        _copy_installed_addons_to_repo(chosen_ids, repo_root_real)

    addon_folders = []
    for name in os.listdir(repo_root_real):
        path = os.path.join(repo_root_real, name)
        if not os.path.isdir(path):
            continue
        if name.lower() == "zips":
            continue
        if os.path.isfile(os.path.join(path, "addon.xml")):
            addon_folders.append(path)

    if not addon_folders:
        xbmcgui.Dialog().ok("Repo Builder", "No add-on folders with addon.xml were found.")
        return

    dp = xbmcgui.DialogProgress()
    dp.create("Building Repository", "Zipping add-ons...")
    collected_xml = []
    total = len(addon_folders)

    for i, folder in enumerate(addon_folders, 1):
        dp.update(int(i * 100 / total), os.path.basename(folder))

        addon_id, version, _ = _zip_addon_folder(folder, zips_root_real)

        # ✅ Always re-read the addon.xml after zipping to ensure latest version info
        addon_xml_path = os.path.join(folder, "addon.xml")
        if addon_id and version and os.path.isfile(addon_xml_path):
            xml_text = _read_text(addon_xml_path)
            collected_xml.append(xml_text)

        if dp.iscanceled():
            dp.close()
            _notify("Canceled.")
            return

    dp.close()

    addons_xml_text = _build_addons_xml(collected_xml)
    _write_addons_xml_and_md5(zips_root_real, addons_xml_text)

    _maybe_create_repository_addon(repo_root_real, zips_root_real)

    xbmcgui.Dialog().ok(
        "Repo Builder",
        "Repository built successfully.\n\n"
        f"Location:\n{repo_root_real}\n\n"
        "Upload the **zips/** folder to your server. If you created a repository add-on,\n"
        "zip that folder and install it on Kodi to link to your repo."
    )
