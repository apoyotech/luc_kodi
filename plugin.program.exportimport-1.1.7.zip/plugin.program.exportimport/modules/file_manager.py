# modules/file_manager.py
# Delete / Rename files and folders (with SAF + Kodi VFS support)
# - Recursive folder delete using xbmcvfs (works on special:// and saf://)
# - Rename file or folder (fallback copy+delete when rename unsupported)
# - Basic whitelist protection for known addon folders

import os
import json
import xbmc
import xbmcgui
import xbmcvfs
import shutil

ADDON_ID = "plugin.program.exportimport"

# Where we persist user whitelist (optional extension later)
DATA_DIR_VFS = "special://profile/addon_data/plugin.program.exportimport/"
WHITELIST_JSON_VFS = DATA_DIR_VFS + "whitelist.json"

# Default protected addon ids (won't be deleted/renamed)
DEFAULT_PROTECTED_ADDONS = {
    "plugin.program.exportimport",            # Kodi’s Little Helper
    "repository.diamondrepoaddon",            # your repo
    "service.addonprotector",                 # guardian (rename if different)
    "plugin.program.addonprotector",          # alt id, safe to include
}

def _translate(p):
    try:
        return xbmcvfs.translatePath(p)
    except Exception:
        return p

def _ensure_data_dir():
    if not xbmcvfs.exists(DATA_DIR_VFS):
        xbmcvfs.mkdirs(DATA_DIR_VFS)

def _load_whitelist():
    """Return a dict {'addons': set([...])} – future-friendly."""
    _ensure_data_dir()
    if not xbmcvfs.exists(WHITELIST_JSON_VFS):
        return {"addons": set(DEFAULT_PROTECTED_ADDONS)}
    try:
        real = _translate(WHITELIST_JSON_VFS)
        with open(real, "r", encoding="utf-8") as f:
            data = json.load(f)
        addons = set(data.get("addons", [])) | set(DEFAULT_PROTECTED_ADDONS)
        return {"addons": addons}
    except Exception:
        return {"addons": set(DEFAULT_PROTECTED_ADDONS)}

def _save_whitelist(addons_set):
    try:
        _ensure_data_dir()
        real = _translate(WHITELIST_JSON_VFS)
        with open(real, "w", encoding="utf-8") as f:
            json.dump({"addons": sorted(addons_set)}, f, indent=2)
    except Exception as e:
        xbmc.log(f"[FileManager] Failed to save whitelist: {e}", xbmc.LOGWARNING)

def _notify(title, msg, ms=3500):
    xbmcgui.Dialog().notification(title, msg, xbmcgui.NOTIFICATION_INFO, ms)

def _error(msg):
    xbmcgui.Dialog().ok("File Manager", msg)

def _join(vfs_folder, name):
    return vfs_folder.rstrip("/\\") + "/" + name

def _is_vfs(p):
    return isinstance(p, str) and (p.startswith("special://") or p.startswith("saf://") or p.startswith("smb://"))

def _listdir(vfs_path):
    try:
        return xbmcvfs.listdir(vfs_path)  # returns (dirs, files)
    except Exception:
        return ([], [])

def _exists(vfs_or_real):
    try:
        return xbmcvfs.exists(vfs_or_real)
    except Exception:
        return os.path.exists(_translate(vfs_or_real))

def _is_file(vfs_path):
    # Heuristic: listdir fails, or the path is not a directory => treat as file
    try:
        dirs, files = xbmcvfs.listdir(vfs_path)
        # If we can list it, it's a dir (Kodi shows entries)
        return False
    except Exception:
        return True

def _delete_file(vfs_path):
    """Delete a single file (VFS first; fallback to os.remove)."""
    try:
        ok = xbmcvfs.delete(vfs_path)
        if ok:
            return True
    except Exception:
        pass
    # fallback on real path
    try:
        os.remove(_translate(vfs_path))
        return True
    except Exception:
        return False

def _rmdir_empty(vfs_path):
    """Remove empty dir (VFS); fallback to os.rmdir."""
    try:
        ok = xbmcvfs.rmdir(vfs_path)
        if ok:
            return True
    except Exception:
        pass
    try:
        os.rmdir(_translate(vfs_path))
        return True
    except Exception:
        return False

def _delete_dir_recursive(vfs_dir):
    """Recursively delete a directory tree via VFS (works with SAF)."""
    # Safety: don't allow nuking special://home/ directly here; Fresh Start covers that.
    home = _translate("special://home/").rstrip("/\\")
    target_real = _translate(vfs_dir).rstrip("/\\")
    if target_real == home:
        _error("Refusing to delete entire Kodi home here. Use Fresh Start instead.")
        return False

    # Walk children
    dirs, files = _listdir(vfs_dir)
    # Delete files in this directory
    ok_all = True
    for f in files:
        if not _delete_file(_join(vfs_dir, f)):
            ok_all = False

    # Recurse into subdirectories
    for d in dirs:
        if not _delete_dir_recursive(_join(vfs_dir, d)):
            ok_all = False

    # Remove this (now empty) directory
    if not _rmdir_empty(vfs_dir):
        ok_all = False
    return ok_all

def _rename(src_vfs, dst_vfs):
    """Try native rename; on failure, copy+delete."""
    try:
        if xbmcvfs.rename(src_vfs, dst_vfs):
            return True
    except Exception:
        pass

    # Fallback: copy then delete
    try:
        # file or dir?
        if _is_file(src_vfs):
            # copy file
            src_f = xbmcvfs.File(src_vfs, 'rb')
            dst_f = xbmcvfs.File(dst_vfs, 'wb')
            while True:
                chunk = src_f.read(128 * 1024)
                if not chunk:
                    break
                dst_f.write(chunk)
            src_f.close(); dst_f.close()
            _delete_file(src_vfs)
            return True
        else:
            # dir copy
            xbmcvfs.mkdirs(dst_vfs)
            dirs, files = _listdir(src_vfs)
            for f in files:
                _rename(_join(src_vfs, f), _join(dst_vfs, f))  # copy file via fallback
            for d in dirs:
                _rename(_join(src_vfs, d), _join(dst_vfs, d))
            _rmdir_empty(src_vfs)
            return True
    except Exception as e:
        xbmc.log(f"[FileManager] Rename fallback failed: {e}", xbmc.LOGWARNING)
    return False

def _is_protected_addon_path(target_vfs):
    """
    If the path resolves to special://home/addons/<addonid>[/...],
    and addonid is whitelisted, block destructive ops.
    """
    wl = _load_whitelist()["addons"]
    home_addons_real = _translate("special://home/addons/").rstrip("/\\")
    real = _translate(target_vfs).replace("\\", "/")
    if home_addons_real.replace("\\", "/") in real:
        # extract addon id: .../addons/<id>/...
        parts = real.split("/")
        try:
            idx = parts.index("addons")
            addon_id = parts[idx + 1]
            if addon_id in wl:
                return addon_id
        except Exception:
            pass
    return None

# ---------------------------
# UI Actions
# ---------------------------

def delete_file_action():
    path = xbmcgui.Dialog().browse(1, "Select file to delete", "files", "", False, False, "")
    if not path:
        return
    prot = _is_protected_addon_path(path)
    if prot:
        _error(f"'{prot}' is protected; file under this add-on cannot be deleted here.")
        return
    if not xbmcgui.Dialog().yesno("Confirm Delete", f"Delete this file?\n\n{path}"):
        return
    if _delete_file(path):
        _notify("File Manager", "File deleted.")
    else:
        _error("Failed to delete file.")

def delete_folder_action():
    path = xbmcgui.Dialog().browse(0, "Select folder to delete (recursive)", "files", "", False, True, "")
    if not path:
        return
    prot = _is_protected_addon_path(path)
    if prot:
        _error(f"'{prot}' is protected; this add-on folder cannot be deleted here.")
        return
    if not xbmcgui.Dialog().yesno(
        "Confirm Recursive Delete",
        "This will permanently remove the selected folder and ALL its contents.\n\nProceed?"
    ):
        return
    ok = _delete_dir_recursive(path)
    if ok:
        _notify("File Manager", "Folder deleted.")
    else:
        _error("Some items could not be deleted. Check permissions / locks.")

def rename_file_action():
    path = xbmcgui.Dialog().browse(1, "Select file to rename", "files", "", False, False, "")
    if not path:
        return
    prot = _is_protected_addon_path(path)
    if prot:
        _error(f"'{prot}' is protected; file under this add-on cannot be renamed here.")
        return
    base = os.path.basename(path.rstrip("/"))
    new_name = xbmcgui.Dialog().input("New file name", defaultt=base)
    if not new_name or new_name == base:
        return
    dst = _join(path.rsplit("/", 1)[0], new_name)
    if _rename(path, dst):
        _notify("File Manager", "File renamed.")
    else:
        _error("Failed to rename file.")

def rename_folder_action():
    path = xbmcgui.Dialog().browse(0, "Select folder to rename", "files", "", False, True, "")
    if not path:
        return
    prot = _is_protected_addon_path(path)
    if prot:
        _error(f"'{prot}' is protected; this add-on folder cannot be renamed here.")
        return
    base = path.rstrip("/").split("/")[-1]
    parent = path.rstrip("/").rsplit("/", 1)[0]
    new_name = xbmcgui.Dialog().input("New folder name", defaultt=base)
    if not new_name or new_name == base:
        return
    dst = _join(parent, new_name)
    if _rename(path, dst):
        _notify("File Manager", "Folder renamed.")
    else:
        _error("Failed to rename folder.")

# ---------------------------
# Menus
# ---------------------------

def whitelist_menu():
    wl = _load_whitelist()["addons"]
    options = [
        "View protected add-ons",
        "Add add-on ID to whitelist",
        "Remove add-on ID from whitelist",
        "Reset to defaults",
        "Back",
    ]
    while True:
        sel = xbmcgui.Dialog().select("Whitelist / Protection", options)
        if sel in (-1, len(options) - 1):
            break
        elif sel == 0:
            xbmcgui.Dialog().textviewer(
                "Protected Add-ons",
                "\n".join(sorted(wl)) or "(none)"
            )
        elif sel == 1:
            new_id = xbmcgui.Dialog().input("Add-on ID to protect")
            if new_id:
                wl.add(new_id.strip())
                _save_whitelist(wl)
                _notify("Whitelist", f"Added: {new_id}")
        elif sel == 2:
            if not wl:
                _error("Whitelist is empty.")
                continue
            items = sorted(wl)
            idx = xbmcgui.Dialog().select("Remove which ID?", items)
            if idx >= 0:
                removed = items[idx]
                wl.remove(removed)
                _save_whitelist(wl)
                _notify("Whitelist", f"Removed: {removed}")
        elif sel == 3:
            if xbmcgui.Dialog().yesno("Reset", "Restore default protected add-ons?"):
                wl = set(DEFAULT_PROTECTED_ADDONS)
                _save_whitelist(wl)
                _notify("Whitelist", "Defaults restored.")

def file_tools_menu():
    options = [
        "Delete a FILE",
        "Delete a FOLDER (recursive)",
        "Rename a FILE",
        "Rename a FOLDER",
        "Back",
    ]
    while True:
        sel = xbmcgui.Dialog().select("Delete / Rename Tools", options)
        if sel in (-1, len(options) - 1):
            break
        elif sel == 0:
            delete_file_action()
        elif sel == 1:
            delete_folder_action()
        elif sel == 2:
            rename_file_action()
        elif sel == 3:
            rename_folder_action()
