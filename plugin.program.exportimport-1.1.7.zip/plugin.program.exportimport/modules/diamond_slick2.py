# modules/diamond_slick.py
# Automates moving Kodi's data folder to an unrestricted location on Android
# Treats old restricted Kodi root like a backup/restore operation.

import os
import xbmc
import xbmcgui
import xbmcvfs
import zipfile
from modules import path_helper, saf_picker

NEW_ROOT = "/storage/emulated/0/Kodi/"
NEW_ROOT2 = "/storage/emulated/0/Kodi/.kodi"
PROPS_FILE = "/storage/emulated/0/xbmc_env.properties"
TEMP_ZIP = "/storage/emulated/0/Kodi/kodi_backup.zip"


def move_to_unrestricted():
    dialog = xbmcgui.Dialog()

    # Confirm
    confirm = dialog.yesno(
        "Diamond/Slick Solution",
        f"This will move your Kodi setup to:\n\n[COLOR yellow]{NEW_ROOT2}[/COLOR]\n\n"
        "Kodi must be restarted afterwards.\n\n"
        "Do you want to continue?"
    )
    if not confirm:
        return

    # Step 1: Ensure target folders exist
    if not xbmcvfs.exists(NEW_ROOT2):
        xbmcvfs.mkdirs(NEW_ROOT2)

    # Step 2: Backup current Kodi root into a zip
    try:
        kodi_root = path_helper.kodi_root()
        dialog.notification("Diamond/Slick Solution", "Backing up Kodi data...", "")

        with zipfile.ZipFile(TEMP_ZIP, "w", zipfile.ZIP_DEFLATED) as zipf:
            for folder in ["userdata", "addons", "media"]:
                src = os.path.join(kodi_root, folder)
                if not os.path.exists(src):
                    continue
                for r, dirs, files in os.walk(src):
                    for f in files:
                        abs_path = os.path.join(r, f)
                        rel_path = os.path.relpath(abs_path, kodi_root)
                        try:
                            zipf.write(abs_path, rel_path)
                        except Exception as e:
                            xbmc.log(f"[DiamondSlick] Failed to zip {abs_path}: {e}", xbmc.LOGWARNING)

        xbmc.log(f"[DiamondSlick] Backup created: {TEMP_ZIP}", xbmc.LOGINFO)

    except Exception as e:
        dialog.ok("Diamond/Slick Solution", f"Failed to backup Kodi data:\n{e}")
        return

    # Step 3: Extract backup into NEW_ROOT2
    try:
        dialog.notification("Diamond/Slick Solution", "Restoring Kodi data...", "")
        with zipfile.ZipFile(TEMP_ZIP, "r") as zf:
            zf.extractall(NEW_ROOT2)
        xbmc.log(f"[DiamondSlick] Restored backup into {NEW_ROOT2}", xbmc.LOGINFO)
    except Exception as e:
        dialog.ok("Diamond/Slick Solution", f"Failed to restore Kodi data:\n{e}")
        return

    # Step 4: Write xbmc_env.properties
    try:
        with open(PROPS_FILE, "w", encoding="utf-8") as f:
            f.write(f"xbmc.data={NEW_ROOT}\n")
        xbmc.log(f"[DiamondSlick] xbmc_env.properties written to {PROPS_FILE}", xbmc.LOGINFO)
    except Exception as e:
        dialog.ok("Diamond/Slick Solution", f"Failed to write xbmc_env.properties:\n{e}")
        return

    # Step 5: Final message
    dialog.ok(
        "Diamond/Slick Solution",
        f"Setup complete!\n\nKodi is now configured to use:\n[COLOR green]{NEW_ROOT2}[/COLOR]\n\n"
        "Please [B]restart Kodi[/B] for changes to take effect."
    )
