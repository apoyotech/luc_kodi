# modules/selective_installer.py
# Selective build/updater installer: let user choose which parts of a build ZIP to apply.
# - Uses merge_manager for XML merges (sources/favourites/mediasources/profiles)
# - Backups are created before overwriting userdata/addons
# - Extracts ZIP to special://temp/plugin.program.exportimport/selective_install/<timestamp>/

import os
import zipfile
import shutil
import time
import xbmc
import xbmcgui
import xbmcvfs
from urllib.parse import urlsplit, unquote

# reuse existing helpers/modules in your addon
from modules import merge_manager
from modules import installer  # to reuse _download_zip
from modules import path_helper

CHUNK_SIZE = 1024 * 128
TEMP_ROOT_VFS = "special://temp/plugin.program.exportimport/selective_install/"

# -------------------------
# Helpers
# -------------------------
def _now_tag():
    return time.strftime("%Y%m%d-%H%M%S")

def _translate(vfs_or_real):
    """Translate vfs-ish paths to real FS paths where possible."""
    try:
        return xbmcvfs.translatePath(vfs_or_real) if vfs_or_real else None
    except Exception:
        return vfs_or_real

def _ensure_temp_folder():
    vfs = TEMP_ROOT_VFS + _now_tag() + "/"
    try:
        if not xbmcvfs.exists(xbmcvfs.translatePath("special://temp/")):
            xbmcvfs.mkdirs(xbmcvfs.translatePath("special://temp/"))
    except Exception:
        pass
    # create resolved folder
    real = _translate(vfs)
    try:
        os.makedirs(real, exist_ok=True)
    except Exception:
        pass
    return vfs

def _clear_temp(root_vfs):
    real = _translate(root_vfs)
    try:
        if real and os.path.exists(real):
            shutil.rmtree(real, ignore_errors=True)
    except Exception:
        pass

def _zip_extract_to(zip_real, dest_vfs):
    """
    Extract zip_real (real path) into dest_vfs (VFS path). Returns dest_real path.
    We extract to the real path returned by translatePath(dest_vfs).
    """
    dest_real = _translate(dest_vfs)
    os.makedirs(dest_real, exist_ok=True)
    try:
        with zipfile.ZipFile(zip_real, "r") as zf:
            zf.extractall(dest_real)
    except Exception as e:
        xbmc.log(f"[SelectiveInstaller] Zip extract failed: {e}", xbmc.LOGERROR)
        raise
    return dest_real

def _vfs_copy_tree(src_real, dst_vfs):
    """
    Copy a real filesystem tree (src_real) into dst_vfs (VFS path).
    Uses OS-level copy where possible (dst_vfs translates to real), otherwise logs failure.
    """
    dst_real = _translate(dst_vfs)
    if not dst_real:
        xbmc.log("[SelectiveInstaller] Destination translate failed", xbmc.LOGERROR)
        return False
    try:
        # If src is a file, copy directly
        if os.path.isfile(src_real):
            os.makedirs(os.path.dirname(dst_real), exist_ok=True)
            shutil.copy2(src_real, dst_real)
            return True

        # copytree semantics: merge into destination (not replace)
        for root, dirs, files in os.walk(src_real):
            rel = os.path.relpath(root, src_real)
            if rel == ".":
                base = dst_real
            else:
                base = os.path.join(dst_real, rel)
            os.makedirs(base, exist_ok=True)
            for f in files:
                s = os.path.join(root, f)
                d = os.path.join(base, f)
                try:
                    shutil.copy2(s, d)
                except Exception as e:
                    xbmc.log(f"[SelectiveInstaller] copy failed {s} -> {d}: {e}", xbmc.LOGWARNING)
        return True
    except Exception as e:
        xbmc.log(f"[SelectiveInstaller] _vfs_copy_tree failed: {e}", xbmc.LOGERROR)
        return False

def _backup_real_path(real_path):
    """Create a timestamped backup copy of a folder or file (real fs path)."""
    try:
        if not os.path.exists(real_path):
            return None
        bak = real_path + ".bak." + _now_tag()
        parent = os.path.dirname(bak)
        os.makedirs(parent, exist_ok=True)
        if os.path.isdir(real_path):
            shutil.copytree(real_path, bak)
        else:
            shutil.copy2(real_path, bak)
        xbmc.log(f"[SelectiveInstaller] Backup created: {bak}", xbmc.LOGINFO)
        return bak
    except Exception as e:
        xbmc.log(f"[SelectiveInstaller] Backup failed for {real_path}: {e}", xbmc.LOGWARNING)
        return None

# -------------------------
# Install worker pieces
# -------------------------
def _install_user_data(extracted_real):
    """
    Copy extracted userdata into special://home/userdata/
    Creates a backup of existing userdata first.
    """
    home_real = xbmcvfs.translatePath("special://home/")
    dest_user_real = os.path.join(home_real, "userdata")
    src_user_real = os.path.join(extracted_real, "userdata")

    if not os.path.exists(src_user_real):
        xbmcgui.Dialog().ok("Selective Installer", "No userdata/ folder found in ZIP.")
        return False

    # backup existing userdata
    _backup_real_path(dest_user_real)

    xbmcgui.Dialog().notification("Selective Installer", "Installing userdata (overlay)...", "")
    ok = _vfs_copy_tree(src_user_real, f"special://home/userdata/")
    return ok

def _install_addons(extracted_real):
    """
    Copy extracted addons into special://home/addons/
    Back up existing addons folder first.
    """
    home_real = xbmcvfs.translatePath("special://home/")
    dest_addons_real = os.path.join(home_real, "addons")
    src_addons_real = os.path.join(extracted_real, "addons")

    if not os.path.exists(src_addons_real):
        xbmcgui.Dialog().ok("Selective Installer", "No addons/ folder found in ZIP.")
        return False

    _backup_real_path(dest_addons_real)
    xbmcgui.Dialog().notification("Selective Installer", "Installing addons (overlay)...", "")
    ok = _vfs_copy_tree(src_addons_real, f"special://home/addons/")
    # refresh addon DBs so Kodi notices new add-ons
    try:
        xbmc.executebuiltin('UpdateLocalAddons')
        xbmc.executebuiltin('UpdateAddonRepos')
    except Exception:
        pass
    return ok

def _merge_xml_from_extracted(extracted_real, filename):
    """
    Merge a single xml (favourites.xml, sources.xml, mediasources.xml, profiles.xml)
    from the extracted folder into special://home/userdata/<filename>
    """
    src_path = os.path.join(extracted_real, "userdata", filename)
    dest_vfs = f"special://home/userdata/{filename}"
    dest_real = _translate(dest_vfs)

    if not os.path.exists(src_path):
        xbmc.log(f"[SelectiveInstaller] {filename} not present in ZIP, skipping.", xbmc.LOGINFO)
        return False

    # Ensure destination exists; if not, copy src directly
    if not os.path.exists(dest_real):
        try:
            os.makedirs(os.path.dirname(dest_real), exist_ok=True)
            shutil.copy2(src_path, dest_real)
            xbmc.log(f"[SelectiveInstaller] {filename} copied (no dest existed).", xbmc.LOGINFO)
            return True
        except Exception as e:
            xbmc.log(f"[SelectiveInstaller] Failed to copy {filename} to userdata: {e}", xbmc.LOGERROR)
            return False

    # call merge_manager helpers
    try:
        if filename.lower() == "sources.xml":
            return merge_manager.merge_sources(dest_real, src_path, dest_real)
        elif filename.lower() == "mediasources.xml":
            return merge_manager.merge_mediasources(dest_real, src_path, dest_real)
        elif filename.lower() == "profiles.xml":
            return merge_manager.merge_profiles(dest_real, src_path, dest_real)
        elif filename.lower() == "favourites.xml":
            return merge_manager.merge_favourites(dest_real, src_path, dest_real)
    except Exception as e:
        xbmc.log(f"[SelectiveInstaller] merge failed for {filename}: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("Selective Installer", f"Merge failed for {filename}:\n{e}")
        return False

    return False

def _install_individual_files_dialog(extracted_real):
    """
    Present list of files from extracted userdata and allow user to pick particular ones to copy.
    Copies into special://home/userdata/ preserving relative paths.
    """
    base = os.path.join(extracted_real, "userdata")
    if not os.path.exists(base):
        xbmcgui.Dialog().ok("Selective Installer", "No userdata folder found in ZIP.")
        return False

    # collect xml and config files (limit to reasonable size)
    choices = []
    paths = []
    for root, dirs, files in os.walk(base):
        for f in files:
            rel = os.path.relpath(os.path.join(root, f), base)
            choices.append(rel)
            paths.append(os.path.join(root, f))

    if not choices:
        xbmcgui.Dialog().ok("Selective Installer", "No files available for selective copy.")
        return False

    sel = xbmcgui.Dialog().multiselect("Pick files to copy into userdata", choices)
    if not sel:
        return False

    for idx in sel:
        src = paths[idx]
        rel = choices[idx]
        dst_vfs = f"special://home/userdata/{rel}"
        dst_real = _translate(dst_vfs)
        os.makedirs(os.path.dirname(dst_real), exist_ok=True)
        try:
            shutil.copy2(src, dst_real)
        except Exception as e:
            xbmc.log(f"[SelectiveInstaller] Failed to copy {src} -> {dst_real}: {e}", xbmc.LOGWARNING)

    xbmcgui.Dialog().ok("Selective Installer", "Selected files copied into userdata.")
    return True

# -------------------------
# Public install flows
# -------------------------
def selective_install_menu():
    """
    Menu entry point:
    - Ask for ZIP (local or download)
    - Extract zip to temp
    - Present checklist
    - Apply selected components
    """
    dialog = xbmcgui.Dialog()

    options = ["Install from local ZIP", "Install from URL", "Back"]
    sel = dialog.select("Selective Build Installer", options)
    if sel == -1 or options[sel] == "Back":
        return

    if sel == 0:
        zip_vfs = dialog.browse(1, "Select Build/Updater ZIP", "files", ".zip", False, False, "")
        if not zip_vfs:
            return
        zip_real = _translate(zip_vfs)
    else:
        url = dialog.input("Enter Build/Updater ZIP URL")
        if not url:
            return
        # reuse installer._download_zip for consistent behavior
        zip_real = installer._download_zip(url, dest_vfs_folder="special://temp/plugin.program.exportimport/")
        if not zip_real:
            return

    # prepare temp folder
    temp_vfs = _ensure_temp_folder()
    temp_real = _translate(temp_vfs)

    # extract
    try:
        xbmcgui.Dialog().notification("Selective Installer", "Extracting ZIP...", "")
        _zip_extract_to(zip_real, temp_vfs)
    except Exception as e:
        xbmcgui.Dialog().ok("Selective Installer", f"Failed to extract ZIP:\n{e}")
        _clear_temp(temp_vfs)
        return

    # Build checklist
    labels = [
        "Userdata (overlay entire userdata/)",
        "Addons (overlay addons/)",
        "Favourites (merge favourites.xml)",
        "Sources (merge sources.xml)",
        "Mediasources (merge mediasources.xml)",
        "Profiles (merge profiles.xml)",
        "Advanced: pick individual userdata files",
        "Cancel"
    ]
    picked = xbmcgui.Dialog().multiselect("Select components to install", labels)
    if not picked:
        _clear_temp(temp_vfs)
        return

    # Map choices
    try:
        if 0 in picked:
            _install_user_data(temp_real)
        if 1 in picked:
            _install_addons(temp_real)
        if 2 in picked:
            _merge_xml_from_extracted(temp_real, "favourites.xml")
        if 3 in picked:
            _merge_xml_from_extracted(temp_real, "sources.xml")
        if 4 in picked:
            _merge_xml_from_extracted(temp_real, "mediasources.xml")
        if 5 in picked:
            _merge_xml_from_extracted(temp_real, "profiles.xml")
        if 6 in picked:
            _install_individual_files_dialog(temp_real)
    finally:
        _clear_temp(temp_vfs)

    xbmcgui.Dialog().ok("Selective Installer", "Selective install completed. Restart Kodi if needed.")

def selective_install_from_zip(zip_vfs):
    """Helper to run selective install given a ZIP vfs path (used by other modules)."""
    zip_real = _translate(zip_vfs)
    if not zip_real or not os.path.exists(zip_real):
        xbmcgui.Dialog().ok("Selective Installer", "ZIP not found.")
        return
    temp_vfs = _ensure_temp_folder()
    temp_real = _translate(temp_vfs)
    try:
        _zip_extract_to(zip_real, temp_vfs)
        # show the same checklist flow
        labels = [
            "Userdata (overlay entire userdata/)",
            "Addons (overlay addons/)",
            "Favourites (merge favourites.xml)",
            "Sources (merge sources.xml)",
            "Mediasources (merge mediasources.xml)",
            "Profiles (merge profiles.xml)",
            "Advanced: pick individual userdata files",
            "Cancel"
        ]
        picked = xbmcgui.Dialog().multiselect("Select components to install", labels)
        if not picked:
            return
        if 0 in picked:
            _install_user_data(temp_real)
        if 1 in picked:
            _install_addons(temp_real)
        if 2 in picked:
            _merge_xml_from_extracted(temp_real, "favourites.xml")
        if 3 in picked:
            _merge_xml_from_extracted(temp_real, "sources.xml")
        if 4 in picked:
            _merge_xml_from_extracted(temp_real, "mediasources.xml")
        if 5 in picked:
            _merge_xml_from_extracted(temp_real, "profiles.xml")
        if 6 in picked:
            _install_individual_files_dialog(temp_real)
    finally:
        _clear_temp(temp_vfs)
    xbmcgui.Dialog().ok("Selective Installer", "Selective install completed. Restart Kodi if needed.")
