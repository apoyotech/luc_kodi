# modules/remote_favorites.py
# Manage favorites for remote URLs (no changes to remote_browser.py)

import os
import json
import xbmcgui
import xbmcvfs
from modules import remote_browser

ADDON_ID = "plugin.program.exportimport"
FAV_FILE = xbmcvfs.translatePath(f"special://profile/addon_data/{ADDON_ID}/remote_favorites.json")

def _load_favs():
    if not xbmcvfs.exists(FAV_FILE):
        return []
    try:
        with open(FAV_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return []

def _save_favs(favs):
    folder = os.path.dirname(FAV_FILE)
    if not xbmcvfs.exists(folder):
        xbmcvfs.mkdirs(folder)
    with open(FAV_FILE, "w", encoding="utf-8") as f:
        json.dump(favs, f, indent=2)

def manage_favorites():
    """Main favorites menu."""
    while True:
        options = ["Browse Favorite", "Add Favorite", "Remove Favorite", "Exit"]
        sel = xbmcgui.Dialog().select("Remote Favorites", options)

        if sel in (-1, 3):  # Exit
            break
        elif sel == 0:  # Browse Favorite
            favs = _load_favs()
            if not favs:
                xbmcgui.Dialog().ok("Remote Favorites", "No favorites saved.")
                continue
            idx = xbmcgui.Dialog().select("Choose Favorite", favs)
            if idx >= 0:
                remote_browser.remote_browser_menu_from_url(favs[idx])
        elif sel == 1:  # Add Favorite
            url = xbmcgui.Dialog().input("Enter URL to save")
            if url:
                favs = _load_favs()
                if url not in favs:
                    favs.append(url)
                    _save_favs(favs)
                    xbmcgui.Dialog().notification("Remote Favorites", "Added")
        elif sel == 2:  # Remove Favorite
            favs = _load_favs()
            if not favs:
                xbmcgui.Dialog().ok("Remote Favorites", "No favorites to remove.")
                continue
            idx = xbmcgui.Dialog().select("Remove Which?", favs)
            if idx >= 0:
                favs.pop(idx)
                _save_favs(favs)
                xbmcgui.Dialog().notification("Remote Favorites", "Removed")
