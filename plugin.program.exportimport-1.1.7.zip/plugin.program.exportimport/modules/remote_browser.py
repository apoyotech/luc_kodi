# modules/remote_browser.py
# Browse remote repository URLs, view directory listings, and download files.

import re
import os
import urllib.request
import urllib.error
import xbmc
import xbmcgui
import xbmcvfs
from modules.utils import _join_path, get_download_folder

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0 Safari/537.36"
    )
}

def fetch_url(url):
    """Fetch HTML content with proper headers."""
    if not url.endswith("/"):
        url += "/"
    req = urllib.request.Request(url, headers=HEADERS)
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.read().decode("utf-8", errors="ignore")
    except urllib.error.HTTPError as e:
        xbmcgui.Dialog().ok("Remote Browser", f"HTTP Error {e.code}\n{url}")
    except Exception as e:
        xbmcgui.Dialog().ok("Remote Browser", f"Error fetching URL:\n{e}")
    return None

def parse_links(base_url, html):
    """Extract clickable links from a directory index page."""
    links = re.findall(r'href="([^"]+)"', html)
    cleaned = []
    for link in links:
        if link.startswith("?") or link.startswith("#"):
            continue
        if link.startswith("http"):
            cleaned.append(link)
        else:
            cleaned.append(base_url.rstrip("/") + "/" + link)
    return cleaned

def download_file(url):
    """Download a selected file to the Imported_Files folder."""
    save_folder = get_download_folder()
    if not save_folder:
        return

    fname = os.path.basename(url.split("?")[0])
    dest = _join_path(save_folder, fname)

    dp = xbmcgui.DialogProgress()
    dp.create("Downloading", fname)

    try:
        req = urllib.request.Request(url, headers=HEADERS)
        with urllib.request.urlopen(req, timeout=30) as resp:
            out_f = xbmcvfs.File(dest, "wb")
            while True:
                chunk = resp.read(1024 * 256)
                if not chunk:
                    break
                out_f.write(chunk)
            out_f.close()
        dp.close()
        xbmcgui.Dialog().ok("Download Complete", f"Saved to:\n{dest}")
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok("Download Failed", str(e))

def remote_browser_menu():
    """Interactive menu to browse and download from a remote repo."""
    base_url = xbmcgui.Dialog().input(
        "Enter base URL (http/https):", type=xbmcgui.INPUT_ALPHANUM
    )
    if not base_url:
        return

    html = fetch_url(base_url)
    if not html:
        return

    links = parse_links(base_url, html)
    if not links:
        xbmcgui.Dialog().ok("Remote Browser", "No files or directories found.")
        return

    sel = xbmcgui.Dialog().select("Remote Files", links)
    if sel == -1:
        return

    choice = links[sel]
    if choice.endswith("/"):
        # Navigate deeper
        remote_browser_menu()
    else:
        # Download the selected file
        download_file(choice)

def remote_browser_menu_from_url(url):
    """Browse starting from a given URL (for favorites)."""
    html = fetch_url(url)
    if not html:
        return
    links = parse_links(url, html)
    if not links:
        xbmcgui.Dialog().ok("Remote Browser", "No files or directories found.")
        return

    sel = xbmcgui.Dialog().select("Remote Files", links)
    if sel == -1:
        return

    choice = links[sel]
    if choice.endswith("/"):
        remote_browser_menu_from_url(choice)
    else:
        download_file(choice)
