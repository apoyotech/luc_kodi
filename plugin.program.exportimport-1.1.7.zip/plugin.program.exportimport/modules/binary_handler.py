# modules/binary_handler.py
# Handles re-install of platform-specific binary addons from build_binaries.txt

import xbmc
import xbmcgui
import xbmcaddon
import os
import xbmcvfs

BINARY_FILE = xbmcvfs.translatePath("special://userdata/build_binaries.txt")

# simple state tracker so retries happen only once per Kodi session
_retry_done = False


def log(msg):
    xbmc.log(f"[BinaryHandler] {msg}", xbmc.LOGINFO)


def install_and_enable(addonid):
    """
    Try to install an addon from Kodi repo, then enable it.
    Returns True if addon is installed + enabled, False otherwise.
    """
    try:
        xbmc.executebuiltin(f"InstallAddon({addonid})", True)
        xbmc.sleep(2000)  # wait a little for install

        # Enable the addon
        xbmc.executebuiltin(f"EnableAddon({addonid})", True)
        xbmc.sleep(500)

        # Verify installed + enabled
        addon = xbmcaddon.Addon(addonid)
        enabled = xbmc.getCondVisibility(f"System.HasAddon({addonid})")
        return bool(addon and enabled)
    except Exception as e:
        log(f"{addonid} install/enable failed: {e}")
        return False


def process_binaries():
    """
    Main entry point: detects build_binaries.txt and processes installs.
    Runs once per startup, with optional retry if user agrees.
    """
    global _retry_done

    if not xbmcvfs.exists(BINARY_FILE):
        log("No build_binaries.txt found. Nothing to do.")
        return

    # Read file contents
    with xbmcvfs.File(BINARY_FILE) as f:
        content = f.read()
    addon_ids = [a.strip() for a in content.split(",") if a.strip()]

    if not addon_ids:
        log("Binary file exists but is empty. Removing.")
        xbmcvfs.delete(BINARY_FILE)
        return

    dialog = xbmcgui.Dialog()
    dialog.ok("Binary Add-ons",
              "Kodi will now attempt to install them Please wait.")

    success = []
    fail = []

    for addonid in addon_ids:
        if install_and_enable(addonid):
            log(f"{addonid} install succeeded.")
            success.append(addonid)
        else:
            log(f"{addonid} install failed.")
            fail.append(addonid)

    if not fail:
        dialog.ok("Binary Add-ons", "All required add-ons installed successfully.")
        xbmcvfs.delete(BINARY_FILE)
        return

    # If we reach here, some failed
    dialog.ok("Binary Add-ons", f"{', '.join(fail)}")

    if not _retry_done:
        retry = dialog.yesno(
                             "Binary Repair",                  # heading
                             "Some add-ons failed.\nWould you like to retry?",  # message
                             nolabel="No", yeslabel="Retry")
        if retry:
            _retry_done = True
            process_binaries()  # retry once
        else:
            log("User declined retry.")
    else:
        log("Retry already attempted this session. Leaving file for next restart.")
