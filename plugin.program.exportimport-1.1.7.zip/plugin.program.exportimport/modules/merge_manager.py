# modules/merge_manager.py
# Merges Kodi XML config files: sources.xml, mediasources.xml, profiles.xml, favourites.xml
# Avoids duplicate entries and backs up the destination before overwriting.

import os
import time
import shutil
import copy
import xml.etree.ElementTree as ET
import xbmcgui
import xbmcvfs
import xbmc

# ------------------------------------------------------------
# Helpers
# ------------------------------------------------------------
def _translate(path_or_vfs):
    """Return a real filesystem path for a VFS-style path when possible."""
    if path_or_vfs is None:
        return None
    if path_or_vfs.startswith("special://") or path_or_vfs.startswith("smb://") or path_or_vfs.startswith("saf://"):
        try:
            return xbmcvfs.translatePath(path_or_vfs)
        except Exception:
            return path_or_vfs
    return path_or_vfs

def _exists(path_or_vfs):
    """Check existence in VFS or real fs."""
    if xbmcvfs.exists(path_or_vfs):
        return True
    real = _translate(path_or_vfs)
    return os.path.exists(real)

def _backup_file(realpath):
    try:
        if not os.path.exists(realpath):
            return
        bak = realpath + ".bak." + time.strftime("%Y%m%d-%H%M%S")
        os.makedirs(os.path.dirname(bak), exist_ok=True)
        shutil.copy2(realpath, bak)
        xbmc.log(f"[MergeManager] Backup created: {bak}", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[MergeManager] Backup failed: {e}", xbmc.LOGWARNING)

def _load_tree(vfs_or_real):
    real = _translate(vfs_or_real)
    if not real or not os.path.exists(real):
        raise FileNotFoundError(f"File not found: {vfs_or_real}")
    parser = ET.XMLParser(encoding="utf-8")
    tree = ET.parse(real, parser=parser)
    return tree

def _write_tree(tree, vfs_or_real):
    real = _translate(vfs_or_real)
    _backup_file(real)
    tree.write(real, encoding="utf-8", xml_declaration=True)
    xbmcgui.Dialog().ok("Merge Complete", f"Saved merged file:\n{vfs_or_real}")

# ------------------------------------------------------------
# Key extraction / dedupe helpers
# ------------------------------------------------------------

def merge_files(src, dst, out=None):
    """
    Merge two Kodi XML files into one.
    src = existing XML (already in Kodi userdata)
    dst = new XML (from ZIP or backup)
    out = output path (default = overwrite src)
    """
    if not os.path.exists(src):
        shutil.copy2(dst, out or src)
        return

    if not os.path.exists(dst):
        return

    try:
        tree1 = ET.parse(src)
        tree2 = ET.parse(dst)
    except Exception as e:
        xbmc.log(f"[merge_manager] Failed to parse XML: {e}", xbmc.LOGERROR)
        return

    root1, root2 = tree1.getroot(), tree2.getroot()

    filename = os.path.basename(src).lower()
    if filename == "sources.xml":
        _merge_sources(root1, root2)
    elif filename == "mediasources.xml":
        _merge_mediasources(root1, root2)
    elif filename == "profiles.xml":
        _merge_profiles(root1, root2)
    elif filename == "favourites.xml":
        _merge_favourites(root1, root2)
    else:
        # fallback: append unique children
        _merge_generic(root1, root2)

    # Backup before overwrite
    backup_path = f"{src}.bak"
    try:
        shutil.copy2(src, backup_path)
    except Exception:
        pass

    # Pretty-print output
    _indent(root1)
    out_path = out or src
    tree1.write(out_path, encoding="utf-8", xml_declaration=True)

def _source_key(source_elem):
    """Return canonical key for a <source> element: path text(s) or name fallback."""
    # look for <path> children (may be multiple)
    paths = []
    for p in source_elem.findall("path"):
        if p.text and p.text.strip():
            paths.append(p.text.strip().lower())
    if paths:
        # join multiple paths if present
        return "||".join(paths)
    # fallback to <name>
    name = source_elem.findtext("name") or ""
    return name.strip().lower()

def _favourite_key(fav_elem):
    """Return key for <favourite> (use path or title)."""
    path = fav_elem.findtext("path") or fav_elem.get("path") or ""
    title = fav_elem.findtext("title") or fav_elem.get("title") or ""
    return (path.strip().lower() or title.strip().lower())

def _generic_child_key(elem):
    """Try to derive a reproducible key for arbitrary element (attrs or text children)."""
    # prefer 'path', 'title', 'label', 'name'
    for tag in ("path", "title", "label", "name"):
        t = elem.findtext(tag)
        if t and t.strip():
            return t.strip().lower()
    # fallback to attributes concatenated
    if elem.items():
        return "||".join(f"{k}={v}" for k, v in sorted(elem.items())).lower()
    # fallback to stringified element
    return ET.tostring(elem, encoding="utf-8", method="xml").decode("utf-8").strip().lower()

# ------------------------------------------------------------
# Merge functions
# ------------------------------------------------------------
def merge_sources(src_a, src_b, out_vfs=None):
    """
    Merge two sources.xml files.
    src_a: primary (destination) file (VFS or real path)
    src_b: file to merge into src_a
    out_vfs: optional output path (if None, src_a will be overwritten after backup)
    """
    try:
        tree_a = _load_tree(src_a)
        tree_b = _load_tree(src_b)
    except Exception as e:
        xbmcgui.Dialog().ok("Merge Error", str(e))
        return False

    root_a = tree_a.getroot()
    root_b = tree_b.getroot()

    sections = ["video", "music", "pictures", "files"]
    merged_count = 0
    for sec in sections:
        sec_a = root_a.find(sec)
        sec_b = root_b.find(sec)
        if sec_b is None:
            continue
        if sec_a is None:
            # create section if missing in A
            sec_a = ET.SubElement(root_a, sec)

        # build keys set for existing children
        existing_keys = set()
        for child in list(sec_a):
            k = _source_key(child)
            existing_keys.add(k)

        for child in list(sec_b):
            k = _source_key(child)
            if not k:
                # still append if nothing to compare by
                sec_a.append(copy.deepcopy(child))
                merged_count += 1
            elif k not in existing_keys:
                sec_a.append(copy.deepcopy(child))
                existing_keys.add(k)
                merged_count += 1

    out = out_vfs or src_a
    _write_tree(tree_a, out)
    xbmc.log(f"[MergeManager] merge_sources added {merged_count} new entries", xbmc.LOGINFO)
    return True

def merge_mediasources(a, b, out_vfs=None):
    """Merge mediasources.xml: append unique child nodes under root."""
    try:
        tree_a = _load_tree(a)
        tree_b = _load_tree(b)
    except Exception as e:
        xbmcgui.Dialog().ok("Merge Error", str(e))
        return False

    r_a = tree_a.getroot()
    r_b = tree_b.getroot()

    existing = {_generic_child_key(ch) for ch in list(r_a)}
    added = 0
    for ch in list(r_b):
        key = _generic_child_key(ch)
        if key not in existing:
            r_a.append(copy.deepcopy(ch))
            existing.add(key)
            added += 1

    out = out_vfs or a
    _write_tree(tree_a, out)
    xbmc.log(f"[MergeManager] merge_mediasources added {added} items", xbmc.LOGINFO)
    return True

def merge_profiles(a, b, out_vfs=None):
    """Merge profiles.xml by appending unique <profile> entries."""
    try:
        tree_a = _load_tree(a)
        tree_b = _load_tree(b)
    except Exception as e:
        xbmcgui.Dialog().ok("Merge Error", str(e))
        return False

    r_a = tree_a.getroot()
    r_b = tree_b.getroot()

    existing = {_generic_child_key(ch) for ch in list(r_a)}
    added = 0
    for ch in list(r_b):
        key = _generic_child_key(ch)
        if key not in existing:
            r_a.append(copy.deepcopy(ch))
            existing.add(key)
            added += 1

    out = out_vfs or a
    _write_tree(tree_a, out)
    xbmc.log(f"[MergeManager] merge_profiles added {added} items", xbmc.LOGINFO)
    return True

def merge_favourites(a, b, out_vfs=None):
    """Merge favourites.xml (append unique favourites by path/title)."""
    try:
        tree_a = _load_tree(a)
        tree_b = _load_tree(b)
    except Exception as e:
        xbmcgui.Dialog().ok("Merge Error", str(e))
        return False

    r_a = tree_a.getroot()
    r_b = tree_b.getroot()

    existing = set()
    for ch in list(r_a):
        existing.add(_favourite_key(ch))

    added = 0
    for ch in list(r_b):
        key = _favourite_key(ch)
        if key not in existing:
            r_a.append(copy.deepcopy(ch))
            existing.add(key)
            added += 1

    out = out_vfs or a
    _write_tree(tree_a, out)
    xbmc.log(f"[MergeManager] merge_favourites added {added} items", xbmc.LOGINFO)
    return True

# ------------------------------------------------------------
# Dialog helpers for menu wiring
# ------------------------------------------------------------
def _pick_file_dialog(title, start_path="special://home/"):
    """Prompt user to pick a file (returns VFS path or None)."""
    d = xbmcgui.Dialog()
    picked = d.browse(1, title, 'files', '.xml', False, False, start_path)
    return picked

def merge_sources_dialog():
    a = _pick_file_dialog("Select primary sources.xml (destination)", "special://home/userdata/")
    if not a: return
    b = _pick_file_dialog("Select sources.xml to merge INTO primary", "special://home/userdata/")
    if not b: return
    out = a  # overwrite primary
    if merge_sources(a, b, out):
        xbmcgui.Dialog().ok("Merge Sources", "Merge complete.")

def merge_mediasources_dialog():
    a = _pick_file_dialog("Select primary mediasources.xml", "special://home/userdata/")
    if not a: return
    b = _pick_file_dialog("Select mediasources.xml to merge", "special://home/userdata/")
    if not b: return
    if merge_mediasources(a, b, a):
        xbmcgui.Dialog().ok("Merge mediasources", "Merge complete.")

def merge_profiles_dialog():
    a = _pick_file_dialog("Select primary profiles.xml", "special://home/userdata/")
    if not a: return
    b = _pick_file_dialog("Select profiles.xml to merge", "special://home/userdata/")
    if not b: return
    if merge_profiles(a, b, a):
        xbmcgui.Dialog().ok("Merge profiles", "Merge complete.")

def merge_favourites_dialog():
    a = _pick_file_dialog("Select primary favourites.xml", "special://home/userdata/")
    if not a: return
    b = _pick_file_dialog("Select favourites.xml to merge", "special://home/userdata/")
    if not b: return
    if merge_favourites(a, b, a):
        xbmcgui.Dialog().ok("Merge favourites", "Merge complete.")
