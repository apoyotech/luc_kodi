# modules/zip_tools.py
# Standalone ZIP tools for Kodi's Little Helper
# - Extract ZIP (device FS → Kodi root)
# - Zip Directory (Kodi root → device FS)
# - Download ZIP from URL

import os
import zipfile
import urllib.request
import xbmc
import xbmcgui
import xbmcvfs
from urllib.parse import urlsplit, unquote

from modules.path_helper import browse_folder_kodi_root, _join_path, get_download_folder
from modules import saf_picker   # SAF-aware picker for device filesystem

CHUNK_SIZE = 1024 * 128  # 128 KB


def extract_zip():
    """Extract a ZIP file from device filesystem → Kodi root."""
    src_zip = saf_picker.pick_file("Select ZIP file to extract", mask=".zip")
    if not src_zip:
        return
    dst_folder = browse_folder_kodi_root("Select destination folder (Kodi root)")
    if not dst_folder:
        return

    dp = xbmcgui.DialogProgress()
    dp.create("Extracting", os.path.basename(src_zip))

    try:
        with zipfile.ZipFile(xbmcvfs.translatePath(src_zip), 'r') as zf:
            file_list = zf.namelist()
            total = len(file_list)
            for i, member in enumerate(file_list, 1):
                dp.update(int((i / total) * 100), f"Extracting: {member}")
                zf.extract(member, xbmcvfs.translatePath(dst_folder))
        dp.close()
        xbmcgui.Dialog().ok("Extract Complete", f"Files extracted to:\n{dst_folder}")
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok("Extract Failed", str(e))


def zip_directory():
    """Create a ZIP archive from a directory in Kodi root → device filesystem."""
    src_folder = browse_folder_kodi_root("Select directory to zip (Kodi root)")
    if not src_folder:
        return
    dst_folder = saf_picker.pick_folder("Select destination folder (device filesystem)")
    if not dst_folder:
        return

    zip_name = os.path.basename(src_folder.rstrip('/')) + ".zip"
    dst_zip = saf_picker.join(dst_folder, zip_name)

    dp = xbmcgui.DialogProgress()
    dp.create("Creating ZIP", zip_name)

    try:
        with zipfile.ZipFile(xbmcvfs.translatePath(dst_zip), 'w', zipfile.ZIP_DEFLATED) as zf:
            for root, dirs, files in os.walk(xbmcvfs.translatePath(src_folder)):
                for f in files:
                    abs_path = os.path.join(root, f)
                    rel_path = os.path.relpath(abs_path, xbmcvfs.translatePath(src_folder))
                    dp.update(0, f"Adding: {rel_path}")
                    zf.write(abs_path, rel_path)
        dp.close()
        xbmcgui.Dialog().ok("ZIP Complete", f"Created:\n{dst_zip}")
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok("ZIP Failed", str(e))


def download_zip_from_url():
    """Download a ZIP from a URL and save to the chosen download folder."""
    url = xbmcgui.Dialog().input("Enter ZIP URL (http/https/ftp)")
    if not url:
        return
    save_folder = get_download_folder()
    if not save_folder:
        return

    fname = unquote(os.path.basename(urlsplit(url).path)) or "download.zip"
    dest_vfs_path = _join_path(save_folder, fname)

    dp = xbmcgui.DialogProgress()
    dp.create("Downloading", fname)
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=45) as resp:
            out_f = xbmcvfs.File(dest_vfs_path, 'wb')
            while True:
                chunk = resp.read(CHUNK_SIZE)
                if not chunk:
                    break
                out_f.write(chunk)
            out_f.close()
        dp.close()
        xbmcgui.Dialog().ok("Download complete", f"Saved to:\n{dest_vfs_path}")
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok("Download Failed", str(e))
