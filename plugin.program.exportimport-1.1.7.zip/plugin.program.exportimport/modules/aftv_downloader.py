# aftv_downloader.py — Handles AFTV short code downloads

import os
import re
import urllib.request
import xbmcgui
import xbmcvfs
from urllib.parse import urlsplit, unquote
from modules.utils import _join_path, get_download_folder

CHUNK_SIZE = 1024 * 256  # 256 KB

def install_zip_from_aftv_code():
    dialog = xbmcgui.Dialog()
    code = dialog.input("Enter AFTV Downloader Code (numbers only):", type=xbmcgui.INPUT_NUMERIC)
    if not code:
        return

    short_url = f"https://aftv.news/{code}"
    try:
        req = urllib.request.Request(short_url, headers={"User-Agent": "Mozilla/5.0"})
        html = urllib.request.urlopen(req, timeout=15).read().decode("utf-8", errors="ignore")
        match = re.search(r'URL=(https?://[^"\']+)', html, re.IGNORECASE)
        if not match:
            match = re.search(r'window\.location\s*=\s*["\'](https?://[^"\']+)["\']', html, re.IGNORECASE)
        if not match:
            xbmcgui.Dialog().ok("Error", "Could not find redirect link in AFTV page.")
            return
        final_url = match.group(1).strip()
        download_zip_from_url_with_prefill(final_url)
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Failed to fetch from AFTV: {e}")

def download_zip_from_url_with_prefill(prefill_url):
    save_folder = get_download_folder()
    if not save_folder:
        return
    fname = unquote(os.path.basename(urlsplit(prefill_url).path)) or "download.zip"
    dest_vfs_path = _join_path(save_folder, fname)

    dp = xbmcgui.DialogProgress()
    dp.create("Downloading", fname)
    try:
        req = urllib.request.Request(prefill_url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=45) as resp:
            out_f = xbmcvfs.File(dest_vfs_path, 'wb')
            while True:
                chunk = resp.read(CHUNK_SIZE)
                if not chunk:
                    break
                out_f.write(chunk)
            out_f.close()
        dp.close()
        xbmcgui.Dialog().ok("Download complete", f"Saved to:\n{dest_vfs_path}")
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok("Download Failed", str(e))
