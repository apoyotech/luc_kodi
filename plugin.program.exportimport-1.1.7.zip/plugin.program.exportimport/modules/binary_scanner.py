# modules/binary_scanner.py
import os
import xbmc
import xbmcvfs
import xml.etree.ElementTree as ET

BINARY_FILE = xbmcvfs.translatePath("special://home/userdata/build_binaries.txt")
ADDONS_DIR  = xbmcvfs.translatePath("special://home/addons/")

# IDs that are typically Kodi binary addons
BINARY_ID_PREFIXES = (
    "inputstream.", "pvr.", "audiodecoder.", "audioencoder.",
    "vfs.", "visualization.", "screensaver.", "peripheral.",
)

NATIVE_EXTS = (".so", ".dll", ".dylib")


def _has_native_libs(folder):
    for r, _, files in os.walk(folder):
        for f in files:
            if f.lower().endswith(NATIVE_EXTS):
                return True
    return False


def scan_addons():
    safe, binary = [], []

    for addon_id in os.listdir(ADDONS_DIR):
        addon_path = os.path.join(ADDONS_DIR, addon_id)
        addon_xml  = os.path.join(addon_path, "addon.xml")
        if not os.path.isfile(addon_xml):
            continue

        try:
            # Decide by id prefix OR by actual native libraries inside
            is_binary = addon_id.startswith(BINARY_ID_PREFIXES) or _has_native_libs(addon_path)

            if is_binary:
                binary.append(addon_id)
            else:
                safe.append(addon_id)
        except Exception as e:
            xbmc.log(f"[BinaryScanner] Parse error for {addon_id}: {e}", xbmc.LOGWARNING)

    # Persist binary list for restore
    try:
        if binary:
            with xbmcvfs.File(BINARY_FILE, 'w') as fh:
                fh.write(bytearray(",".join(binary), 'utf-8'))
            xbmc.log(f"[BinaryScanner] Saved build_binaries.txt: {binary}", xbmc.LOGINFO)
        else:
            if xbmcvfs.exists(BINARY_FILE):
                xbmcvfs.delete(BINARY_FILE)
    except Exception as e:
        xbmc.log(f"[BinaryScanner] Failed to write build_binaries.txt: {e}", xbmc.LOGERROR)

    return safe, binary
