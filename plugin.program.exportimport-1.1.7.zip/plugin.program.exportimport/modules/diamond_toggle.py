# modules/diamond_toggle.py
# Toggle Kodi unrestricted mode by enabling/disabling xbmc_env.properties

import os
import xbmc
import xbmcgui

PROPS_FILE = "/storage/emulated/0/xbmc_env.properties"
DISABLED_FILE = "/storage/emulated/0/xbmc_env.properties.disabled"


def get_status():
    """Return current unrestricted mode status: 'on', 'off', or 'missing'."""
    if os.path.exists(PROPS_FILE):
        return "on"
    elif os.path.exists(DISABLED_FILE):
        return "off"
    else:
        return "missing"


def toggle_unrestricted():
    """Flip unrestricted mode ON/OFF by renaming the properties file."""
    dialog = xbmcgui.Dialog()
    status = get_status()

    if status == "on":
        try:
            os.rename(PROPS_FILE, DISABLED_FILE)
            dialog.ok("Diamond/Slick Toggle",
                      "Unrestricted mode is now [COLOR red]OFF[/COLOR].")
            _restart_prompt()
        except Exception as e:
            dialog.ok("Diamond/Slick Toggle", f"Failed to disable unrestricted mode:\n{e}")

    elif status == "off":
        try:
            os.rename(DISABLED_FILE, PROPS_FILE)
            dialog.ok("Diamond/Slick Toggle",
                      "Unrestricted mode is now [COLOR green]ON[/COLOR].")
            _restart_prompt()
        except Exception as e:
            dialog.ok("Diamond/Slick Toggle", f"Failed to enable unrestricted mode:\n{e}")

    else:
        dialog.ok("Diamond/Slick Toggle",
                  "No xbmc_env.properties file found.\nRun Diamond/Slick setup first.")


def _restart_prompt():
    """Ask user to restart Kodi immediately."""
    dialog = xbmcgui.Dialog()
    restart = dialog.yesno("Restart Required",
                           "Changes won’t take effect until Kodi restarts.\n\n"
                           "Restart Kodi now?")
    if restart:
        xbmc.executebuiltin("RestartApp")
