# addons_db_cleaner.py
# Safe cleaning of Kodi's Addons database (works across versions)

import os
import sqlite3
import xbmc
import xbmcgui
import xbmcvfs
import shutil
import json

# 🔹 Always keep these addons safe
PROTECTED = {"plugin.program.exportimport"}

def clean_addons_db():
    try:
        db_path = xbmcvfs.translatePath("special://profile/Database/Addons33.db")
        if not os.path.exists(db_path):
            xbmcgui.Dialog().ok("Add-ons DB Cleaner", "No Addons DB found.")
            return

        # Backup first
        backup_path = db_path + ".bak"
        if not os.path.exists(backup_path):
            shutil.copy2(db_path, backup_path)
            xbmc.log(f"[DBCleaner] Backup created at {backup_path}", xbmc.LOGINFO)

        conn = sqlite3.connect(db_path)
        cur = conn.cursor()

        # Get list of tables
        cur.execute("SELECT name FROM sqlite_master WHERE type='table';")
        tables = {row[0].lower() for row in cur.fetchall()}
        xbmc.log(f"[DBCleaner] Found tables: {tables}", xbmc.LOGINFO)

        # Clean orphaned entries if tables exist
        if "installed" in tables and "addon" in tables:
            cur.execute("""
                DELETE FROM installed
                WHERE addonID NOT IN (SELECT addonID FROM addon);
            """)
        elif "installed" in tables and "addons" in tables:
            cur.execute("""
                DELETE FROM installed
                WHERE addonID NOT IN (SELECT addonID FROM addons);
            """)

        if "repo" in tables:
            if "addon" in tables:
                cur.execute("""
                    DELETE FROM repo
                    WHERE addonID NOT IN (SELECT addonID FROM addon);
                """)
            elif "addons" in tables:
                cur.execute("""
                    DELETE FROM repo
                    WHERE addonID NOT IN (SELECT addonID FROM addons);
                """)

        if "dependencies" in tables:
            if "addon" in tables:
                cur.execute("""
                    DELETE FROM dependencies
                    WHERE addonID NOT IN (SELECT addonID FROM addon);
                """)
            elif "addons" in tables:
                cur.execute("""
                    DELETE FROM dependencies
                    WHERE addonID NOT IN (SELECT addonID FROM addons);
                """)

        conn.commit()
        conn.close()

        xbmcgui.Dialog().notification(
            "Add-ons DB Cleaner",
            "Database cleaned safely. Restart Kodi recommended.",
            xbmcgui.NOTIFICATION_INFO,
            4000
        )
        xbmc.log("[DBCleaner] Addons database cleaned successfully", xbmc.LOGINFO)

        # --- Safety net: re-enable protected addons ---
        for addon_id in PROTECTED:
            xbmc.executeJSONRPC(json.dumps({
                "jsonrpc": "2.0",
                "method": "Addons.SetAddonEnabled",
                "params": {"addonid": addon_id, "enabled": True},
                "id": 1
            }))
        xbmc.log("[DBCleaner] Protected addons re-enabled", xbmc.LOGINFO)

    except Exception as e:
        xbmc.log(f"[DBCleaner] Failed to clean addons DB: {e}", xbmc.LOGERROR)
