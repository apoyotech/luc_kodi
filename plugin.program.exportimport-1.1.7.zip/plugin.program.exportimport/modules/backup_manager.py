# modules/backup_manager.py
# Backup Manager UI + Cleanup
# Matches new installer.py backup layout
# backup_updater/
#   ├─ zips/
#   ├─ folders/
#   └─ file_overwrites/

import os
import shutil
import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon   # ✅ Needed for ADDON.getSettingBool / setSettingBool

ADDON_ID = "plugin.program.exportimport"
ADDON = xbmcaddon.Addon(id=ADDON_ID)


def _home_path(rel=""):
    return xbmcvfs.translatePath(f"special://home/{rel}")


BACKUP_ROOT = _home_path("backup_updater")


def _notify(msg):
    xbmcgui.Dialog().notification("Backup Manager", msg, xbmcgui.NOTIFICATION_INFO, 3000)


def _delete_folder(path):
    try:
        if os.path.exists(path):
            shutil.rmtree(path, ignore_errors=True)
            _notify(f"Deleted: {os.path.basename(path)}")
    except Exception as e:
        xbmcgui.Dialog().ok("Delete Failed", f"Could not delete:\n{path}\n\n{e}")


def delete_backups_menu():
    options = [
        "Delete ALL Backups",
        "Delete ZIP Backups (zips/)",
        "Delete Folder Snapshots (folders/)",
        "Delete File Overwrites (file_overwrites/)",
        "Back"
    ]
    while True:
        sel = xbmcgui.Dialog().select("Delete Backups", options)
        if sel == -1 or sel == len(options) - 1:
            break
        elif sel == 0:
            if xbmcgui.Dialog().yesno("Confirm", "Delete ALL backups?"):
                _delete_folder(BACKUP_ROOT)
        elif sel == 1:
            _delete_folder(os.path.join(BACKUP_ROOT, "zips"))
        elif sel == 2:
            _delete_folder(os.path.join(BACKUP_ROOT, "folders"))
        elif sel == 3:
            _delete_folder(os.path.join(BACKUP_ROOT, "file_overwrites"))


def backup_settings_menu():
    # Read current settings
    backup_enabled = ADDON.getSettingBool("enable_backups")
    custom_path = ADDON.getSettingString("backup_location")

    options = [
        f"Toggle Backups (Currently: {'ON' if backup_enabled else 'OFF'})",
        "Delete Backups...",
        f"Change Backup Location (Current: {custom_path or 'Default'})",
        "Back"
    ]

    while True:
        sel = xbmcgui.Dialog().select("Backup Settings", options)
        if sel == -1 or sel == len(options) - 1:
            break
        elif sel == 0:
            backup_enabled = not backup_enabled
            ADDON.setSettingBool("enable_backups", backup_enabled)
            _notify(f"Backups {'Enabled' if backup_enabled else 'Disabled'}")
        elif sel == 1:
            delete_backups_menu()
        elif sel == 2:
            new_path = xbmcgui.Dialog().browse(3, "Select Backup Location", "files")
            if new_path:
                ADDON.setSettingString("backup_location", new_path)
                _notify(f"Backup path set to:\n{new_path}")


def ensure_backup_root():
    """Make sure backup root exists."""
    if not os.path.exists(BACKUP_ROOT):
        os.makedirs(BACKUP_ROOT, exist_ok=True)
