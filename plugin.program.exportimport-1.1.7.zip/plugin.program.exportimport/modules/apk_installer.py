# modules/apk_installer.py
# APK Installer placeholder: instructs users to install APK manually.

import xbmcgui

def install_apk():
    xbmcgui.Dialog().ok(
        "APK Installer",
        "To install APKs:\n\n"
        "1. Use this add-on to download APK files.\n"
        "2. Open your device's native file manager.\n"
        "3. Tap the downloaded APK to install it.\n\n"
        "Direct installation from Kodi is not supported."
    )
