# modules/binary_repair.py
# Tools to repair broken or missing Kodi binary add-ons
# Force clean + generate build_binaries.txt for auto-reinstall on restart

import os
import xbmc
import xbmcgui
import xbmcvfs
from modules import path_helper

def force_clean_and_repair():
    dialog = xbmcgui.Dialog()

    # Step 0: Confirm before proceeding
    confirm = dialog.yesno(
        "Force Clean Binaries & Repair",
        "This will remove core binary add-ons and rebuild them on restart.\n\n"
        "Removed add-ons: pvr.iptvsimple, inputstream.adaptive, inputstream.rtmp, inputstream.ffmpegdirect.\n\n"
        "[COLOR yellow]You must restart Kodi afterward.[/COLOR]\n\n"
        "Do you want to continue?"
    )
    if not confirm:
        return  # user backed out

    kodi_root = path_helper.kodi_root()
    addons_folder = os.path.join(kodi_root, "addons")
    userdata_folder = path_helper.userdata_path()

    # Addons to remove
    essential_binaries = [
        "pvr.iptvsimple",
        "inputstream.adaptive",
        "inputstream.rtmp",
        "inputstream.ffmpegdirect"
    ]
    
    # Addons to restore (iptvsimple pulls in the rest)
    essential_binaries2 = ["pvr.iptvsimple"]

    # Step 1: Show progress while cleaning
    progress = xbmcgui.DialogProgress()
    progress.create("Force Clean Binaries & Repair", "Cleaning binary add-ons...")
    
    removed = []
    total = len(essential_binaries)
    for i, binary in enumerate(essential_binaries, start=1):
        target = os.path.join(addons_folder, binary)
        if os.path.exists(target):
            try:
                import shutil
                shutil.rmtree(target, ignore_errors=True)
                removed.append(binary)
            except Exception:
                xbmc.log(f"[BinaryRepair] Could not remove {target}", xbmc.LOGWARNING)
        progress.update(int(i * 100 / total), f"Removing: {binary}")
        if progress.iscanceled():
            progress.close()
            return
    progress.close()

    # Step 2: Generate build_binaries.txt
    bin_file = os.path.join(userdata_folder, "build_binaries.txt")
    try:
        with open(bin_file, "w", encoding="utf-8") as f:
            f.write(",".join(sorted(essential_binaries2)))
        xbmc.log(f"[BinaryRepair] build_binaries.txt written with {essential_binaries2}", xbmc.LOGINFO)
    except Exception as e:
        dialog.ok("Binary Repair", f"Failed to create build_binaries.txt:\n{e}")
        return

    # Step 3: Final notification
    msg = []
    if removed:
        msg.append(f"Removed: {', '.join(removed)}")
    msg.append("Repair file created in userdata.\n[COLOR yellow]Restart Kodi to reinstall binaries.[/COLOR]")

    dialog.ok("Force Clean Binaries & Repair", "\n".join(msg))
