# modules/saf_picker.py
# Minimal helpers to use Android's Storage Access Framework (SAF) via Kodi's browser.
# On non-Android, these just fall back to the normal device FS browser.

import xbmc
import xbmcgui

def _is_android():
    try:
        return xbmc.getCondVisibility("system.platform.android")
    except Exception:
        return False

def pick_folder(title):
    """
    Returns a folder URI/path chosen by the user.
    On Android, starts at 'saf://', which triggers the native SAF picker.
    On other platforms, starts at the device filesystem root.
    """
    start = "saf://" if _is_android() else ""
    # browse(type, heading, shares, mask, useThumbs, treatAsFolder, defaultt)
    return xbmcgui.Dialog().browse(0, title, 'files', "", False, True, start)

def pick_file(title, mask=""):
    """
    Returns a file URI/path chosen by the user.
    On Android, uses SAF; elsewhere uses the device filesystem.
    """
    start = "saf://" if _is_android() else ""
    # browse(type=1 -> file)
    return xbmcgui.Dialog().browse(1, title, 'files', mask or "", False, False, start)

def join(folder_uri, name):
    """
    Join a SAF (or normal) folder path with a filename in a Kodi-friendly way.
    For SAF, concatenation with '/' is supported by Kodi's VFS.
    """
    if not folder_uri:
        return ""
    if folder_uri.endswith("/"):
        return folder_uri + name
    return folder_uri + "/" + name
