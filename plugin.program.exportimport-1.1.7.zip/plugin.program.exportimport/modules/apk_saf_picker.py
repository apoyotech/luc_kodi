# modules/saf_picker.py
# SAF-based file/folder picker helpers for Android

import xbmcgui
import xbmcvfs

def pick_file(title="Select a file", file_filter=None):
    """
    Open SAF file picker and return selected file path.
    file_filter: Optional extension filter (".apk", ".zip", etc.)
    """
    dialog = xbmcgui.Dialog()
    path = dialog.browse(1, title, "files")  # 1 = file picker
    if not path:
        return None

    path = xbmcvfs.translatePath(path)

    # If filter provided, ensure correct extension
    if file_filter and not path.lower().endswith(file_filter.lower()):
        dialog.ok("Invalid file", f"Please select a {file_filter} file.")
        return None

    return path


def pick_folder(title="Select a folder"):
    """
    Open SAF folder picker and return selected folder path.
    """
    dialog = xbmcgui.Dialog()
    folder = dialog.browse(3, title, "files")  # 3 = folder picker
    if not folder:
        return None

    return xbmcvfs.translatePath(folder)
