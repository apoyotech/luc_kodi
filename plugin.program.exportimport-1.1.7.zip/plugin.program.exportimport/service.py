import time
import xbmc
from modules import binary_handler

if __name__ == "__main__":
    binary_handler.process_binaries()

    # Wait ~15 seconds so Kodi finishes initializing
    time.sleep(15)

    binary_handler.process_binaries()
