import sys
import requests
from bs4 import BeautifulSoup
import xbmcplugin
import xbmcgui
import xbmc
import io
import re
import urllib.parse

# Verificăm dacă rulăm pe Android
is_android = xbmc.getCondVisibility('System.Platform.Android')

# Importă zstandard doar dacă platforma nu este Android
if not is_android:
    try:
        import zstandard as zstd
    except ImportError:
        zstd = None  # În cazul în care zstandard nu poate fi importat

# Funcția pentru a extrage lista de canale (doar titlul și logo-ul)
def extract_channel_items():
    #url = 'https://rds.live/canale-tv-7/'
    url = 'https://emisiuni.live/canale-tv-1/'
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        #'Referer': 'https://rds.live/',
        'Referer': 'https://emisiuni.live/',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    }

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
    except requests.exceptions.RequestException:
        return []

    response_text = response.text
    soup = BeautifulSoup(response_text, 'html.parser')
    channels = []
    articles = soup.find_all('article', class_='canal')

    for article in articles:
        try:
            title_element = article.find('h2', class_='entry-title')
            title = title_element.text.strip() if title_element else None
            poster_element = article.find('img')
            poster = poster_element['src'] if poster_element else ''
            link_element = article.find('a', class_='post-thumbnail')
            link = link_element['href'] if link_element else ''

            if title:
                channels.append({'title': title, 'poster': poster, 'link': link})
        except Exception:
            continue

    return channels

# Funcția care va adăuga canalele în interfața Kodi
def list_channels():
    channels = extract_channel_items()
    for channel in channels:
        url = f"{sys.argv[0]}?action=play&link={urllib.parse.quote_plus(channel['link'])}"
        list_item = xbmcgui.ListItem(label=channel['title'])

        # Setăm thumb, icon și fundalul fanart.webp pentru fiecare canal
        list_item.setArt({
            'thumb': channel['poster'],
            'icon': channel['poster'],
            'fanart': 'special://home/addons/plugin.video.rdslive/fanart.webp'  # Setează fundalul
        })

        list_item.setProperty('IsPlayable', 'true')  # Marcăm elementul ca redabil
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=list_item, isFolder=False)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))

# Funcția care va extrage URL-ul video și îl va reda
def play_channel(link):
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
        #'Referer': 'https://rds.live/',
        'Referer': 'https://emisiuni.live/',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    }

    try:
        response = requests.get(link, headers=headers)
        response.raise_for_status()
    except requests.exceptions.RequestException:
        return

    soup = BeautifulSoup(response.text, 'html.parser')

    player_element = soup.find(id="player")
    player_id = player_element['data-id'] if player_element else None

    nonce = None
    script_tags = soup.find_all('script')
    for script in script_tags:
        if 'eVariables' in script.text:
            nonce_match = re.search(r'nonce":"(.*?)"', script.text)
            if nonce_match:
                nonce = nonce_match.group(1)
                break

    if player_id and nonce:
        #video_url = get_video_url("https://rds.live/wp-admin/admin-ajax.php", player_id, nonce, link)
        video_url = get_video_url("https://emisiuni.live/wp-admin/admin-ajax.php", player_id, nonce, link)
        if video_url:
            #video_url_with_referer = f"{video_url}|Referer=https://rds.live/"
            video_url_with_referer = f"{video_url}|Referer=https://emisiuni.live/"
            list_item = xbmcgui.ListItem(path=video_url_with_referer)
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, list_item)

# Funcția pentru a obține URL-ul video
def get_video_url(ajax_url, player_id, nonce, referer_url):
    post_data = {
        'action': 'show_player',
        'id': player_id,
        'nonce': nonce
    }

    headers = {
        'accept': '*/*',
        'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
        #'origin': 'https://rds.live',
        'origin': 'https://emisiuni.live',
        'referer': referer_url,
        'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
        'x-requested-with': 'XMLHttpRequest',
    }

    try:
        response = requests.post(ajax_url, data=post_data, headers=headers)
        response.raise_for_status()
    except requests.exceptions.RequestException:
        return None

    response_text = response.text  # Fallback implicit

    # Decompresie doar dacă nu suntem pe Android și header-ul conține zstd
    if not is_android and zstd and 'zstd' in response.headers.get('Content-Encoding', ''):
        try:
            dctx = zstd.ZstdDecompressor()
            stream = io.BytesIO(response.content)
            with dctx.stream_reader(stream) as reader:
                decompressed = reader.read()
            response_text = decompressed.decode('utf-8')
        except zstd.ZstdError:
            pass

    soup = BeautifulSoup(response_text, 'html.parser')
    script_tags = soup.find_all('script')
    for script in script_tags:
        if 'videojs' in script.text:
            start = script.text.find("src: '") + len("src: '")
            end = script.text.find("'", start)
            return script.text[start:end]

    return None

# Funcția principală pentru a gestiona acțiunile
def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    if params and 'action' in params:
        if params['action'] == 'play':
            play_channel(params['link'])
    else:
        list_channels()

# Main entry point
if __name__ == '__main__':
    router(sys.argv[2][1:])
