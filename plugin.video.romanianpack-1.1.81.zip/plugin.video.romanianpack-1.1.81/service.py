# -*- coding: utf-8 -*-
from resources.lib import mrspservice

mrspservice.run()
