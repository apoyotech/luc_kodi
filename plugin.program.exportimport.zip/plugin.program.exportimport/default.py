# -*- coding: utf-8 -*-
# default.py — File Import/Export + Download ZIP from Direct URL or AFTV Code
import os
import shutil
import re
import urllib.request
import urllib.error
import xbmc
import xbmcgui
import xbmcvfs

CHUNK_SIZE = 1024 * 128  # 128 KB

# ---------- Helpers ----------

def _copy_vfs(src_path, dst_path):
    """Copy using xbmcvfs, fallback to stream copy via xbmcvfs.File for VFS safety."""
    try:
        if xbmcvfs.copy(src_path, dst_path):
            return True
    except Exception:
        pass
    # Manual stream copy (works across VFS)
    try:
        src_f = xbmcvfs.File(src_path, 'rb')
        try:
            dst_f = xbmcvfs.File(dst_path, 'wb')
            try:
                while True:
                    chunk = src_f.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    dst_f.write(chunk)
            finally:
                dst_f.close()
        finally:
            src_f.close()
        return True
    except Exception:
        return False

def _join_path(folder, name):
    # Ensure a single slash between folder and file, regardless of VFS
    if folder.endswith('/'):
        return folder + name
    return folder + '/' + name

# ---------- Browsers (use positional args; 7th arg is defaultt) ----------

def browse_file_kodi_root(title):
    # type=1 (files), shares='files', defaultt='special://home/'
    return xbmcgui.Dialog().browse(1, title, 'files', '', False, False, 'special://home/')

def browse_folder_kodi_root(title):
    # type=0 (folders), shares='files', defaultt='special://home/'
    return xbmcgui.Dialog().browse(0, title, 'files', '', False, True, 'special://home/')

def browse_file_device_fs(title):
    # type=1 (files), shares='files', defaultt='' -> top-level shares (device FS / USB / network)
    return xbmcgui.Dialog().browse(1, title, 'files', '', False, False, '')

def browse_folder_device_fs(title):
    # type=0 (folders), shares='files', defaultt='' -> top-level shares (device FS / USB / network)
    return xbmcgui.Dialog().browse(0, title, 'files', '', False, True, '')

# ---------- Actions ----------

def export_file():
    # Pick a source FROM Kodi root
    src = browse_file_kodi_root("Select file to export (Kodi root)")
    if not src:
        xbmcgui.Dialog().notification("Export", "No source selected", xbmcgui.NOTIFICATION_INFO, 2500)
        return

    # Pick destination IN device filesystem
    dst_folder = browse_folder_device_fs("Select destination folder (device filesystem)")
    if not dst_folder:
        xbmcgui.Dialog().notification("Export", "No destination selected", xbmcgui.NOTIFICATION_INFO, 2500)
        return

    dst = _join_path(dst_folder, os.path.basename(src))

    if xbmcvfs.exists(dst):
        if not xbmcgui.Dialog().yesno("Overwrite?", f"{dst}\nexists. Overwrite?"):
            xbmcgui.Dialog().notification("Export", "Canceled", xbmcgui.NOTIFICATION_INFO, 2000)
            return

    if _copy_vfs(src, dst):
        xbmcgui.Dialog().ok("Export", f"Exported to:\n{dst}")
    else:
        xbmcgui.Dialog().ok("Export Failed", "Could not copy file.")

def import_file():
    # Pick a source FROM device filesystem
    src = browse_file_device_fs("Select file to import (device filesystem)")
    if not src:
        xbmcgui.Dialog().notification("Import", "No source selected", xbmcgui.NOTIFICATION_INFO, 2500)
        return

    # Pick destination IN Kodi root
    dst_folder = browse_folder_kodi_root("Select destination folder (Kodi root)")
    if not dst_folder:
        xbmcgui.Dialog().notification("Import", "No destination selected", xbmcgui.NOTIFICATION_INFO, 2500)
        return

    dst = _join_path(dst_folder, os.path.basename(src))

    # Ensure destination folder exists
    if not xbmcvfs.exists(dst_folder):
        xbmcvfs.mkdirs(dst_folder)

    if xbmcvfs.exists(dst):
        if not xbmcgui.Dialog().yesno("Overwrite?", f"{dst}\nexists. Overwrite?"):
            xbmcgui.Dialog().notification("Import", "Canceled", xbmcgui.NOTIFICATION_INFO, 2000)
            return

    if _copy_vfs(src, dst):
        xbmcgui.Dialog().ok("Import", f"Imported to:\n{dst}")
    else:
        xbmcgui.Dialog().ok("Import Failed", "Could not copy file.")

def download_zip_from_url():
    # Ask for URL
    url = xbmcgui.Dialog().input("Enter ZIP URL (http/https/ftp)")
    if not url:
        xbmcgui.Dialog().notification("Download", "No URL entered", xbmcgui.NOTIFICATION_INFO, 2000)
        return
    if not (url.lower().startswith('http://') or url.lower().startswith('https://') or url.lower().startswith('ftp://')):
        xbmcgui.Dialog().ok("Invalid URL", "Enter a valid http/https/ftp URL to a ZIP file.")
        return

    # Pick save folder IN device filesystem
    save_folder = browse_folder_device_fs("Select folder to save ZIP (device filesystem)")
    if not save_folder:
        xbmcgui.Dialog().notification("Download", "No folder selected", xbmcgui.NOTIFICATION_INFO, 2000)
        return

    # Derive filename from URL
    try:
        from urllib.parse import urlsplit, unquote
        fname = unquote(os.path.basename(urlsplit(url).path)) or "download.zip"
    except Exception:
        fname = "download.zip"

    dest_vfs_path = _join_path(save_folder, fname)

    if xbmcvfs.exists(dest_vfs_path):
        if not xbmcgui.Dialog().yesno("Overwrite?", f"{dest_vfs_path}\nexists. Overwrite?"):
            xbmcgui.Dialog().notification("Download", "Canceled", xbmcgui.NOTIFICATION_INFO, 2000)
            return

    # Use DialogProgress
    dp = xbmcgui.DialogProgress()
    dp.create("Downloading", fname)

    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0 (Kodi Addon)'})
        with urllib.request.urlopen(req, timeout=45) as resp:
            total = resp.getheader('Content-Length')
            total = int(total) if total else None

            # Write via xbmcvfs.File to support VFS destinations
            out_f = xbmcvfs.File(dest_vfs_path, 'wb')
            try:
                downloaded = 0
                while True:
                    chunk = resp.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    out_f.write(chunk)
                    downloaded += len(chunk)
                    if total:
                        pct = max(0, min(100, int(downloaded * 100 / total)))
                        dp.update(pct, f"{downloaded//1024} KB of {total//1024} KB")
                    else:
                        dp.update((downloaded // (256*1024)) % 100, f"{downloaded//1024} KB")
                    if dp.iscanceled():
                        dp.close()
                        out_f.close()
                        xbmcvfs.delete(dest_vfs_path)
                        xbmcgui.Dialog().notification("Download", "Canceled", xbmcgui.NOTIFICATION_INFO, 2000)
                        return
            finally:
                out_f.close()

        dp.close()
        xbmcgui.Dialog().ok("Download complete", f"Saved to:\n{dest_vfs_path}")
    except urllib.error.HTTPError as e:
        dp.close()
        xbmcgui.Dialog().ok("Download Failed", f"HTTP {e.code} {e.reason}")
    except urllib.error.URLError as e:
        dp.close()
        xbmcgui.Dialog().ok("Download Failed", f"URL Error: {e.reason}")
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok("Download Failed", str(e))

def install_zip_from_aftv_code():
    dialog = xbmcgui.Dialog()
    code = dialog.input("Enter AFTV Downloader Code (numbers only):", type=xbmcgui.INPUT_NUMERIC)
    if not code:
        return

    short_url = f"https://aftv.news/{code}"

    try:
        # Step 1: Fetch HTML with a browser-like User-Agent
        req = urllib.request.Request(short_url, headers={"User-Agent": "Mozilla/5.0"})
        html = urllib.request.urlopen(req, timeout=15).read().decode("utf-8", errors="ignore")

        # Step 2: Look for meta refresh redirect
        match = re.search(r'URL=(https?://[^"\']+)', html, re.IGNORECASE)
        if not match:
            # Look for JS redirect
            match = re.search(r'window\.location\s*=\s*["\'](https?://[^"\']+)["\']', html, re.IGNORECASE)

        if not match:
            xbmcgui.Dialog().ok("Error", "Could not find redirect link in AFTV page.")
            return

        final_url = match.group(1).strip()

        # Step 3: Send final URL to your working download_zip_from_url logic
        download_zip_from_url_with_prefill(final_url)

    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Failed to fetch from AFTV: {e}")

def download_zip_from_url_with_prefill(prefill_url):
    # Pick save folder IN device filesystem
    save_folder = browse_folder_device_fs("Select folder to save ZIP (device filesystem)")
    if not save_folder:
        xbmcgui.Dialog().notification("Download", "No folder selected", xbmcgui.NOTIFICATION_INFO, 2000)
        return

    # Derive filename from URL
    from urllib.parse import urlsplit, unquote
    fname = unquote(os.path.basename(urlsplit(prefill_url).path)) or "download.zip"
    dest_vfs_path = _join_path(save_folder, fname)

    if xbmcvfs.exists(dest_vfs_path):
        if not xbmcgui.Dialog().yesno("Overwrite?", f"{dest_vfs_path}\nexists. Overwrite?"):
            xbmcgui.Dialog().notification("Download", "Canceled", xbmcgui.NOTIFICATION_INFO, 2000)
            return

    dp = xbmcgui.DialogProgress()
    dp.create("Downloading", fname)

    try:
        req = urllib.request.Request(prefill_url, headers={'User-Agent': 'Mozilla/5.0 (Kodi Addon)'})
        with urllib.request.urlopen(req, timeout=45) as resp:
            total = resp.getheader('Content-Length')
            total = int(total) if total else None

            out_f = xbmcvfs.File(dest_vfs_path, 'wb')
            try:
                downloaded = 0
                while True:
                    chunk = resp.read(CHUNK_SIZE)
                    if not chunk:
                        break
                    out_f.write(chunk)
                    downloaded += len(chunk)
                    if total:
                        pct = max(0, min(100, int(downloaded * 100 / total)))
                        dp.update(pct, f"{downloaded//1024} KB of {total//1024} KB")
                    else:
                        dp.update((downloaded // (256*1024)) % 100, f"{downloaded//1024} KB")
                    if dp.iscanceled():
                        dp.close()
                        out_f.close()
                        xbmcvfs.delete(dest_vfs_path)
                        xbmcgui.Dialog().notification("Download", "Canceled", xbmcgui.NOTIFICATION_INFO, 2000)
                        return
            finally:
                out_f.close()

        dp.close()
        xbmcgui.Dialog().ok("Download complete", f"Saved to:\n{dest_vfs_path}")
    except Exception as e:
        dp.close()
        xbmcgui.Dialog().ok("Download Failed", str(e))

# ---------- Menu ----------

def main():
    options = [
        "Export ZIP/File (Kodi root → device fs)",
        "Import ZIP/File (device fs → Kodi root)",
        "Download ZIP from URL",
        "Download ZIP from AFTV Downloader Code",
        "Exit"
    ]
    while True:
        sel = xbmcgui.Dialog().select("File Import/Export", options)
        if sel == 0:
            export_file()
        elif sel == 1:
            import_file()
        elif sel == 2:
            download_zip_from_url()
        elif sel == 3:
            install_zip_from_aftv_code()  
        else:
            break

if __name__ == '__main__':
    main()
