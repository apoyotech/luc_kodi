## Theme for Seren & Estuary users
SmartPlay PopUp             
![nextup up popup](https://i.imgur.com/EXdfNvu.jpg)

##### Requirements
* Seren - 2.x or greater
* Estuary 

**This theme has not been tested thoroughly and is not supported on any skin besides Estuary at the current time , use at your own risk with other skins.**

*The text color for this theme is controlled by "Select Text Highlight Color..." in Seren > Settings > Interface*

-----------

##### To install this theme in Seren, navigate to:

`Seren -> Tools > Open Settings Menu -> Theme Manager -> Interface > (themes section) Install Theme -> Web Location`

And enter the following URL:

https://www.github.com/inb4after/DefaultMod-Full/zipball/master/

------------


You can also download the `.zip` file directly from the same URL, and install it from:

`Seren -> Tools > Open Settings Menu -> Theme Manager -> Interface > (themes section) Install Theme ->  Browse`

------------




*The creator of this theme is not affiliated with Seren, Estuary, or Kodi.*
