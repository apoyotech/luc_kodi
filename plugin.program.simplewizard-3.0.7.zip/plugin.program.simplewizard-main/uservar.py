'''#####-----Build File-----#####'''
buildfile = 'http://CHANGEME'

'''#####-----Videos File-----#####'''
videos_url = 'http://CHANGEME'

'''#####-----Notifications File-----#####'''
notify_url  = 'http://CHANGEME'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
