# -*- coding: utf-8 -*-
"""
	luc_kodi Add-on — system_status.py (v2.0.12)

	System status: a page of the plugin's own context panel (and of Settings)
	with four blocks, all on one screen.

	  LIVE · DEVICE   RAM in use, screen and refresh rate. Read once a second
	                  from Kodi's own infolabels while the page is open (the
	                  same System.Memory / System.ScreenResolution labels that
	                  device_profile.py and display_test.py already trust), and
	                  only while it is open: nothing runs in the background.
	                  No CPU: on Android an app cannot read /proc/stat since
	                  Android 8, so Kodi reports 0 % there and a 0 that looks
	                  like a value is worse than no tile at all.

	  ACCOUNTS        only the services that are switched on and signed in, as
	                  their logo with a dot: green = fine, orange = needs
	                  attention. A line below explains the orange ones, and it
	                  only exists when there is something to say:
	                    debrid    subscription ending in 7 days or less, or ended
	                    trackers  the session needs signing in again (the same
	                              marks trakt/simkl/wetrakr/punchplay already
	                              set when their refresh token dies)

	  APIS            the metadata and service APIs the plugin is using right
	                  now (TMDb, TheTVDB, Fanart.tv, Trakt, and OMDb, MDBList,
	                  Gemini, OpenSubtitles, TheIntroDB and JustWatch when they
	                  are switched on or have a key), each asked for one cheap
	                  thing with the key the plugin itself uses. Keys never
	                  reach the log or the page.
	                    green   answered, in normal time
	                    orange  answered but refused the key (401/403), is
	                            limiting us (429) or took over 5 s
	                    red     no answer, or a server error (5xx)

	  SCRAPERS        a test of the ENABLED providers, only when the user asks
	                  for it (Check again), never on opening: opening a menu
	                  must not cost requests to every provider. It is the same
	                  machinery as provider_test.py (_run_one: configured,
	                  reachable, results, time), with its lock and its cooldown,
	                  so the two tests never overlap. Against one fixed, very
	                  popular movie: if a provider returns nothing for it, the
	                  problem is the provider, not the catalogue.
	                    green   results, in normal time
	                    orange  answered but something is off: 0 results, slow
	                            (over 15 s) or credentials missing
	                    red     did not work: no answer from the host, an error,
	                            or still nothing after 120 s
	                  The last result stays in a window property, so the page
	                  shows it again (with its time) until Kodi restarts.

	The debrid expiry dates and the update check are network calls too: they
	run in a background thread after the page is drawn and are kept for 6 hours;
	Check again refreshes them.
"""

import json
import re
import threading
import time

import xbmc

from resources.lib.modules import control
from resources.lib.modules import log_utils

LOGINFO = log_utils.LOGINFO

GREEN, ORANGE, RED, GREY = 'FF00D488', 'FFFFAA44', 'FFFF6B6B', 'FF9A9AC4'
EXPIRY_DAYS = 7         # warn when a subscription ends in this many days or less
SLOW_SECONDS = 15.0     # a provider slower than this is flagged
TEST_DEADLINE = 120     # seconds; still running after this = no answer
CACHE_TTL = 6 * 3600    # debrid expiry dates and update check
MAX_SLOTS = 10          # account logos (5 trackers + 4 debrid + Easynews)

PROP_DEBRID = 'luc_kodi.status.debrid'
PROP_UPDATE = 'luc_kodi.status.update'
PROP_SCRAPERS = 'luc_kodi.status.scrapers'
PROP_APIS = 'luc_kodi.status.apis'
API_TIMEOUT = 8         # seconds per API
SLOW_API = 5.0          # an API slower than this is flagged

# One fixed, very popular movie: see the docstring.
TEST_TITLE = {'imdb': 'tt0468569', 'title': 'The Dark Knight', 'year': '2008', 'aliases': [], 'localtitle': ''}
# library = the user's own Kodi library, not a scraper. Languages-only helpers are
# skipped by their flag (they only search titles opened from Languages).
EXCLUDE = ('library',)

# (key, name, logo, token setting, isauthed setting, window property set when the session died)
TRACKERS = (
	('trakt', 'Trakt', 'trakt', 'trakt.token', 'trakt.isauthed', 'luc_kodi.trakt.reauth_notice'),
	('simkl', 'SIMKL', 'simkl', 'simkl.token', 'simkl.isauthed', 'luc_kodi.simkl.reauth_notify'),
	('mdblist', 'MDBList', 'mdblist', '', '', ''),
	('wetrakr', 'WeTrakr', 'wetrakr', 'wetrakr.token', 'wetrakr.isauthed', 'luc_kodi.wetrakr.reauth'),
	('punchplay', 'PunchPlay', 'punchplay', 'punchplay.token', 'punchplay.isauthed', 'luc_kodi.punchplay.reauth'),
)
DEBRIDS = (
	('realdebrid', 'Real-Debrid', 'realdebrid'),
	('premiumize', 'Premiumize', 'premiumize'),
	('alldebrid', 'AllDebrid', 'alldebrid'),
	('torbox', 'TorBox', 'torbox'),
)

NAMES = {
	'aiostreams': 'AIOStreams', 'comet': 'Comet', 'dmm': 'DMM', 'easynews': 'Easynews',
	'knaben': 'Knaben', 'mediafusion': 'MediaFusion', 'meteor': 'Meteor', 'newznab': 'Newznab',
	'orion': 'Orion', 'peerflix': 'Peerflix', 'piratebay': 'The Pirate Bay', 'sootio': 'Sootio',
	'torboxnews': 'TorBox Search', 'torrentio': 'Torrentio', 'torrentio_spanish': 'Torrentio ES',
	'torrentsdb': 'TorrentsDB', 'torz': 'Torz', 'zilean': 'Zilean',
}


def _log(msg):
	control.log('[ luc_kodi ] system_status: %s' % msg, LOGINFO)


def L(sid):
	return control.lang(sid)


def display_name(name):
	return NAMES.get(name) or name.replace('_', ' ').title()


def _get(sid):
	try: return (control.setting(sid) or '').strip()
	except Exception: return ''


def _read_cache(prop, ttl=None):
	try:
		raw = control.homeWindow.getProperty(prop)
		data = json.loads(raw) if raw else None
	except Exception:
		data = None
	if not isinstance(data, dict): return None
	if ttl and (time.time() - float(data.get('ts') or 0)) > ttl: return None
	return data


def _write_cache(prop, data):
	try:
		data = dict(data)
		data['ts'] = time.time()
		control.homeWindow.setProperty(prop, json.dumps(data))
	except Exception:
		log_utils.error()


# ───────────────────────── device ─────────────────────────
def _fmt_hz(hz):
	return ('%d Hz' % int(round(hz))) if abs(hz - round(hz)) < 0.005 else ('%.2f Hz' % hz)


def device_snapshot():
	"""RAM, screen and refresh, formatted for the three tiles."""
	from resources.lib.modules import device_profile, display_test
	out = {'ram': '-', 'ram2': '', 'ram_pct': 0, 'screen': '-', 'screen2': '', 'aspect': '', 'refresh': '-', 'refresh2': ''}
	try:
		total = device_profile._mb(xbmc.getInfoLabel('System.Memory(total)'))
		used = device_profile._mb(xbmc.getInfoLabel('System.Memory(used)'))
		if not used and total:
			free = device_profile._mb(xbmc.getInfoLabel('System.FreeMemory'))
			used = max(0, total - free) if free else 0
		if total:
			out['ram_pct'] = max(0, min(100, int(round(used * 100.0 / total))))
			if total >= 1024:
				out['ram'], out['ram2'] = '%.2f GB' % (used / 1024.0), L(48185) % ('%.2f GB' % (total / 1024.0))
			else:
				out['ram'], out['ram2'] = '%d MB' % used, L(48185) % ('%d MB' % total)
	except Exception:
		log_utils.error()
	try:
		w, h, raw = display_test._physical_mode()
		gw, gh = display_test._gui_size()
		if w and h:
			out['screen'] = '%d×%d' % (w, h)
			aspect, is_169 = display_test._aspect(w, h)
			# the aspect ratio goes next to the tile caption, and only when it is not 16:9
			out['aspect'] = '' if is_169 else aspect
			if gw and gh: out['screen2'] = L(48180) % ('%d×%d' % (gw, gh))
		# Only the display's own rate. Not System.FPS: Kodi stops redrawing what
		# has not changed, so an idle menu reads 12 fps on a 120 Hz panel and
		# looks like a fault that is not there (seen on the tablet, 2.0.12).
		m = re.search(r'@\s*([\d.]+)\s*Hz', raw or '', re.I)
		if m: out['refresh'] = _fmt_hz(float(m.group(1)))
		# Kodi's own words for the mode: Full Screen / Windowed
		mode = re.search(r'-\s*([^-@]+?)\s*$', raw or '')
		if mode and not re.search(r'\d', mode.group(1)): out['refresh2'] = mode.group(1)
	except Exception:
		log_utils.error()
	return out


def header_info():
	from resources.lib.modules import device_profile
	friendly = (xbmc.getInfoLabel('System.FriendlyName') or '').strip()
	m = re.match(r'^Kodi \((.+)\)$', friendly)   # Kodi's default name is "Kodi (<device>)"
	if m: friendly = m.group(1).strip()
	try: ver = (control.getKodiVersion(full=True) or '').split()[0]
	except Exception: ver = ''
	kodi = ('Kodi %s' % ver) if ver else 'Kodi'
	meta = ('%s · %s' % (friendly, kodi)) if friendly else kodi
	try:
		profile = control.homeWindow.getProperty(device_profile.PROP) or device_profile.detect()[0]
	except Exception:
		profile = ''
	# only when it says something: the low memory profile trims the plugin's caches
	profile = L(48160) if profile == 'low' else ''
	try: version = 'v%s' % control.addon('plugin.video.luc_kodi').getAddonInfo('version')
	except Exception: version = ''
	return {'meta': meta, 'profile': profile, 'version': version}


# ───────────────────────── accounts ─────────────────────────
def _tracker_active(key, token_id):
	if key == 'mdblist':
		# OAuth token or the user's OWN API key: the key built into the plugin is
		# not an account of the user's.
		try:
			from resources.lib.modules import mdblist
			if mdblist.oauthActive(): return True
		except Exception:
			pass
		return bool(_get('mdblist.apikey'))
	return bool(_get(token_id))


def _expiry_message(name, days):
	if days is None or days > EXPIRY_DAYS: return ''
	if days < 0: return L(48168) % name
	if days == 0: return L(48165) % name
	if days == 1: return L(48166) % name
	return L(48167) % (name, days)


def accounts(debrid_days=None):
	"""-> [{'key','name','logo','dot','message'}] for the ACTIVE services only."""
	debrid_days = debrid_days or {}
	out = []
	for key, name, logo, token_id, authed_id, dead_prop in TRACKERS:
		if not _tracker_active(key, token_id): continue
		message = ''
		dead = False
		try: dead = bool(dead_prop and control.homeWindow.getProperty(dead_prop))
		except Exception: pass
		if dead or (authed_id and _get(authed_id) == 'false'):
			message = L(48169) % name
		out.append({'key': key, 'name': name, 'logo': 'ctx/logo_%s.png' % logo,
					'dot': ORANGE if message else GREEN, 'message': message})
	for key, name, logo in DEBRIDS:
		if _get('%s.enable' % key) != 'true' or not _get('%s.token' % key): continue
		message = _expiry_message(name, debrid_days.get(key))
		out.append({'key': key, 'name': name, 'logo': 'ctx/logo_%s.png' % logo,
					'dot': ORANGE if message else GREEN, 'message': message})
	if _get('easynews.username') and _get('easynews.password'):
		out.append({'key': 'easynews', 'name': 'Easynews', 'logo': 'ctx/logo_easynews.png', 'dot': GREEN, 'message': ''})
	return out[:MAX_SLOTS]


def warnings(accts):
	"""At most two lines. A third and later problems share the second line."""
	msgs = [a for a in accts if a['message']]
	if len(msgs) <= 2: return [a['message'] for a in msgs]
	rest = [a['name'] for a in msgs[1:]]
	return [msgs[0]['message'], L(48170) % (', '.join(rest[:-1]), rest[-1])]


def _days_left(key):
	"""Days of subscription left, -1 when it has ended, None when unknown."""
	from datetime import datetime
	today = datetime.today().date()
	if key == 'realdebrid':
		from resources.lib.debrid.realdebrid import RealDebrid
		info = RealDebrid().account_info() or {}
		if not info: return None
		if str(info.get('type', '')).lower() != 'premium': return -1
		return int(int(info.get('premium') or 0) / 86400)
	if key == 'premiumize':
		from resources.lib.debrid.premiumize import Premiumize
		info = Premiumize().account_info() or {}
		until = info.get('premium_until')
		if until in (None, ''): return None
		if not until: return -1
		return (datetime.fromtimestamp(int(until)).date() - today).days
	if key == 'alldebrid':
		from resources.lib.debrid.alldebrid import AllDebrid
		info = (AllDebrid().account_info() or {}).get('user') or {}
		if not info: return None
		if not info.get('isPremium'): return -1
		until = int(info.get('premiumUntil') or 0)
		return (datetime.fromtimestamp(until).date() - today).days if until else None
	if key == 'torbox':
		from resources.lib.debrid.torbox import TorBox
		info = ((TorBox().account_info() or {}).get('data')) or {}
		stamp = str(info.get('premium_expires_at') or '')[:10]
		if not stamp: return None
		return (datetime.strptime(stamp, '%Y-%m-%d').date() - today).days
	return None


def debrid_days(force=False):
	"""{service: days} for the active debrid accounts, cached CACHE_TTL. Each
	account is asked in its own thread; an account that does not answer is left
	out (unknown is not a reason to paint it orange)."""
	cached = None if force else _read_cache(PROP_DEBRID, CACHE_TTL)
	active = [k for k, n, l in DEBRIDS if _get('%s.enable' % k) == 'true' and _get('%s.token' % k)]
	if cached is not None and sorted(cached.get('keys') or []) == sorted(active):
		return cached.get('days') or {}
	days = {}

	def ask(key):
		try:
			value = _days_left(key)
			if value is not None: days[key] = value
		except Exception:
			log_utils.error()
	threads = [threading.Thread(target=ask, args=(k,)) for k in active]
	for t in threads: t.start()
	for t in threads: t.join(20)
	_write_cache(PROP_DEBRID, {'keys': active, 'days': days})
	if days: _log('debrid days left %s' % json.dumps(days, sort_keys=True))
	return days


def update_label(force=False):
	"""'Up to date' / 'Update X ready', or '' when the channel did not answer."""
	cached = None if force else _read_cache(PROP_UPDATE, CACHE_TTL)
	if cached is not None: return cached.get('label') or ''
	label = ''
	try:
		from resources.lib.modules import updater
		manifest = updater.fetch_manifest()
		if manifest:
			if updater.is_newer(manifest['version'], updater.installed_version()):
				label = L(48164) % manifest['version']
			else:
				label = L(48163)
	except Exception:
		log_utils.error()
	_write_cache(PROP_UPDATE, {'label': label})
	return label


def layout_key(accts, warns):
	if not accts: return 'n'
	return 'a%d' % min(2, len(warns))



# ───────────────────────── APIs ─────────────────────────
def _ua():
	try: return 'luc_kodi/%s (Kodi)' % control.addonInfo('version')
	except Exception: return 'luc_kodi (Kodi)'


def _req(method, url, **kw):
	import requests
	kw.setdefault('timeout', API_TIMEOUT)
	headers = kw.pop('headers', {}) or {}
	headers.setdefault('User-Agent', _ua())
	return requests.request(method, url, headers=headers, **kw)


def _api_tmdb():
	from resources.lib.modules import app_keys
	key = _get('tmdb.api.key') or app_keys.get('tmdb')
	return _req('GET', 'https://api.themoviedb.org/3/configuration', params={'api_key': key}).status_code


def _api_tvdb():
	from resources.lib.modules import tvdb
	key, pin = tvdb._credentials()
	payload = {'apikey': key}
	if pin: payload['pin'] = pin
	return _req('POST', '%s/login' % tvdb.API, json=payload).status_code


def _api_fanart():
	from resources.lib.modules import app_keys
	headers = {'api-key': app_keys.get('fanart')}
	if _get('fanart_tv.api_key'): headers['client-key'] = _get('fanart_tv.api_key')
	return _req('GET', 'https://webservice.fanart.tv/v3/movies/155', headers=headers).status_code


def _api_trakt():
	from resources.lib.modules import trakt
	cid = trakt._app_credentials()[0]
	headers = {'trakt-api-version': '2', 'trakt-api-key': cid, 'Content-Type': 'application/json'}
	return _req('GET', 'https://api.trakt.tv/movies/the-dark-knight-2008', headers=headers).status_code


def _api_omdb():
	r = _req('GET', 'https://www.omdbapi.com/', params={'i': TEST_TITLE['imdb'], 'apikey': _get('omdb.apikey')})
	if r.status_code == 200:
		try:
			data = r.json()
			if str(data.get('Response')) != 'True' and 'key' in str(data.get('Error', '')).lower(): return 401
		except Exception:
			pass
	return r.status_code


def _api_mdblist():
	from resources.lib.modules import mdblist
	if mdblist.oauthActive():
		return _req('GET', mdblist.BASE_URL + '/user', headers={'Authorization': 'Bearer %s' % mdblist.getOAuthToken()}).status_code
	return _req('GET', mdblist.BASE_URL + '/user', params={'apikey': _get('mdblist.apikey')}).status_code


def _api_gemini():
	from resources.lib.modules import gemini_api
	keys = gemini_api.gemini_api_keys()
	return _req('GET', 'https://generativelanguage.googleapis.com/v1beta/models', params={'pageSize': 1},
				headers={'x-goog-api-key': keys[0]}).status_code


def _api_opensubs():
	from resources.lib.modules import app_keys
	return _req('GET', 'https://api.opensubtitles.com/api/v1/infos/formats',
				headers={'Api-Key': app_keys.get('opensubs'), 'User-Agent': 'luc_kodi v%s' % control.addonInfo('version')}).status_code


def _api_introdb():
	from resources.lib.modules import skip_intro
	headers = {'Accept': 'application/json', 'User-Agent': skip_intro.USER_AGENT}
	if _get('tidb.api.key'): headers['Authorization'] = 'Bearer %s' % _get('tidb.api.key')
	code = _req('GET', skip_intro._build_url(None, 155, None, None, True), headers=headers).status_code
	return 200 if code == 404 else code   # 404 = answered: that title is not in its database


def _api_justwatch():
	from resources.lib.indexers import justwatch
	return _req('POST', justwatch._JW_GRAPHQL_URL, headers=dict(justwatch._JW_HEADERS), json={'query': '{ __typename }'}).status_code


def _gemini_on():
	try:
		from resources.lib.modules import gemini_api
		return bool(gemini_api.gemini_api_keys())
	except Exception:
		return False


def _mdblist_on():
	try:
		from resources.lib.modules import mdblist
		return mdblist.oauthActive() or bool(_get('mdblist.apikey'))
	except Exception:
		return False


# (key, name, test, active?) -- in the order they are shown
APIS = (
	('tmdb', 'TMDb', _api_tmdb, lambda: True),
	('tvdb', 'TheTVDB', _api_tvdb, lambda: True),
	('fanart', 'Fanart.tv', _api_fanart, lambda: _get('enable.fanarttv') != 'false'),
	('trakt', 'Trakt', _api_trakt, lambda: True),
	('omdb', 'OMDb', _api_omdb, lambda: bool(_get('omdb.apikey'))),
	('mdblist', 'MDBList', _api_mdblist, _mdblist_on),
	('gemini', 'Gemini', _api_gemini, _gemini_on),
	('opensubs', 'OpenSubtitles', _api_opensubs, lambda: _get('subtitles') == 'true'),
	('introdb', 'TheIntroDB', _api_introdb, lambda: _get('skipintro.enabled') == 'true'),
	('justwatch', 'JustWatch', _api_justwatch, lambda: _get('streaming.use_justwatch') == 'true'),
)


def active_apis():
	out = []
	for key, name, fn, on in APIS:
		try:
			if on(): out.append((key, name, fn))
		except Exception:
			pass
	return out


def api_view(code, elapsed):
	"""HTTP status (None = no answer) -> what the list shows."""
	took = '%.1f s' % elapsed
	if code is None:
		return {'state': 'fail', 'dot': RED, 'note': L(48177), 'notecolor': RED, 'value': L(48176)}
	if code >= 500:
		return {'state': 'fail', 'dot': RED, 'note': 'HTTP %d' % code, 'notecolor': RED, 'value': took}
	if code in (401, 403):
		return {'state': 'warn', 'dot': ORANGE, 'note': L(48189), 'notecolor': ORANGE, 'value': took}
	if code == 429:
		return {'state': 'warn', 'dot': ORANGE, 'note': L(48190), 'notecolor': ORANGE, 'value': took}
	if code >= 400:
		return {'state': 'warn', 'dot': ORANGE, 'note': 'HTTP %d' % code, 'notecolor': ORANGE, 'value': took}
	if elapsed > SLOW_API:
		return {'state': 'warn', 'dot': ORANGE, 'note': L(48175), 'notecolor': ORANGE, 'value': took}
	return {'state': 'ok', 'dot': GREEN, 'note': 'OK', 'notecolor': GREY, 'value': took}


def run_api_test(apis=None, on_row=None, on_done=None):
	"""Ask every active API at once. on_row(key, view), on_done(summary, views)."""
	apis = active_apis() if apis is None else apis
	views = {}

	def ask(key, name, fn):
		start = time.time()
		code = None
		try: code = int(fn())
		except Exception as e:
			_log('api %s -> no answer (%s)' % (key, type(e).__name__))
		views[key] = api_view(code, time.time() - start)
		_log('api %s -> %s (HTTP %s, %.1fs)' % (key, views[key]['state'], code, time.time() - start))
		if on_row:
			try: on_row(key, views[key])
			except Exception: log_utils.error()
	threads = [threading.Thread(target=ask, args=a) for a in apis]
	for t in threads: t.start()
	for t in threads: t.join(API_TIMEOUT + 4)
	for key, name, fn in apis:
		if key not in views:
			views[key] = api_view(None, API_TIMEOUT)
			if on_row:
				try: on_row(key, views[key])
				except Exception: log_utils.error()
	ordered = [dict(views[k], name=k, label=n) for k, n, f in apis]
	text = summary(ordered)
	_write_cache(PROP_APIS, {'sum': text, 'rows': ordered})
	if on_done:
		try: on_done(text, ordered)
		except Exception: log_utils.error()
	return ordered


def last_api_test():
	return _read_cache(PROP_APIS)

# ───────────────────────── scrapers ─────────────────────────
def classify(row):
	"""provider_test row -> what the list shows. state: ok / warn / fail."""
	elapsed = '%.1f s' % (row.get('elapsed') or 0.0)
	results = row.get('results')
	if row.get('configured') is False:
		return {'state': 'warn', 'dot': ORANGE, 'note': L(48178), 'notecolor': ORANGE, 'value': ''}
	if row.get('skipped'): # v2.0.20: el scraper no busco y dice por que (torboxnews)
		return {'state': 'warn', 'dot': ORANGE, 'note': row['skipped'], 'notecolor': ORANGE, 'value': ''}
	if row.get('reachable') is False:
		return {'state': 'fail', 'dot': RED, 'note': L(48177), 'notecolor': RED, 'value': L(48176)}
	if results is None:
		return {'state': 'fail', 'dot': RED, 'note': L(48176), 'notecolor': RED, 'value': elapsed}
	if not results:
		return {'state': 'warn', 'dot': ORANGE, 'note': L(48174) % 0, 'notecolor': ORANGE, 'value': elapsed}
	count = L(48181) if results == 1 else L(48174) % results
	if (row.get('elapsed') or 0.0) > SLOW_SECONDS:
		return {'state': 'warn', 'dot': ORANGE, 'note': '%s · %s' % (count, L(48175)), 'notecolor': ORANGE, 'value': elapsed}
	return {'state': 'ok', 'dot': GREEN, 'note': count, 'notecolor': GREY, 'value': elapsed}


def pending_view():
	return {'state': 'pending', 'dot': GREY, 'note': L(48179), 'notecolor': GREY, 'value': ''}


def timeout_view():
	return {'state': 'fail', 'dot': RED, 'note': L(48177), 'notecolor': RED, 'value': '%d s' % TEST_DEADLINE}


def enabled_providers():
	"""[(name, source class)] of the enabled providers that a movie test applies to."""
	from resources.lib.jacksparrow import sources as fs_sources
	out = []
	for name, cls in fs_sources() or []:
		if name in EXCLUDE or getattr(cls, 'languages_only', False) or not getattr(cls, 'hasMovies', False): continue
		out.append((name, cls))
	out.sort(key=lambda e: display_name(e[0]).lower())
	return out


def summary(views):
	ok = len([v for v in views if v.get('state') == 'ok'])
	return L(48173) % (ok, len(views), time.strftime('%H:%M'))


def last_test():
	return _read_cache(PROP_SCRAPERS)


def test_blocked():
	"""0 when a test may start now; otherwise the seconds to wait (the provider
	test's own lock and cooldown, shared so the two never overlap)."""
	from resources.lib.modules import provider_test
	now = time.time()
	try:
		running = control.homeWindow.getProperty(provider_test.RUN_FLAG)
		if running and (now - int(running)) < 360: return max(1, int(360 - (now - int(running))))
		last = control.homeWindow.getProperty(provider_test.LAST_END)
		if last and (now - int(last)) < provider_test.COOLDOWN:
			return max(1, int(provider_test.COOLDOWN - (now - int(last))))
	except Exception:
		pass
	return 0


def run_test(entries, on_row=None, on_done=None):
	"""Test the given providers (background-safe). on_row(name, view) as each one
	finishes, on_done(summary_text, views) at the end. Returns the views."""
	from resources.lib.modules import provider_test
	from resources.lib.jacksparrow import workers
	monitor = xbmc.Monitor()
	gate = threading.Semaphore(provider_test.MAX_PARALLEL)
	views, rows = {}, {}
	try: control.homeWindow.setProperty(provider_test.RUN_FLAG, str(int(time.time())))
	except Exception: pass

	def work(entry):
		row = provider_test._run_one(entry, dict(TEST_TITLE), gate)
		rows[entry[0]] = row
		views[entry[0]] = classify(row)
		if on_row:
			try: on_row(entry[0], views[entry[0]])
			except Exception: log_utils.error()

	threads = [workers.Thread(work, e) for e in entries]
	for t in threads: t.start()
	deadline = time.time() + TEST_DEADLINE
	while any(t.is_alive() for t in threads) and time.time() < deadline:
		if monitor.waitForAbort(0.25): break
	for name, cls in entries:
		if name not in views:
			views[name] = timeout_view()
			if on_row:
				try: on_row(name, views[name])
				except Exception: log_utils.error()
	try:
		control.homeWindow.setProperty(provider_test.LAST_END, str(int(time.time())))
		control.homeWindow.clearProperty(provider_test.RUN_FLAG)
	except Exception:
		pass
	ordered = [dict(views[n], name=n, label=display_name(n)) for n, c in entries]
	text = summary(ordered)
	_write_cache(PROP_SCRAPERS, {'sum': text, 'rows': ordered})
	for n, c in entries:
		r = rows.get(n) or {}
		_log('test %s -> %s (results=%s, %.1fs, configured=%s, reachable=%s%s)' % (
			n, views[n]['state'], r.get('results'), r.get('elapsed') or 0.0, r.get('configured'), r.get('reachable'),
			(', error=%s' % r['error']) if r.get('error') else ''))
	_log('test done: %s' % text)
	if on_done:
		try: on_done(text, ordered)
		except Exception: log_utils.error()
	return ordered


# ───────────────────────── background work ─────────────────────────
_BG = []


def track(thread):
	"""Threads started by the page (test, expiry dates, update check)."""
	_BG.append(thread)
	return thread


def wait_background():
	"""Called at the very end of a top-level call (router ctx_Hub / ctx_Status),
	after any navigation has been sent: if the page was closed while a test was
	running, the script stays alive until it ends, so the result is saved and
	the provider test lock is released instead of being cut off half-way. The
	UI is not held: the window is already closed. Kodi shutting down wins."""
	monitor = xbmc.Monitor()
	end = time.time() + TEST_DEADLINE + 15
	while any(t.is_alive() for t in _BG) and time.time() < end:
		if monitor.waitForAbort(0.25): break
	del _BG[:]


# ───────────────────────── entry points ─────────────────────────
def open_page(from_panel=False):
	"""Show the page. Returns 'back' (to the context panel), 'home',
	'__search__' or None."""
	result = None
	try:
		from resources.lib.windows.system_status import SystemStatusXML
		window = SystemStatusXML('system_status.xml', control.addonPath(control.addonId()), from_panel=from_panel)
		result = window.run()
		del window
	except Exception:
		log_utils.error()
	return result


def show():
	"""Router action ctx_Status (Settings, or anywhere outside the panel)."""
	result = open_page(from_panel=False)
	if result == '__search__':
		from resources.lib.modules import spotlight
		control.sleep(80)
		spotlight.open_search()
	elif result == 'home':
		from resources.lib.modules import navstate
		navstate.go_home()
	wait_background()
