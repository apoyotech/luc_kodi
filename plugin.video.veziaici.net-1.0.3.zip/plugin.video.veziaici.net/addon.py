import sys
import xbmcvfs
import xbmcaddon
import xbmcgui
import xbmcplugin
import urllib.parse
import requests
import resolveurl
import json
import re
import os
import time
from bs4 import BeautifulSoup

# Get the addon ID
ADDON_ID = xbmcaddon.Addon().getAddonInfo('id')
ADDON = xbmcaddon.Addon(ADDON_ID)
HANDLE = int(sys.argv[1])
BASE_URL = 'https://veziaici.net/'
CACHE_DIR = xbmcvfs.translatePath(os.path.join(xbmcaddon.Addon().getAddonInfo('profile'), 'cache'))
if not os.path.exists(CACHE_DIR):
    os.makedirs(CACHE_DIR)

# Dictionary for custom show images
CUSTOM_IMAGES = {
    'insula iubirii': 'https://www.fanatik.ro/wp-content/uploads/2024/08/insula-iubirii-2025.jpg',
    'las fierbinti': 'https://upload.wikimedia.org/wikipedia/en/0/0d/Las_Fierbin%C8%9Bi_logo.png',
    'asia express': 'https://cdn.adh.reperio.news/image-e/e410c82f-f849-4953-94fa-ed9ee2ba49bf/index.jpeg',
    'masterchef': 'https://static4.libertatea.ro/wp-content/uploads/2024/02/masterchef-romania-revine-la-pro-tv.jpg',
    'the ticket': 'https://static4.libertatea.ro/wp-content/uploads/2025/07/the-ticket.jpg',
    'vocea romaniei': 'https://upload.wikimedia.org/wikipedia/ro/thumb/8/83/Vocea_Rom%C3%A2niei_-_compila%C8%9Bie.jpg/250px-Vocea_Rom%C3%A2niei_-_compila%C8%9Bie.jpg',
    'ana mi-ai fost scrisa in adn': 'https://static4.libertatea.ro/wp-content/uploads/2024/11/ana-mi-ai-fost-scrisa-in-adn-serial-antena-1.jpg',
    'camera 609': 'https://static.cinemagia.ro/img/resize/db/movie/33/10/231/lasa-ma-imi-place-camera-609-729239l-600x0-w-09e9e09b.jpg',
    'clanul': 'https://cmero-ott-images-svod.ssl.cdn.cra.cz/r800x1160n/ad802c4a-901f-4700-9948-39361f41a677',
    'seriale': 'https://upload.wikimedia.org/wikipedia/en/0/0d/Las_Fierbin%C8%9Bi_logo.png',
    'iubire cu': 'https://dcasting.ro/wp-content/uploads/2025/02/Iubire-cu-parfum-de-lavanda.jpg',
    'sotia sotului': 'https://onemagia.com/upload/images/e7mDxkP6Qgbo735USy5telMF1wF.jpg',
    'scara b': 'https://static4.libertatea.ro/wp-content/uploads/2024/08/scara-b-scaled.jpg',
    'tatutu': 'https://image.stirileprotv.ro/media/images/1920x1080/Jun2025/62556367.jpg'
}

def get_main_menu_items():
    try:
        response = requests.get(BASE_URL)
        response.raise_for_status()
        html_content = response.text
    except requests.exceptions.RequestException as e:
        xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), f"Failed to fetch main page: {e}")
        return []
    
    soup = BeautifulSoup(html_content, 'html.parser')
    categories = []
    
    for top_li in soup.select('ul#main-menu > li.menu-item-has-children'):
        category_title_element = top_li.find('span')
        if not category_title_element:
            continue
        
        category_title = category_title_element.text.strip()
        sub_menu = top_li.find('ul', class_='sub-menu')
        
        if category_title and sub_menu:
            shows = []
            for sub_li in sub_menu.find_all('li'):
                link = sub_li.find('a')
                if link and 'href' in link.attrs:
                    title = link.text.strip()
                    url = link['href']
                    if title and url:
                        shows.append({'title': title, 'url': url})
            if shows:
                categories.append({'title': category_title, 'shows': shows})
                        
    return categories

def list_main_menu():
    # Add a static search item
    list_item = xbmcgui.ListItem('Cauta')
    search_icon = "https://i.imgur.com/dvqhLCI.png"
    list_item.setArt({'icon': search_icon, 'thumb': search_icon})
    url = sys.argv[0] + '?' + urllib.parse.urlencode({'mode': 'search'})
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)

    categories = get_main_menu_items()
    for category in categories:
        list_item = xbmcgui.ListItem(category['title'])
        category_icon = ADDON.getAddonInfo('icon')  # Initialize with default
        
        if 'emisiuni' in category['title'].lower():
            category_icon = CUSTOM_IMAGES.get('asia express', category_icon)
            url = sys.argv[0] + '?' + urllib.parse.urlencode({'mode': 'list_show_categories', 'shows': json.dumps(category['shows']), 'name': category['title'], 'latest_url': 'https://veziaici.net/category/a-emisiuni-romanesti/'})
        elif 'seriale' in category['title'].lower():
            category_icon = CUSTOM_IMAGES.get('las fierbinti', category_icon)
            url = sys.argv[0] + '?' + urllib.parse.urlencode({'mode': 'list_show_categories', 'shows': json.dumps(category['shows']), 'name': category['title'], 'latest_url': 'https://veziaici.net/category/a-seriale-romanesti/'})
        else:
            url = sys.argv[0] + '?' + urllib.parse.urlencode({'mode': 'list_shows', 'shows': json.dumps(category['shows']), 'name': category['title']})

        list_item.setArt({'icon': category_icon, 'thumb': category_icon})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_show_categories(shows_json, name, latest_url):
    # Add "Ultimile adaugate" item
    list_item = xbmcgui.ListItem('Ultimile adaugate')
    url_params = {'mode': 'list_latest', 'url': latest_url, 'name': 'Ultimile adaugate'}
    xbmcplugin.addDirectoryItem(handle=HANDLE, url=sys.argv[0] + '?' + urllib.parse.urlencode(url_params), listitem=list_item, isFolder=True)

    # Add the rest of the shows
    shows = json.loads(shows_json)
    for show in shows:
        list_item = xbmcgui.ListItem(show['title'])
        
        # Default icon
        show_icon = ADDON.getAddonInfo('icon')
        # Check for custom image
        for keyword, image_url in CUSTOM_IMAGES.items():
            if keyword in show['title'].lower():
                show_icon = image_url
                break

        list_item.setArt({'icon': show_icon, 'thumb': show_icon})
        url = sys.argv[0] + '?' + urllib.parse.urlencode({'mode': 'list_episodes', 'url': show['url'], 'name': show['title']})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_shows(shows_json):
    shows = json.loads(shows_json)
    for show in shows:
        list_item = xbmcgui.ListItem(show['title'])
        
        # Default icon
        show_icon = ADDON.getAddonInfo('icon')
        # Check for custom image
        for keyword, image_url in CUSTOM_IMAGES.items():
            if keyword in show['title'].lower():
                show_icon = image_url
                break

        list_item.setArt({'icon': show_icon, 'thumb': show_icon})
        url = sys.argv[0] + '?' + urllib.parse.urlencode({'mode': 'list_episodes', 'url': show['url'], 'name': show['title']})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_episodes(url, name=""):
    cache_file = os.path.join(CACHE_DIR, name.replace(' ', '_') + '.json')
    cache_expiry = 24 * 3600 # 24 hours

    all_episodes = []

    # Try to load from cache first
    if os.path.exists(cache_file) and (time.time() - os.path.getmtime(cache_file)) < cache_expiry:
        with open(cache_file, 'r') as f:
            all_episodes = json.load(f)
    else:
        # If cache is invalid or missing, scrape all pages
        current_url = url
        while current_url:
            try:
                response = requests.get(current_url)
                response.raise_for_status()
                soup = BeautifulSoup(response.text, 'html.parser')
            except requests.exceptions.RequestException:
                break

            for item_container in soup.find_all('div', class_='rb-col-m12'):
                title_element = item_container.find('h2', class_='entry-title')
                if title_element and title_element.find('a'):
                    link_element = title_element.find('a')
                    item_url = link_element['href']
                    title = link_element.text.strip()
                    if item_url and title:
                        all_episodes.append({'title': title, 'url': item_url, 'name': name})

            next_page_link = soup.find('a', class_='next page-numbers')
            if next_page_link and next_page_link.has_attr('href'):
                current_url = next_page_link['href']
            else:
                current_url = None
        
        # Save to cache
        with open(cache_file, 'w') as f:
            json.dump(all_episodes, f)

    # --- The rest of the function remains the same, processing 'all_episodes' ---

    # Extract seasons from episode titles
    seasons = {}
    no_season_episodes = []
    for episode in all_episodes:
        match = re.search(r'sez(?:onul|on|\.)\s*(\d+)', episode['title'], re.IGNORECASE)
        if match:
            season_num = int(match.group(1))
            if season_num not in seasons:
                seasons[season_num] = []
            seasons[season_num].append(episode)
        else:
            no_season_episodes.append(episode)

    # If only one season is found and no episodes without a season, list them directly
    if len(seasons) == 1 and not no_season_episodes:
        season_num = list(seasons.keys())[0]
        list_episodes_for_season(json.dumps(seasons[season_num]), season_num, name)
        return

    # Create folders for each season
    for season_num in sorted(seasons.keys(), reverse=True):
        list_item = xbmcgui.ListItem(f"Sezonul {season_num}")
        season_icon = ADDON.getAddonInfo('icon')
        for keyword, image_url in CUSTOM_IMAGES.items():
            if keyword in name.lower():
                season_icon = image_url
                break
        list_item.setArt({'icon': season_icon, 'thumb': season_icon})
        url_params = {'mode': 'list_episodes_for_season', 'episodes': json.dumps(seasons[season_num]), 'season': season_num, 'name': name}
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=sys.argv[0] + '?' + urllib.parse.urlencode(url_params), listitem=list_item, isFolder=True)

    if no_season_episodes:
        list_item = xbmcgui.ListItem("Fara Sezon")
        list_item.setArt({'icon': ADDON.getAddonInfo('icon'), 'thumb': ADDON.getAddonInfo('icon')})
        url_params = {'mode': 'list_episodes_for_season', 'episodes': json.dumps(no_season_episodes), 'season': '0', 'name': name}
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=sys.argv[0] + '?' + urllib.parse.urlencode(url_params), listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def list_episodes_for_season(episodes_json, season, name=""):
    episodes = json.loads(episodes_json)
    custom_image_found = None
    for keyword, image_url in CUSTOM_IMAGES.items():
        if keyword in name.lower():
            custom_image_found = image_url
            break

    for episode in episodes:
        list_item = xbmcgui.ListItem(episode['title'])
        image_to_use = custom_image_found if custom_image_found else ADDON.getAddonInfo('icon')
        list_item.setArt({'thumb': image_to_use, 'icon': image_to_use, 'fanart': ADDON.getAddonInfo('fanart')})
        list_item.setInfo('video', {'title': episode['title']})
        url_params = {'mode': 'list_sources', 'url': episode['url']}
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=sys.argv[0] + '?' + urllib.parse.urlencode(url_params), listitem=list_item, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_sources(url):
    try:
        response = requests.get(url)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
    except requests.exceptions.RequestException as e:
        xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), f"Failed to fetch source page: {e}")
        return

    iframes = soup.find_all('iframe', attrs={'data-lazy-src': True})
    for iframe in iframes:
        video_url = iframe['data-lazy-src']
        
        if video_url.startswith('//'):
            video_url = 'https:' + video_url
        
        domain = urllib.parse.urlparse(video_url).netloc.replace('www.', '')
        
        list_item = xbmcgui.ListItem(f"Sursa: {domain}")
        list_item.setInfo('video', {'title': f"Sursa: {domain}"})
        list_item.setProperty('IsPlayable', 'true')
        url_params = {'mode': 'play_source', 'url': video_url}
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=sys.argv[0] + '?' + urllib.parse.urlencode(url_params), listitem=list_item, isFolder=False)
    
    xbmcplugin.endOfDirectory(HANDLE)

def play_source(url):
    resolved_url = resolveurl.resolve(url)
    if resolved_url:
        list_item = xbmcgui.ListItem(path=resolved_url)
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
    else:
        xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), "Could not resolve video URL.")

def list_search_results(url):
    try:
        response = requests.get(url)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
    except requests.exceptions.RequestException as e:
        xbmcgui.Dialog().ok(ADDON.getAddonInfo('name'), f"Failed to fetch search results: {e}")
        return

    for item in soup.select('div.rb-p20-gutter.rb-col-m12.rb-col-t4'):
        title_element = item.select_one('h3.entry-title a.p-url')
        if title_element:
            title = title_element.get('title')
            item_url = title_element.get('href')
            
            show_icon = ADDON.getAddonInfo('icon')
            for keyword, image_url in CUSTOM_IMAGES.items():
                if keyword in title.lower():
                    show_icon = image_url
                    break

            list_item = xbmcgui.ListItem(title)
            list_item.setArt({'thumb': show_icon, 'icon': show_icon})
            
            # We assume search results lead directly to sources
            url_params = {'mode': 'list_sources', 'url': item_url, 'name': title}
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=sys.argv[0] + '?' + urllib.parse.urlencode(url_params), listitem=list_item, isFolder=True)

    # Handle pagination
    next_page_link = soup.select_one('a.page-numbers')
    if next_page_link:
        next_page_url = next_page_link.get('href')
        if next_page_url:
            list_item = xbmcgui.ListItem('Next Page >>')
            url_params = {'mode': 'list_search_results', 'url': next_page_url}
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=sys.argv[0] + '?' + urllib.parse.urlencode(url_params), listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def search(query=None):
    if not query:
        keyboard = xbmcgui.Dialog().input('Cauta', type=xbmcgui.INPUT_ALPHANUM)
        if not keyboard:
            return
        query = keyboard

    search_url = BASE_URL + '?s=' + urllib.parse.quote_plus(query)
    list_search_results(search_url)

def list_latest(url, name=""):
    all_items = []
    current_url = url
    page_count = 0

    while current_url and page_count < 3:
        try:
            response = requests.get(current_url)
            response.raise_for_status()
            soup = BeautifulSoup(response.text, 'html.parser')
        except requests.exceptions.RequestException:
            break

        for item_container in soup.find_all('div', class_='rb-col-m12'):
            title_element = item_container.find('h2', class_='entry-title')
            if title_element and title_element.find('a'):
                link_element = title_element.find('a')
                item_url = link_element['href']
                title = link_element.text.strip()

                show_icon = ADDON.getAddonInfo('icon')
                for keyword, image_url in CUSTOM_IMAGES.items():
                    if keyword in title.lower():
                        show_icon = image_url
                        break

                if item_url and title:
                    all_items.append({'title': title, 'url': item_url, 'thumbnail': show_icon})

        next_page_link = soup.find('a', class_='next page-numbers')
        if next_page_link and next_page_link.has_attr('href'):
            current_url = next_page_link['href']
        else:
            current_url = None
        
        page_count += 1

    for item in all_items:
        list_item = xbmcgui.ListItem(item['title'])
        list_item.setArt({'thumb': item['thumbnail'], 'icon': item['thumbnail']})
        list_item.setInfo('video', {'title': item['title']})
        url_params = {'mode': 'list_sources', 'url': item['url']}
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=sys.argv[0] + '?' + urllib.parse.urlencode(url_params), listitem=list_item, isFolder=True)

    if current_url:
        list_item = xbmcgui.ListItem('Next Page >>')
        url_params = {'mode': 'list_latest', 'url': current_url, 'name': name}
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=sys.argv[0] + '?' + urllib.parse.urlencode(url_params), listitem=list_item, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get('mode')
    name = params.get('name')
    url = params.get('url')
    shows = params.get('shows')
    episodes = params.get('episodes')
    season = params.get('season')
    latest_url = params.get('latest_url')

    if mode is None:
        list_main_menu()
    elif mode == 'list_show_categories':
        list_show_categories(shows, name, latest_url)
    elif mode == 'list_latest':
        list_latest(url, name)
    elif mode == 'list_episodes':
        list_episodes(url, name)
    elif mode == 'list_episodes_for_season':
        list_episodes_for_season(episodes, season, name)
    elif mode == 'list_search_results':
        list_search_results(url)
    elif mode == 'list_sources':
        list_sources(url)
    elif mode == 'play_source':
        play_source(url)
    elif mode == 'search':
        search()


if __name__ == '__main__':
    router(sys.argv[2][1:])
